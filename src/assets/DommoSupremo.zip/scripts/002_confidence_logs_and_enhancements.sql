-- DOMMO CORE - Migration 002: Confidence Gate Logs, Enhanced Bets, Device Sync, AI Config

-- Confidence gate logs - stores every time a lottery hits the confidence threshold
CREATE TABLE IF NOT EXISTS public.confidence_gate_logs (
  id BIGSERIAL PRIMARY KEY,
  lottery_id TEXT NOT NULL,
  lottery_name TEXT NOT NULL,
  contest_id INTEGER NOT NULL DEFAULT 0,
  confidence NUMERIC NOT NULL,
  threshold NUMERIC NOT NULL DEFAULT 0.999,
  gate_status TEXT NOT NULL DEFAULT 'APPROVED',
  model_name TEXT NOT NULL DEFAULT '',
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  extras JSONB DEFAULT '{}',
  analysis_window INTEGER DEFAULT 0,
  triggered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  year INTEGER NOT NULL DEFAULT EXTRACT(YEAR FROM NOW()),
  month INTEGER NOT NULL DEFAULT EXTRACT(MONTH FROM NOW()),
  day INTEGER NOT NULL DEFAULT EXTRACT(DAY FROM NOW()),
  hour INTEGER NOT NULL DEFAULT EXTRACT(HOUR FROM NOW()),
  minute INTEGER NOT NULL DEFAULT EXTRACT(MINUTE FROM NOW()),
  notes TEXT DEFAULT ''
);

-- Add missing columns to saved_bets if they don't exist
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS bet_date TEXT DEFAULT '';
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS confirmed_at TIMESTAMPTZ;
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS model_name TEXT DEFAULT '';
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS year INTEGER DEFAULT EXTRACT(YEAR FROM NOW());
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS result_numbers INTEGER[] DEFAULT '{}';
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS result_checked BOOLEAN DEFAULT FALSE;
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS result_hits INTEGER DEFAULT 0;
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS result_tier TEXT DEFAULT '';
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS result_prize NUMERIC DEFAULT 0;
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS result_checked_at TIMESTAMPTZ;
ALTER TABLE public.saved_bets ADD COLUMN IF NOT EXISTS source TEXT DEFAULT 'bets_view';

-- Device sync state table - keeps track of last sync per device
CREATE TABLE IF NOT EXISTS public.device_sync (
  id BIGSERIAL PRIMARY KEY,
  device_id TEXT NOT NULL UNIQUE,
  device_name TEXT DEFAULT '',
  device_type TEXT DEFAULT 'unknown',
  last_sync_at TIMESTAMPTZ DEFAULT NOW(),
  sync_data JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- AI configuration table
CREATE TABLE IF NOT EXISTS public.ai_config (
  id BIGSERIAL PRIMARY KEY,
  config_key TEXT NOT NULL UNIQUE,
  config_value JSONB NOT NULL DEFAULT '{}',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_confidence_logs_lottery ON public.confidence_gate_logs(lottery_id);
CREATE INDEX IF NOT EXISTS idx_confidence_logs_status ON public.confidence_gate_logs(gate_status);
CREATE INDEX IF NOT EXISTS idx_confidence_logs_triggered ON public.confidence_gate_logs(triggered_at);
CREATE INDEX IF NOT EXISTS idx_confidence_logs_year ON public.confidence_gate_logs(year, month, day);
CREATE INDEX IF NOT EXISTS idx_saved_bets_status ON public.saved_bets(status);
CREATE INDEX IF NOT EXISTS idx_saved_bets_contest ON public.saved_bets(lottery_id, contest_id);
CREATE INDEX IF NOT EXISTS idx_saved_bets_checked ON public.saved_bets(result_checked);
CREATE INDEX IF NOT EXISTS idx_device_sync_device ON public.device_sync(device_id);

-- RLS
ALTER TABLE public.confidence_gate_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.device_sync ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ai_config ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "anon_read_confidence_logs" ON public.confidence_gate_logs FOR SELECT USING (true);
CREATE POLICY "anon_insert_confidence_logs" ON public.confidence_gate_logs FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_confidence_logs" ON public.confidence_gate_logs FOR UPDATE USING (true);

CREATE POLICY "anon_read_device_sync" ON public.device_sync FOR SELECT USING (true);
CREATE POLICY "anon_insert_device_sync" ON public.device_sync FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_device_sync" ON public.device_sync FOR UPDATE USING (true);

CREATE POLICY "anon_read_ai_config" ON public.ai_config FOR SELECT USING (true);
CREATE POLICY "anon_insert_ai_config" ON public.ai_config FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_ai_config" ON public.ai_config FOR UPDATE USING (true);

-- Insert default AI config
INSERT INTO public.ai_config (config_key, config_value) VALUES
  ('confidence_threshold', '{"value": 0.999, "label": "99.9%"}'),
  ('ai_models_enabled', '{"CertusV2": true, "BayesianNet": true, "MarkovChain": true, "NeuralFreq": true, "TemporalGAN": true, "EnsembleVote": true}'),
  ('auto_check_results', '{"enabled": true, "interval_minutes": 5}'),
  ('device_sync_enabled', '{"enabled": true}'),
  ('advanced_ai', '{"ensemble_voting": true, "frequency_analysis": true, "pattern_recognition": true, "temporal_analysis": true, "cross_lottery_correlation": true, "hot_cold_tracking": true, "gap_analysis": true, "positional_frequency": true}')
ON CONFLICT (config_key) DO NOTHING;
