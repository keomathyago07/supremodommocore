import sharp from "sharp";
import { readFileSync, mkdirSync, existsSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const publicDir = join(__dirname, "..", "public");
const iconsDir = join(publicDir, "icons");

if (!existsSync(iconsDir)) mkdirSync(iconsDir, { recursive: true });

const sourceImage = join(publicDir, "icon-512.jpg");

async function generateIcons() {
  const src = readFileSync(sourceImage);

  // 192x192 PNG
  await sharp(src).resize(192, 192).png().toFile(join(iconsDir, "icon-192.png"));
  console.log("Created icons/icon-192.png");

  // 512x512 PNG
  await sharp(src).resize(512, 512).png().toFile(join(iconsDir, "icon-512.png"));
  console.log("Created icons/icon-512.png");

  // Maskable 512x512 PNG (add padding for safe area)
  const maskable = await sharp(src).resize(410, 410).extend({
    top: 51, bottom: 51, left: 51, right: 51,
    background: { r: 11, g: 14, b: 20, alpha: 1 }
  }).png().toFile(join(iconsDir, "maskable-512.png"));
  console.log("Created icons/maskable-512.png");

  // Favicon 32x32
  await sharp(src).resize(32, 32).png().toFile(join(publicDir, "favicon.png"));
  console.log("Created favicon.png");

  // Apple touch icon 180x180
  await sharp(src).resize(180, 180).png().toFile(join(iconsDir, "apple-touch-icon.png"));
  console.log("Created icons/apple-touch-icon.png");

  console.log("All icons generated successfully!");
}

generateIcons().catch(console.error);
