-- DOMMO CORE - Lottery Database Schema
-- Each lottery has its own table for independent AI analysis

-- Master draws table with all lotteries
CREATE TABLE IF NOT EXISTS public.draws (
  id BIGSERIAL PRIMARY KEY,
  lottery_id TEXT NOT NULL,
  contest_id INTEGER NOT NULL,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  extras JSONB DEFAULT '{}',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(lottery_id, contest_id)
);

-- Mega-Sena dedicated table
CREATE TABLE IF NOT EXISTS public.megasena (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Lotofacil dedicated table
CREATE TABLE IF NOT EXISTS public.lotofacil (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Quina dedicated table
CREATE TABLE IF NOT EXISTS public.quina (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Lotomania dedicated table
CREATE TABLE IF NOT EXISTS public.lotomania (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Timemania dedicated table
CREATE TABLE IF NOT EXISTS public.timemania (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  team TEXT DEFAULT '',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Dupla Sena dedicated table
CREATE TABLE IF NOT EXISTS public.duplasena (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  numbers_2 INTEGER[] DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Dia de Sorte dedicated table
CREATE TABLE IF NOT EXISTS public.diadesorte (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  lucky_month TEXT DEFAULT '',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Super Sete dedicated table
CREATE TABLE IF NOT EXISTS public.supersete (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  columns INTEGER[] NOT NULL DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- +Milionaria dedicated table
CREATE TABLE IF NOT EXISTS public.maismilionaria (
  id BIGSERIAL PRIMARY KEY,
  contest_id INTEGER NOT NULL UNIQUE,
  draw_date TEXT NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  trevos INTEGER[] DEFAULT '{}',
  accumulated BOOLEAN DEFAULT FALSE,
  prize_estimate NUMERIC DEFAULT 0,
  accumulated_value NUMERIC DEFAULT 0,
  prizes JSONB DEFAULT '[]',
  raw_data JSONB DEFAULT '{}',
  synced_at TIMESTAMPTZ DEFAULT NOW()
);

-- Saved bets table
CREATE TABLE IF NOT EXISTS public.saved_bets (
  id BIGSERIAL PRIMARY KEY,
  lottery_id TEXT NOT NULL,
  contest_id INTEGER NOT NULL,
  numbers INTEGER[] NOT NULL DEFAULT '{}',
  extras JSONB DEFAULT '{}',
  confidence NUMERIC DEFAULT 0,
  gate_status TEXT DEFAULT 'PENDING',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audit logs table
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id BIGSERIAL PRIMARY KEY,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT DEFAULT '',
  details TEXT DEFAULT '',
  severity TEXT DEFAULT 'info',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Sync status table
CREATE TABLE IF NOT EXISTS public.sync_status (
  id BIGSERIAL PRIMARY KEY,
  lottery_id TEXT NOT NULL,
  last_contest_id INTEGER DEFAULT 0,
  last_sync_at TIMESTAMPTZ DEFAULT NOW(),
  status TEXT DEFAULT 'ok',
  error_message TEXT DEFAULT '',
  UNIQUE(lottery_id)
);

-- Indexes for fast AI queries
CREATE INDEX IF NOT EXISTS idx_draws_lottery ON public.draws(lottery_id);
CREATE INDEX IF NOT EXISTS idx_draws_contest ON public.draws(lottery_id, contest_id);
CREATE INDEX IF NOT EXISTS idx_draws_date ON public.draws(draw_date);
CREATE INDEX IF NOT EXISTS idx_megasena_contest ON public.megasena(contest_id);
CREATE INDEX IF NOT EXISTS idx_lotofacil_contest ON public.lotofacil(contest_id);
CREATE INDEX IF NOT EXISTS idx_quina_contest ON public.quina(contest_id);
CREATE INDEX IF NOT EXISTS idx_lotomania_contest ON public.lotomania(contest_id);
CREATE INDEX IF NOT EXISTS idx_timemania_contest ON public.timemania(contest_id);
CREATE INDEX IF NOT EXISTS idx_duplasena_contest ON public.duplasena(contest_id);
CREATE INDEX IF NOT EXISTS idx_diadesorte_contest ON public.diadesorte(contest_id);
CREATE INDEX IF NOT EXISTS idx_supersete_contest ON public.supersete(contest_id);
CREATE INDEX IF NOT EXISTS idx_maismilionaria_contest ON public.maismilionaria(contest_id);
CREATE INDEX IF NOT EXISTS idx_saved_bets_lottery ON public.saved_bets(lottery_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON public.audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON public.audit_logs(created_at);

-- Disable RLS for this app (PIN-based auth, not user-based)
ALTER TABLE public.draws ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.megasena ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lotofacil ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quina ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lotomania ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.timemania ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.duplasena ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.diadesorte ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.supersete ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.maismilionaria ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.saved_bets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sync_status ENABLE ROW LEVEL SECURITY;

-- Allow public access via anon key (PIN protects the app)
CREATE POLICY "anon_read_draws" ON public.draws FOR SELECT USING (true);
CREATE POLICY "anon_insert_draws" ON public.draws FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_draws" ON public.draws FOR UPDATE USING (true);

CREATE POLICY "anon_read_megasena" ON public.megasena FOR SELECT USING (true);
CREATE POLICY "anon_insert_megasena" ON public.megasena FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_megasena" ON public.megasena FOR UPDATE USING (true);

CREATE POLICY "anon_read_lotofacil" ON public.lotofacil FOR SELECT USING (true);
CREATE POLICY "anon_insert_lotofacil" ON public.lotofacil FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_lotofacil" ON public.lotofacil FOR UPDATE USING (true);

CREATE POLICY "anon_read_quina" ON public.quina FOR SELECT USING (true);
CREATE POLICY "anon_insert_quina" ON public.quina FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_quina" ON public.quina FOR UPDATE USING (true);

CREATE POLICY "anon_read_lotomania" ON public.lotomania FOR SELECT USING (true);
CREATE POLICY "anon_insert_lotomania" ON public.lotomania FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_lotomania" ON public.lotomania FOR UPDATE USING (true);

CREATE POLICY "anon_read_timemania" ON public.timemania FOR SELECT USING (true);
CREATE POLICY "anon_insert_timemania" ON public.timemania FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_timemania" ON public.timemania FOR UPDATE USING (true);

CREATE POLICY "anon_read_duplasena" ON public.duplasena FOR SELECT USING (true);
CREATE POLICY "anon_insert_duplasena" ON public.duplasena FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_duplasena" ON public.duplasena FOR UPDATE USING (true);

CREATE POLICY "anon_read_diadesorte" ON public.diadesorte FOR SELECT USING (true);
CREATE POLICY "anon_insert_diadesorte" ON public.diadesorte FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_diadesorte" ON public.diadesorte FOR UPDATE USING (true);

CREATE POLICY "anon_read_supersete" ON public.supersete FOR SELECT USING (true);
CREATE POLICY "anon_insert_supersete" ON public.supersete FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_supersete" ON public.supersete FOR UPDATE USING (true);

CREATE POLICY "anon_read_maismilionaria" ON public.maismilionaria FOR SELECT USING (true);
CREATE POLICY "anon_insert_maismilionaria" ON public.maismilionaria FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_maismilionaria" ON public.maismilionaria FOR UPDATE USING (true);

CREATE POLICY "anon_read_bets" ON public.saved_bets FOR SELECT USING (true);
CREATE POLICY "anon_insert_bets" ON public.saved_bets FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_bets" ON public.saved_bets FOR UPDATE USING (true);
CREATE POLICY "anon_delete_bets" ON public.saved_bets FOR DELETE USING (true);

CREATE POLICY "anon_read_audit" ON public.audit_logs FOR SELECT USING (true);
CREATE POLICY "anon_insert_audit" ON public.audit_logs FOR INSERT WITH CHECK (true);

CREATE POLICY "anon_read_sync" ON public.sync_status FOR SELECT USING (true);
CREATE POLICY "anon_insert_sync" ON public.sync_status FOR INSERT WITH CHECK (true);
CREATE POLICY "anon_update_sync" ON public.sync_status FOR UPDATE USING (true);
