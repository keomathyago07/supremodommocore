"use client"

import { useState, useRef, useEffect } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { Shield, Lock, AlertTriangle, Zap, Activity, Cpu, Brain } from "lucide-react"

const CORRECT_PIN = "834589"
const MAX_ATTEMPTS = 5
const BLOCK_TIME = 60000

export function AuthScreen() {
  const { locale, setIsAuthenticated } = useApp()
  const [pin, setPin] = useState(["", "", "", "", "", ""])
  const [error, setError] = useState("")
  const [attempts, setAttempts] = useState(0)
  const [blocked, setBlocked] = useState(false)
  const [blockTimer, setBlockTimer] = useState(0)
  const [brasiliaTime, setBrasiliaTime] = useState("")
  const inputRefs = useRef<(HTMLInputElement | null)[]>([])

  useEffect(() => {
    if (blocked) {
      const interval = setInterval(() => {
        setBlockTimer((prev) => {
          if (prev <= 1) { setBlocked(false); setAttempts(0); clearInterval(interval); return 0 }
          return prev - 1
        })
      }, 1000)
      return () => clearInterval(interval)
    }
  }, [blocked])

  useEffect(() => { inputRefs.current[0]?.focus() }, [])

  useEffect(() => {
    const updateTime = () => {
      const now = new Date()
      const brasiliaStr = now.toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit", second: "2-digit" })
      setBrasiliaTime(brasiliaStr)
    }
    updateTime()
    const interval = setInterval(updateTime, 1000)
    return () => clearInterval(interval)
  }, [])

  const handleInput = (index: number, value: string) => {
    if (blocked) return
    if (!/^\d?$/.test(value)) return
    const newPin = [...pin]
    newPin[index] = value
    setPin(newPin)
    setError("")
    if (value && index < 5) inputRefs.current[index + 1]?.focus()
    if (newPin.every((d) => d !== "") && index === 5) {
      const entered = newPin.join("")
      if (entered === CORRECT_PIN) {
        setIsAuthenticated(true)
      } else {
        const newAttempts = attempts + 1
        setAttempts(newAttempts)
        if (newAttempts >= MAX_ATTEMPTS) {
          setBlocked(true)
          setBlockTimer(BLOCK_TIME / 1000)
          setError(t("auth.blocked", locale))
        } else { setError(t("auth.error", locale)) }
        setPin(["", "", "", "", "", ""])
        setTimeout(() => inputRefs.current[0]?.focus(), 100)
      }
    }
  }

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !pin[index] && index > 0) inputRefs.current[index - 1]?.focus()
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row" style={{ background: "hsl(220 15% 4%)" }}>
      {/* Left side - Robot Image Hero */}
      <div className="relative flex-1 min-h-[40vh] lg:min-h-screen flex items-center justify-center overflow-hidden">
        {/* Animated background glows */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[700px] rounded-full animate-pulse-slow" style={{ background: "radial-gradient(circle, hsl(180 100% 50% / 0.1) 0%, transparent 70%)" }} />
          <div className="absolute bottom-0 left-1/4 w-[500px] h-[500px] rounded-full animate-pulse-slow" style={{ background: "radial-gradient(circle, hsl(45 100% 50% / 0.06) 0%, transparent 70%)", animationDelay: "1s" }} />
          <div className="absolute top-1/3 right-0 w-[400px] h-[400px] rounded-full animate-pulse-slow" style={{ background: "radial-gradient(circle, hsl(180 100% 50% / 0.04) 0%, transparent 70%)", animationDelay: "2s" }} />
        </div>

        {/* Scan lines overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.02]" style={{ backgroundImage: "repeating-linear-gradient(0deg, transparent, transparent 2px, hsl(180 100% 50%) 2px, transparent 4px)" }} />

        {/* Grid pattern */}
        <div className="absolute inset-0 pointer-events-none opacity-[0.03]" style={{ backgroundImage: "linear-gradient(hsl(180 100% 50% / 0.3) 1px, transparent 1px), linear-gradient(90deg, hsl(180 100% 50% / 0.3) 1px, transparent 1px)", backgroundSize: "40px 40px" }} />

        {/* Robot Image */}
        <div className="relative z-10 w-64 h-80 md:w-96 md:h-[480px] lg:w-[440px] lg:h-[580px]">
          <div className="absolute -inset-6 rounded-3xl animate-glow-pulse" style={{ background: "linear-gradient(135deg, hsl(180 100% 50% / 0.12) 0%, transparent 40%, hsl(45 100% 50% / 0.08) 100%)", filter: "blur(2px)" }} />
          <div className="relative w-full h-full rounded-2xl overflow-hidden border-2" style={{ borderColor: "hsl(180 100% 50% / 0.25)", boxShadow: "0 0 100px hsl(180 100% 50% / 0.2), 0 0 200px hsl(180 100% 50% / 0.08), inset 0 0 60px hsl(180 100% 50% / 0.04)" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="/images/dommo-robot.jpg"
              alt="DOMMO CORE - Sentinel AI"
              className="w-full h-full object-cover"
            />
            {/* Gradient overlays */}
            <div className="absolute inset-0" style={{ background: "linear-gradient(to top, hsl(220 15% 4%) 0%, hsl(220 15% 4% / 0.5) 12%, transparent 35%)" }} />
            <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, hsl(220 15% 4% / 0.3) 0%, transparent 20%)" }} />

            {/* Cyan energy line at top */}
            <div className="absolute top-0 left-0 right-0 h-[2px]" style={{ background: "linear-gradient(90deg, transparent 0%, hsl(180 100% 50%) 50%, transparent 100%)", boxShadow: "0 0 30px hsl(180 100% 50% / 0.6)" }} />

            {/* Status indicators */}
            <div className="absolute top-4 left-4 flex items-center gap-2">
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: "hsl(220 15% 4% / 0.85)", backdropFilter: "blur(12px)", border: "1px solid hsl(180 100% 50% / 0.25)" }}>
                <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "hsl(142 71% 45%)", boxShadow: "0 0 8px hsl(142 71% 45% / 0.5)" }} />
                <span className="text-[9px] font-mono tracking-[0.3em] font-bold" style={{ color: "hsl(142 71% 45%)" }}>ONLINE</span>
              </div>
            </div>

            <div className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1.5 rounded-full" style={{ background: "hsl(220 15% 4% / 0.85)", backdropFilter: "blur(12px)", border: "1px solid hsl(180 100% 50% / 0.25)" }}>
              <Activity className="w-3 h-3" style={{ color: "hsl(180 100% 50%)" }} />
              <span className="text-[9px] font-mono tracking-[0.25em] font-bold" style={{ color: "hsl(180 100% 50%)" }}>SENTINEL</span>
            </div>

            {/* AI Models running indicator */}
            <div className="absolute left-4 top-14 flex flex-col gap-1.5">
              {["NeuralFreq", "BayesianNet", "CertusV2", "MegaFreqMaster", "DeepSentinel"].map((model, i) => (
                <div key={model} className="flex items-center gap-1.5 px-2 py-1 rounded-md" style={{ background: "hsl(220 15% 4% / 0.75)", backdropFilter: "blur(8px)" }}>
                  <div className="w-1 h-1 rounded-full animate-pulse" style={{ background: "hsl(180 100% 50%)", animationDelay: `${i * 0.3}s` }} />
                  <span className="text-[7px] font-mono tracking-wider" style={{ color: "hsl(180 100% 50% / 0.7)" }}>{model}</span>
                </div>
              ))}
            </div>

            {/* Robot label at bottom */}
            <div className="absolute bottom-0 left-0 right-0 p-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-mono tracking-[0.35em] uppercase font-bold" style={{ color: "hsl(180 100% 50% / 0.9)" }}>DOMMO AI</p>
                  <p className="text-[9px] font-mono mt-0.5" style={{ color: "hsl(220 10% 50%)" }}>v3.0 // 185 AI ENGINES</p>
                </div>
                <div className="flex items-center gap-2">
                  <Brain className="w-4 h-4 animate-pulse" style={{ color: "hsl(180 100% 50% / 0.7)" }} />
                  <Zap className="w-4 h-4 animate-pulse" style={{ color: "hsl(45 100% 50%)", animationDelay: "0.5s" }} />
                </div>
              </div>
            </div>
          </div>

          {/* Corner accents */}
          <div className="absolute -top-2 -left-2 w-8 h-8 border-t-2 border-l-2 rounded-tl-lg" style={{ borderColor: "hsl(180 100% 50% / 0.5)" }} />
          <div className="absolute -top-2 -right-2 w-8 h-8 border-t-2 border-r-2 rounded-tr-lg" style={{ borderColor: "hsl(180 100% 50% / 0.5)" }} />
          <div className="absolute -bottom-2 -left-2 w-8 h-8 border-b-2 border-l-2 rounded-bl-lg" style={{ borderColor: "hsl(45 100% 50% / 0.4)" }} />
          <div className="absolute -bottom-2 -right-2 w-8 h-8 border-b-2 border-r-2 rounded-br-lg" style={{ borderColor: "hsl(45 100% 50% / 0.4)" }} />
        </div>
      </div>

      {/* Right side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md flex flex-col items-center gap-8">
          {/* Title */}
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-3">
              <Cpu className="w-6 h-6" style={{ color: "hsl(180 100% 50% / 0.5)" }} />
              <h1 className="text-4xl lg:text-5xl font-bold tracking-[0.25em]" style={{ color: "hsl(180 100% 50%)", textShadow: "0 0 40px hsl(180 100% 50% / 0.4), 0 0 80px hsl(180 100% 50% / 0.15)" }}>
                DOMMO
              </h1>
              <Cpu className="w-6 h-6" style={{ color: "hsl(180 100% 50% / 0.5)" }} />
            </div>
            <p className="text-lg font-bold tracking-[0.5em] uppercase" style={{ color: "hsl(45 100% 50%)", textShadow: "0 0 20px hsl(45 100% 50% / 0.3)" }}>
              CORE
            </p>
            <div className="flex items-center justify-center gap-3 mt-4">
              <div className="h-[1px] flex-1" style={{ background: "linear-gradient(90deg, transparent, hsl(180 100% 50% / 0.4))" }} />
              <p className="text-[10px] tracking-[0.5em] uppercase font-bold" style={{ color: "hsl(45 100% 50%)" }}>
                {t("app.slogan", locale)}
              </p>
              <div className="h-[1px] flex-1" style={{ background: "linear-gradient(270deg, transparent, hsl(45 100% 50% / 0.4))" }} />
            </div>
            <p className="text-xs mt-2 tracking-wide" style={{ color: "hsl(220 10% 50%)" }}>
              {t("app.subtitle", locale)}
            </p>
          </div>

          {/* Brasilia Time */}
          <div className="flex items-center gap-2 px-4 py-2 rounded-full" style={{ background: "hsl(220 15% 7%)", border: "1px solid hsl(220 10% 14%)" }}>
            <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "hsl(180 100% 50%)" }} />
            <span className="text-[10px] font-mono tracking-wider" style={{ color: "hsl(180 100% 50% / 0.7)" }}>
              BRASILIA {brasiliaTime}
            </span>
          </div>

          {/* PIN Card */}
          <div className="w-full rounded-2xl p-8 border" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 12%)", boxShadow: "0 0 80px hsl(220 15% 4% / 0.8), inset 0 1px 0 hsl(220 10% 14%)" }}>
            <div className="flex items-center justify-center gap-2 mb-6">
              <div className="p-2.5 rounded-xl" style={{ background: "hsl(180 100% 50% / 0.08)", border: "1px solid hsl(180 100% 50% / 0.15)" }}>
                <Shield className="w-5 h-5" style={{ color: "hsl(180 100% 50%)" }} />
              </div>
              <span className="text-sm font-bold tracking-[0.2em] uppercase" style={{ color: "hsl(200 20% 90%)" }}>
                {t("auth.title", locale)}
              </span>
            </div>

            <p className="text-center text-xs mb-8" style={{ color: "hsl(220 10% 50%)" }}>
              {t("auth.subtitle", locale)}
            </p>

            {/* Invisible PIN - only dots show where filled */}
            <div className="flex justify-center gap-4 mb-8">
              {pin.map((digit, i) => (
                <div key={i} className="relative">
                  <input
                    ref={(el) => { inputRefs.current[i] = el }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleInput(i, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(i, e)}
                    disabled={blocked}
                    className="w-12 h-14 text-center text-transparent caret-transparent rounded-xl border-2 outline-none transition-all disabled:opacity-50 select-none"
                    style={{
                      background: digit ? "hsl(180 100% 50% / 0.06)" : "hsl(220 15% 8%)",
                      borderColor: digit ? "hsl(180 100% 50%)" : "hsl(220 10% 18%)",
                      boxShadow: digit ? "0 0 20px hsl(180 100% 50% / 0.2), inset 0 0 15px hsl(180 100% 50% / 0.06)" : "none",
                    }}
                    aria-label={`PIN digit ${i + 1}`}
                    autoComplete="off"
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    {digit ? (
                      <div className="w-3 h-3 rounded-full" style={{ background: "hsl(180 100% 50%)", boxShadow: "0 0 10px hsl(180 100% 50% / 0.5)" }} />
                    ) : (
                      <div className="w-2 h-2 rounded-full" style={{ background: "hsl(220 10% 22%)" }} />
                    )}
                  </div>
                </div>
              ))}
            </div>

            {error && (
              <div className="flex items-center justify-center gap-2 text-xs p-3 rounded-xl mb-4" style={{ background: "hsl(0 72% 51% / 0.08)", color: "hsl(0 72% 60%)", border: "1px solid hsl(0 72% 51% / 0.2)" }}>
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span>{error}</span>
                {blocked && <span className="font-mono ml-1">{blockTimer}s</span>}
              </div>
            )}

            {!error && (
              <div className="flex items-center justify-center gap-2 text-xs" style={{ color: "hsl(220 10% 35%)" }}>
                <Lock className="w-3 h-3" />
                <span className="font-mono">{`${attempts}/${MAX_ATTEMPTS}`}</span>
              </div>
            )}
          </div>

          {/* Status bar */}
          <div className="flex items-center gap-6 text-[9px] tracking-[0.25em] uppercase" style={{ color: "hsl(220 10% 28%)" }}>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: "hsl(142 71% 45%)" }} />
              <span>SECURE</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: "hsl(180 100% 50%)" }} />
              <span>AES-256</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: "hsl(45 100% 50%)" }} />
              <span>185 AI ENGINES</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
