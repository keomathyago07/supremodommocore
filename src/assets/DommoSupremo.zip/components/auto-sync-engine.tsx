"use client"

import { useEffect, useRef, useCallback } from "react"
import { getTodayLotteries } from "@/lib/lottery-config"

function getDeviceId(): string {
  if (typeof window === "undefined") return "server"
  let id = localStorage.getItem("dommo_device_id")
  if (!id) {
    id = `device-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
    localStorage.setItem("dommo_device_id", id)
  }
  return id
}

function getDeviceType(): string {
  if (typeof navigator === "undefined") return "unknown"
  return /Mobi|Android/i.test(navigator.userAgent) ? "mobile" : "desktop"
}

function getBrasiliaHour(): { hour: number; minute: number } {
  const now = new Date()
  const brasiliaStr = now.toLocaleString("en-US", { timeZone: "America/Sao_Paulo", hour12: false, hour: "2-digit", minute: "2-digit" })
  const [h, m] = brasiliaStr.split(":").map(Number)
  return { hour: h, minute: m }
}

async function sendNotification(title: string, body: string) {
  if (typeof window === "undefined") return
  if (!("Notification" in window)) return
  if (Notification.permission === "default") {
    await Notification.requestPermission()
  }
  if (Notification.permission === "granted") {
    new Notification(title, {
      body,
      icon: "/images/dommo-robot.jpg",
      badge: "/images/dommo-robot.jpg",
      tag: `dommo-${Date.now()}`,
      vibrate: [200, 100, 200],
    })
  }
}

export function AutoSyncEngine() {
  const syncIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const notifCheckRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const drawCheckRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const lastNotifDateRef = useRef<string>("")
  const lastSyncHashRef = useRef<string>("")
  const drawCheckDoneRef = useRef<string>("")
  const postDrawCheckDoneRef = useRef<string>("")

  // Automatic device sync - runs every 30 seconds
  const performDeviceSync = useCallback(async () => {
    try {
      const deviceId = getDeviceId()
      const deviceType = getDeviceType()
      const locale = localStorage.getItem("dommo_locale") || "pt-BR"
      const activeView = localStorage.getItem("dommo_last_view") || "dashboard"

      await fetch("/api/lottery/device-sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          device_id: deviceId,
          device_name: navigator.userAgent.slice(0, 80),
          device_type: deviceType,
          sync_data: {
            last_sync: new Date().toISOString(),
            locale,
            active_view: activeView,
            screen_width: window.innerWidth,
            screen_height: window.innerHeight,
            online: navigator.onLine,
            today_lotteries: getTodayLotteries().map(l => l.id),
          },
        }),
      })

      // Pull latest sync data from other devices
      const res = await fetch("/api/lottery/device-sync")
      const data = await res.json()
      const devices = data.devices || []
      const newHash = JSON.stringify(devices.map((d: { device_id: string; last_sync_at: string }) => `${d.device_id}-${d.last_sync_at}`))

      if (lastSyncHashRef.current && lastSyncHashRef.current !== newHash) {
        window.dispatchEvent(new CustomEvent("dommo-sync-update", { detail: { devices } }))
      }
      lastSyncHashRef.current = newHash
    } catch { /* silent */ }
  }, [])

  // Check notifications time
  const checkNotificationTime = useCallback(async () => {
    try {
      const notifHour = localStorage.getItem("dommo_notif_hour") || "10"
      const notifMinute = localStorage.getItem("dommo_notif_minute") || "00"
      const now = new Date()
      const currentHour = now.getHours()
      const currentMinute = now.getMinutes()
      const targetHour = parseInt(notifHour)
      const targetMinute = parseInt(notifMinute)
      const todayKey = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}`

      if (lastNotifDateRef.current === todayKey) return

      if (currentHour > targetHour || (currentHour === targetHour && currentMinute >= targetMinute)) {
        const todayLotteries = getTodayLotteries()

        if (todayLotteries.length > 0) {
          const lotteryNames = todayLotteries.map(l => l.displayName).join(", ")
          const locale = localStorage.getItem("dommo_locale") || "pt-BR"

          await sendNotification(
            "DOMMO CORE - Loterias do Dia",
            locale === "pt-BR"
              ? `${todayLotteries.length} loterias com sorteio hoje as 21h: ${lotteryNames}. Confira as sugestoes!`
              : `${todayLotteries.length} lotteries drawing today at 9PM: ${lotteryNames}. Check suggestions!`
          )

          try {
            const res = await fetch("/api/lottery/confidence-log")
            const data = await res.json()
            const todayLogs = (data.logs || []).filter((log: { gate_status: string; year: number; month: number; day: number; lottery_id: string }) => {
              return log.gate_status === "APPROVED" && log.year === now.getFullYear() && log.month === now.getMonth() + 1 && log.day === now.getDate() && log.lottery_id !== "system"
            })

            if (todayLogs.length > 0) {
              const approvedNames = todayLogs.map((l: { lottery_name: string }) => l.lottery_name).join(", ")
              await sendNotification(
                "DOMMO CORE - Gate Aprovado!",
                locale === "pt-BR"
                  ? `${todayLogs.length} loteria(s) atingiu o gate de confianca: ${approvedNames}`
                  : `${todayLogs.length} lottery(ies) hit the confidence gate: ${approvedNames}`
              )
            }
          } catch { /* silent */ }

          lastNotifDateRef.current = todayKey
        }
      }
    } catch { /* silent */ }
  }, [])

  // Draw time check - runs every 30 seconds to detect 21:00 Brasilia time
  const checkDrawTime = useCallback(async () => {
    try {
      const { hour, minute } = getBrasiliaHour()
      const now = new Date()
      const todayKey = `${now.getFullYear()}-${now.getMonth()}-${now.getDate()}`
      const locale = localStorage.getItem("dommo_locale") || "pt-BR"
      const todayLotteries = getTodayLotteries()

      if (todayLotteries.length === 0) return

      // 21:00 notification
      if (hour === 21 && minute <= 2 && drawCheckDoneRef.current !== todayKey) {
        drawCheckDoneRef.current = todayKey
        await sendNotification(
          "DOMMO CORE - Sorteio Agora!",
          locale === "pt-BR"
            ? `Os sorteios estao acontecendo agora as 21:00h (Brasilia)! ${todayLotteries.map(l => l.displayName).join(", ")}`
            : `Draws are happening now at 9:00 PM (Brasilia)! ${todayLotteries.map(l => l.displayName).join(", ")}`
        )
      }

      // 21:30 - Auto-check results with detailed notification
      if (hour === 21 && minute >= 30 && minute <= 35 && postDrawCheckDoneRef.current !== todayKey) {
        postDrawCheckDoneRef.current = todayKey
        const token = localStorage.getItem("dommo_api_token")
        if (!token) return

        try {
          const res = await fetch("/api/lottery/check-results", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ token }),
          })
          const data = await res.json()

          if (data.results && data.results.length > 0) {
            const winners = data.results.filter((r: { is_winner: boolean }) => r.is_winner)
            const totalChecked = data.results.length

            if (winners.length > 0) {
              // Winner notification with details
              for (const w of winners) {
                await sendNotification(
                  `DOMMO CORE - PREMIACAO! ${w.lottery_name}`,
                  locale === "pt-BR"
                    ? `Concurso #${w.contest_number} | ${w.matches} acertos! | ${w.prize_tier} | Numeros apostados: ${w.bet_numbers.join(",")} | Sorteados: ${w.drawn_numbers.join(",")}`
                    : `Contest #${w.contest_number} | ${w.matches} hits! | ${w.prize_tier} | Bet numbers: ${w.bet_numbers.join(",")} | Drawn: ${w.drawn_numbers.join(",")}`
                )
              }
            }

            // Summary notification
            const details = data.results.map((r: { lottery_name: string; matches: number; contest_number: number }) =>
              `${r.lottery_name}: ${r.matches} acertos (#${r.contest_number})`
            ).join(" | ")

            await sendNotification(
              locale === "pt-BR" ? "DOMMO CORE - Resultados Verificados" : "DOMMO CORE - Results Checked",
              locale === "pt-BR"
                ? `${totalChecked} aposta(s) conferida(s). ${winners.length > 0 ? `${winners.length} PREMIACAO(OES)!` : "Nenhuma premiacao."} Detalhes: ${details}`
                : `${totalChecked} bet(s) checked. ${winners.length > 0 ? `${winners.length} PRIZE(S)!` : "No prizes."} Details: ${details}`
            )
          } else {
            await sendNotification(
              locale === "pt-BR" ? "DOMMO CORE - Conferencia" : "DOMMO CORE - Check",
              locale === "pt-BR"
                ? "Verificacao automatica pos-sorteio concluida. Nenhuma aposta pendente."
                : "Auto post-draw check completed. No pending bets."
            )
          }
        } catch {
          await sendNotification(
            "DOMMO CORE",
            locale === "pt-BR"
              ? "Erro na verificacao automatica. Tente verificar manualmente."
              : "Error in auto-check. Try checking manually."
          )
        }
      }

      // 22:00 - Second check for late results
      if (hour === 22 && minute <= 5) {
        const secondCheckKey = `${todayKey}-second`
        if (postDrawCheckDoneRef.current !== secondCheckKey) {
          postDrawCheckDoneRef.current = secondCheckKey
          const token = localStorage.getItem("dommo_api_token")
          if (token) {
            try {
              await fetch("/api/lottery/check-results", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ token }),
              })
            } catch { /* silent retry */ }
          }
        }
      }
    } catch { /* silent */ }
  }, [])

  // Request notification permission on mount
  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "default") {
      Notification.requestPermission()
    }
  }, [])

  // Start auto-sync engine
  useEffect(() => {
    performDeviceSync()
    checkNotificationTime()
    checkDrawTime()

    // Auto sync every 30 seconds
    syncIntervalRef.current = setInterval(performDeviceSync, 30000)

    // Check notifications every minute
    notifCheckRef.current = setInterval(checkNotificationTime, 60000)

    // Check draw time every 30 seconds (critical for 21:00 detection)
    drawCheckRef.current = setInterval(checkDrawTime, 30000)

    const handleVisibility = () => {
      if (!document.hidden) {
        performDeviceSync()
        checkNotificationTime()
        checkDrawTime()
      }
    }
    document.addEventListener("visibilitychange", handleVisibility)

    const handleOnline = () => {
      performDeviceSync()
      checkDrawTime()
    }
    window.addEventListener("online", handleOnline)

    const handleViewChange = () => {
      const view = document.querySelector("[data-active-view]")?.getAttribute("data-active-view")
      if (view) localStorage.setItem("dommo_last_view", view)
    }
    const observer = new MutationObserver(handleViewChange)
    observer.observe(document.body, { subtree: true, attributes: true, attributeFilter: ["data-active-view"] })

    return () => {
      if (syncIntervalRef.current) clearInterval(syncIntervalRef.current)
      if (notifCheckRef.current) clearInterval(notifCheckRef.current)
      if (drawCheckRef.current) clearInterval(drawCheckRef.current)
      document.removeEventListener("visibilitychange", handleVisibility)
      window.removeEventListener("online", handleOnline)
      observer.disconnect()
    }
  }, [performDeviceSync, checkNotificationTime, checkDrawTime])

  return null
}
