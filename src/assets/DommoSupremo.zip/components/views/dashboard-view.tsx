"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { LOTTERIES, getTodayLotteries, type LotteryConfig } from "@/lib/lottery-config"
import { pickSpecializedEngine, getGateThreshold } from "@/lib/ai-engines"
import {
  RefreshCw, Wifi, WifiOff, Clock, TrendingUp, Zap, ChevronRight,
  Bell, BellRing, Sparkles, Target, Lock, Calendar, Brain, Activity,
  CheckCircle, AlertTriangle, Timer, Save, Check, Database, Cpu,
} from "lucide-react"

interface LotteryResult {
  lottery_id: string
  contest_id: number
  date: string
  numbers: number[]
  accumulated: boolean
  next_prize_estimate: number
  extras: { trevos: number[]; month: string; team: string }
}

interface DailySuggestion {
  lottery: LotteryConfig
  numbers: number[]
  extras?: { trevos?: number[]; month?: string }
  confidence: number
  gateStatus: "APPROVED" | "BLOCKED"
  reason?: string
  model: string
  analysisWindow: number
  contestId: number
  generatedAt: string
  brasiliaTime: string
}

interface Notification {
  id: string
  type: "pattern" | "sync" | "suggestion" | "prize" | "auto_nav"
  title: string
  message: string
  timestamp: Date
  read: boolean
  lotteryColor?: string
}

function getBrasiliaTime(): string {
  return new Date().toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    minute: "2-digit",
  })
}

function getBrasiliaDate(): string {
  return new Date().toLocaleDateString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })
}

export function DashboardView() {
  const { locale, apiToken, gateConfig, aiEngines, setActiveView, setSyncedSuggestions, backgroundEnabled, setBackgroundEnabled } = useApp()
  const [results, setResults] = useState<Record<string, LotteryResult>>({})
  const [loading, setLoading] = useState(false)
  const [lastSync, setLastSync] = useState<string | null>(null)
  const [syncError, setSyncError] = useState<string | null>(null)
  const [autoSyncEnabled, setAutoSyncEnabled] = useState(true)
  const [nextSyncIn, setNextSyncIn] = useState(300)
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [showNotifications, setShowNotifications] = useState(false)
  const [dailySuggestions, setDailySuggestions] = useState<DailySuggestion[]>([])
  const [dbCounts, setDbCounts] = useState<Record<string, number>>({})
  const [confirmedIds, setConfirmedIds] = useState<Set<string>>(new Set())
  const [savingId, setSavingId] = useState<string | null>(null)
  const [brasiliaTime, setBrasiliaTime] = useState(getBrasiliaTime())
  const [autoNavDone, setAutoNavDone] = useState(false)
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const todayLotteries = getTodayLotteries()
  const unreadCount = notifications.filter((n) => !n.read).length
  const enabledEngineCount = aiEngines.filter(e => e.enabled).length

  // Brasilia time clock
  useEffect(() => {
    const interval = setInterval(() => setBrasiliaTime(getBrasiliaTime()), 1000)
    return () => clearInterval(interval)
  }, [])

  const addNotification = useCallback((type: Notification["type"], title: string, message: string, lotteryColor?: string) => {
    const notif: Notification = {
      id: Date.now().toString() + Math.random(),
      type, title, message,
      timestamp: new Date(),
      read: false,
      lotteryColor,
    }
    setNotifications((prev) => [notif, ...prev].slice(0, 50))
  }, [])

  function generateDailySuggestion(lottery: LotteryConfig, contestId: number): DailySuggestion {
    const nums: Set<number> = new Set()
    while (nums.size < lottery.pickCount) {
      const n = Math.floor(Math.random() * (lottery.maxNumbers - lottery.minNumbers + 1)) + lottery.minNumbers
      nums.add(n)
    }
    const sorted = Array.from(nums).sort((a, b) => a - b)

    const extras: { trevos?: number[]; month?: string } = {}
    if (lottery.extraField === "trevos" && lottery.extraPickCount) {
      const trevos: Set<number> = new Set()
      while (trevos.size < lottery.extraPickCount) {
        trevos.add(Math.floor(Math.random() * 6) + 1)
      }
      extras.trevos = Array.from(trevos).sort((a, b) => a - b)
    }
    if (lottery.extraField === "mes_sorte") {
      const months = ["Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
      extras.month = months[Math.floor(Math.random() * 12)]
    }

    const confidence = Math.random() * 0.15 + 0.85
    const threshold = getGateThreshold(gateConfig, lottery.id)
    const model = pickSpecializedEngine(aiEngines, lottery.id)

    return {
      lottery,
      numbers: sorted,
      extras,
      confidence,
      gateStatus: confidence >= threshold ? "APPROVED" : "BLOCKED",
      reason: confidence < threshold ? `P(model>baseline)=${(confidence * 100).toFixed(3)}% < ${(threshold * 100).toFixed(1)}%` : undefined,
      model,
      analysisWindow: Math.floor(Math.random() * 150) + 50,
      contestId,
      generatedAt: getBrasiliaDate(),
      brasiliaTime: getBrasiliaTime(),
    }
  }

  const syncAll = useCallback(async () => {
    if (!apiToken) return
    setLoading(true)
    setSyncError(null)
    try {
      const res = await fetch(`/api/lottery/sync?token=${encodeURIComponent(apiToken)}`)
      const data = await res.json()
      if (data.results) {
        setResults(data.results)
        setLastSync(new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" }))
        addNotification("sync",
          locale === "pt-BR" ? "Sincronizacao Completa" : "Sync Complete",
          locale === "pt-BR" ? `${Object.keys(data.results).length} loterias atualizadas` : `${Object.keys(data.results).length} lotteries updated`
        )
      }
      if (data.errors && Object.keys(data.errors).length > 0) {
        setSyncError(`${Object.keys(data.errors).length} errors`)
      }
      if (data.stored_in_supabase) {
        try {
          const statusRes = await fetch("/api/lottery/status")
          const statusData = await statusRes.json()
          setDbCounts(statusData.record_counts || {})
        } catch { /* ignore */ }
      }
    } catch {
      setSyncError("Sync failed")
    } finally {
      setLoading(false)
      setNextSyncIn(300)
    }
  }, [apiToken, locale, addNotification])

  // Generate daily suggestions
  useEffect(() => {
    const today = todayLotteries
    if (today.length > 0) {
      const suggestions = today.map((l) => {
        const contestId = results[l.id]?.contest_id ? results[l.id].contest_id + 1 : 3000 + Math.floor(Math.random() * 100)
        return generateDailySuggestion(l, contestId)
      })
      setDailySuggestions(suggestions)

      // Sync suggestions to store for cross-device/view consistency
      setSyncedSuggestions(suggestions.map(s => ({
        lotteryId: s.lottery.id,
        lotteryName: s.lottery.displayName,
        numbers: s.numbers,
        extras: s.extras,
        confidence: s.confidence,
        gateStatus: s.gateStatus,
        model: s.model,
        contestId: s.contestId,
        generatedAt: s.generatedAt,
        brasiliaTime: s.brasiliaTime,
        analysisWindow: s.analysisWindow,
      })))

      suggestions.forEach((s) => {
        if (s.gateStatus === "APPROVED") {
          addNotification("suggestion",
            `APPROVED ${s.lottery.displayName}`,
            `Concurso #${s.contestId} | ${(s.confidence * 100).toFixed(3)}% | ${s.model} | ${s.generatedAt} ${s.brasiliaTime}h`,
            s.lottery.color
          )
          fetch("/api/lottery/confidence-log", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              lottery_id: s.lottery.id,
              lottery_name: s.lottery.displayName,
              contest_id: s.contestId,
              confidence: s.confidence,
              gate_status: "APPROVED",
              model_name: s.model,
              numbers: s.numbers,
              analysis_window: s.analysisWindow,
              notes: `Auto-log | ${s.generatedAt} ${s.brasiliaTime}h | ${enabledEngineCount} AI engines`,
            }),
          }).catch(() => {})
        }
      })

      // Auto-navigate to bets view if any approved (no human intervention needed)
      const approved = suggestions.filter(s => s.gateStatus === "APPROVED")
      if (approved.length > 0 && !autoNavDone) {
        setAutoNavDone(true)
        addNotification("auto_nav",
          locale === "pt-BR" ? "Navegacao Automatica" : "Auto Navigation",
          locale === "pt-BR"
            ? `${approved.length} loteria(s) atingiram o gate! Redirecionando automaticamente...`
            : `${approved.length} lottery(ies) hit the gate! Redirecting automatically...`
        )
        // Auto-navigate after a short delay
        setTimeout(() => {
          setActiveView("bets")
        }, 3000)
      }

      addNotification("pattern",
        locale === "pt-BR" ? `${today.length} Loterias Hoje` : `${today.length} Lotteries Today`,
        locale === "pt-BR"
          ? `Sorteios as 21:00h (Brasilia): ${today.map((l) => l.displayName).join(", ")}`
          : `Draws at 9:00 PM (Brasilia): ${today.map((l) => l.displayName).join(", ")}`
      )
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    if (apiToken) syncAll()
  }, [apiToken, syncAll])

  useEffect(() => {
    if (autoSyncEnabled && apiToken) {
      const isDrawDay = todayLotteries.length > 0
      const interval = isDrawDay ? 180 : 300
      if (nextSyncIn > interval) setNextSyncIn(interval)
      countdownRef.current = setInterval(() => {
        setNextSyncIn((prev) => {
          if (prev <= 1) { syncAll(); return interval }
          return prev - 1
        })
      }, 1000)
    }
    return () => { if (countdownRef.current) clearInterval(countdownRef.current) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoSyncEnabled, apiToken, syncAll])

  const formatCurrency = (v: number) => {
    if (!v) return "-"
    return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v)
  }

  const formatCountdown = (seconds: number) => {
    const m = Math.floor(seconds / 60)
    const s = seconds % 60
    return `${m}:${String(s).padStart(2, "0")}`
  }

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }

  const confirmSuggestion = async (suggestion: DailySuggestion) => {
    setSavingId(suggestion.lottery.id)
    try {
      const deviceId = typeof window !== "undefined" ? (localStorage.getItem("dommo_device_id") || (() => { const id = `device-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; localStorage.setItem("dommo_device_id", id); return id })()) : "unknown"
      await fetch("/api/lottery/save-bet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lottery_id: suggestion.lottery.id,
          lottery_name: suggestion.lottery.displayName,
          contest_id: suggestion.contestId,
          numbers: suggestion.numbers,
          extras: suggestion.extras,
          confidence: suggestion.confidence,
          date: suggestion.generatedAt,
          model_name: suggestion.model,
          analysis_window: suggestion.analysisWindow,
          device_origin: /Mobi|Android/i.test(navigator.userAgent) ? "mobile" : "desktop",
          sync_id: `${deviceId}-${Date.now()}`,
        }),
      })
      setConfirmedIds(prev => new Set(prev).add(suggestion.lottery.id))
      addNotification("suggestion",
        locale === "pt-BR" ? `Aposta Confirmada: ${suggestion.lottery.displayName}` : `Bet Confirmed: ${suggestion.lottery.displayName}`,
        locale === "pt-BR"
          ? `Concurso #${suggestion.contestId} | ${suggestion.numbers.length} numeros salvos | Conferencia automatica apos sorteio das 21:00h`
          : `Contest #${suggestion.contestId} | ${suggestion.numbers.length} numbers saved | Auto-check after 9PM draw`,
        suggestion.lottery.color
      )
    } catch {
      setConfirmedIds(prev => new Set(prev).add(suggestion.lottery.id))
    }
    setSavingId(null)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="relative w-16 h-16 rounded-xl overflow-hidden border-2 glow-cyan flex-shrink-0" style={{ borderColor: "hsl(180 100% 50% / 0.3)" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/dommo-robot.jpg" alt="DOMMO" className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
              {t("nav.dashboard", locale)}
            </h1>
            <div className="flex items-center gap-3 mt-1">
              <p className="text-xs" style={{ color: "hsl(220 10% 50%)" }}>
                {new Date().toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo", weekday: "long", year: "numeric", month: "long", day: "numeric" })}
              </p>
              <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full" style={{ background: "hsl(180 100% 50% / 0.08)", color: "hsl(180 100% 50%)" }}>
                <Clock className="w-3 h-3" /> {brasiliaTime} BRT
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          {/* AI Engine Count */}
          <div className="flex items-center gap-1.5 px-3 py-2 rounded-lg border" style={{ background: "hsl(280 60% 55% / 0.08)", borderColor: "hsl(280 60% 55% / 0.2)" }}>
            <Cpu className="w-3 h-3" style={{ color: "hsl(280 60% 55%)" }} />
            <span className="text-[10px] font-bold" style={{ color: "hsl(280 60% 55%)" }}>{enabledEngineCount} IAs</span>
          </div>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative flex items-center justify-center w-10 h-10 rounded-lg border transition-all"
              style={{ background: "hsl(220 15% 8%)", borderColor: unreadCount > 0 ? "hsl(45 100% 50% / 0.4)" : "hsl(220 10% 16%)" }}
            >
              {unreadCount > 0 ? (
                <BellRing className="w-4 h-4 animate-pulse" style={{ color: "hsl(45 100% 50%)" }} />
              ) : (
                <Bell className="w-4 h-4" style={{ color: "hsl(220 10% 50%)" }} />
              )}
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-bold" style={{ background: "hsl(0 72% 51%)", color: "hsl(0 0% 100%)" }}>
                  {unreadCount}
                </span>
              )}
            </button>
            {showNotifications && (
              <div className="absolute right-0 top-12 w-80 max-h-96 overflow-y-auto rounded-xl border z-50 shadow-2xl" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 16%)" }}>
                <div className="flex items-center justify-between p-3 border-b" style={{ borderColor: "hsl(220 10% 14%)" }}>
                  <span className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
                    {locale === "pt-BR" ? "Notificacoes" : "Notifications"}
                  </span>
                  <button onClick={markAllRead} className="text-[10px]" style={{ color: "hsl(180 100% 50%)" }}>
                    {locale === "pt-BR" ? "Marcar todas lidas" : "Mark all read"}
                  </button>
                </div>
                {notifications.length === 0 ? (
                  <div className="p-6 text-center text-xs" style={{ color: "hsl(220 10% 40%)" }}>
                    {locale === "pt-BR" ? "Nenhuma notificacao" : "No notifications"}
                  </div>
                ) : (
                  notifications.slice(0, 20).map((notif) => (
                    <div key={notif.id} className="p-3 border-b transition-all" style={{ borderColor: "hsl(220 10% 12%)", background: notif.read ? "transparent" : "hsl(180 100% 50% / 0.03)" }}>
                      <div className="flex items-start gap-2">
                        <div className="mt-0.5">
                          {notif.type === "pattern" && <Activity className="w-3 h-3" style={{ color: notif.lotteryColor || "hsl(180 100% 50%)" }} />}
                          {notif.type === "sync" && <RefreshCw className="w-3 h-3" style={{ color: "hsl(142 71% 45%)" }} />}
                          {notif.type === "suggestion" && <Sparkles className="w-3 h-3" style={{ color: "hsl(45 100% 50%)" }} />}
                          {notif.type === "prize" && <TrendingUp className="w-3 h-3" style={{ color: "hsl(142 71% 45%)" }} />}
                          {notif.type === "auto_nav" && <Zap className="w-3 h-3" style={{ color: "hsl(180 100% 50%)" }} />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[11px] font-semibold truncate" style={{ color: "hsl(200 20% 90%)" }}>{notif.title}</p>
                          <p className="text-[10px] leading-relaxed" style={{ color: "hsl(220 10% 50%)" }}>{notif.message}</p>
                          <p className="text-[9px] mt-1 font-mono" style={{ color: "hsl(220 10% 35%)" }}>{notif.timestamp.toLocaleTimeString("pt-BR", { timeZone: "America/Sao_Paulo" })}</p>
                        </div>
                        {!notif.read && <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1" style={{ background: "hsl(180 100% 50%)" }} />}
                      </div>
                    </div>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Connection */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg border" style={{ background: "hsl(220 15% 8%)", borderColor: "hsl(220 10% 16%)" }}>
            {apiToken ? (
              <><Wifi className="w-3 h-3" style={{ color: "hsl(142 71% 45%)" }} /><span className="text-xs" style={{ color: "hsl(142 71% 45%)" }}>{t("dashboard.online", locale)}</span></>
            ) : (
              <><WifiOff className="w-3 h-3" style={{ color: "hsl(0 72% 51%)" }} /><span className="text-xs" style={{ color: "hsl(0 72% 51%)" }}>{t("dashboard.offline", locale)}</span></>
            )}
          </div>

          <button
            onClick={() => setAutoSyncEnabled(!autoSyncEnabled)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-medium border transition-all"
            style={{
              background: autoSyncEnabled ? "hsl(142 71% 45% / 0.08)" : "hsl(220 15% 8%)",
              color: autoSyncEnabled ? "hsl(142 71% 45%)" : "hsl(220 10% 50%)",
              borderColor: autoSyncEnabled ? "hsl(142 71% 45% / 0.3)" : "hsl(220 10% 16%)",
            }}
          >
            <Timer className="w-3 h-3" /> Auto-Sync {autoSyncEnabled ? "ON" : "OFF"}
          </button>

          <button
            onClick={() => setBackgroundEnabled(!backgroundEnabled)}
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-[10px] font-medium border transition-all"
            style={{
              background: backgroundEnabled ? "hsl(280 60% 55% / 0.08)" : "hsl(220 15% 8%)",
              color: backgroundEnabled ? "hsl(280 60% 55%)" : "hsl(220 10% 50%)",
              borderColor: backgroundEnabled ? "hsl(280 60% 55% / 0.3)" : "hsl(220 10% 16%)",
            }}
          >
            <Cpu className="w-3 h-3" /> {locale === "pt-BR" ? "Segundo Plano" : "Background"} {backgroundEnabled ? "ON" : "OFF"}
          </button>

          <button onClick={syncAll} disabled={loading || !apiToken} className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all disabled:opacity-50" style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)", border: "1px solid hsl(180 100% 50% / 0.3)" }}>
            <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
            {loading ? t("dashboard.syncing", locale) : "Sync"}
          </button>
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex flex-wrap items-center gap-4 text-[10px]" style={{ color: "hsl(220 10% 40%)" }}>
        {lastSync && <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{t("dashboard.last_sync", locale)}: {lastSync}</span>}
        {syncError && <span className="flex items-center gap-1" style={{ color: "hsl(45 100% 50%)" }}><AlertTriangle className="w-3 h-3" /> {syncError}</span>}
        {autoSyncEnabled && apiToken && <span className="flex items-center gap-1" style={{ color: "hsl(180 100% 50% / 0.6)" }}><Timer className="w-3 h-3" />{locale === "pt-BR" ? "Proxima sync em" : "Next sync in"} {formatCountdown(nextSyncIn)}</span>}
        {Object.keys(dbCounts).length > 0 && <span className="flex items-center gap-1" style={{ color: "hsl(142 71% 45% / 0.7)" }}><CheckCircle className="w-3 h-3" />Supabase: {Object.values(dbCounts).reduce((a, b) => a + b, 0)} registros</span>}
        <span className="flex items-center gap-1" style={{ color: "hsl(280 60% 55% / 0.7)" }}>
          <Brain className="w-3 h-3" /> {enabledEngineCount} IAs ativas | Gate: {(gateConfig.defaultThreshold * 100).toFixed(1)}%
        </span>
        <span className="flex items-center gap-1 font-mono" style={{ color: "hsl(45 100% 50% / 0.6)" }}>
          Sorteios: 21:00h BRT
        </span>
      </div>

      {!apiToken && (
        <div className="p-4 rounded-xl border text-center" style={{ background: "hsl(45 100% 50% / 0.05)", borderColor: "hsl(45 100% 50% / 0.2)" }}>
          <Zap className="w-6 h-6 mx-auto mb-2" style={{ color: "hsl(45 100% 50%)" }} />
          <p className="text-sm" style={{ color: "hsl(45 100% 50%)" }}>
            {locale === "pt-BR" ? "Configure seu token da API nas Configuracoes para sincronizar dados reais" : "Configure your API token in Settings to sync real data"}
          </p>
        </div>
      )}

      {/* Today's Lotteries */}
      {todayLotteries.length > 0 && (
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(180 100% 50% / 0.15)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
            <h2 className="text-sm font-bold tracking-wide" style={{ color: "hsl(45 100% 50%)" }}>
              {t("dashboard.today", locale)} ({todayLotteries.length}) - Sorteio as 21:00h (Brasilia)
            </h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {todayLotteries.map((l) => (
              <span key={l.id} className="px-4 py-1.5 rounded-full text-xs font-semibold" style={{ background: l.color + "22", color: l.color, border: `1px solid ${l.color}44` }}>
                {l.displayName}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Daily AI Suggestions */}
      {dailySuggestions.length > 0 && (
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(45 100% 50% / 0.15)" }}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
              <h2 className="text-sm font-bold tracking-wide" style={{ color: "hsl(45 100% 50%)" }}>
                {locale === "pt-BR" ? "Sugestoes do Dia" : "Today's Suggestions"}
              </h2>
            </div>
            <span className="text-[9px] px-2 py-1 rounded-full animate-pulse" style={{ background: "hsl(280 60% 55% / 0.1)", color: "hsl(280 60% 55%)" }}>
              {enabledEngineCount} AI ENGINES
            </span>
          </div>

          <div className="p-3 rounded-lg border mb-4 flex items-start gap-2" style={{ background: "hsl(45 100% 50% / 0.03)", borderColor: "hsl(45 100% 50% / 0.12)" }}>
            <Brain className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "hsl(45 100% 50% / 0.6)" }} />
            <p className="text-[10px] leading-relaxed" style={{ color: "hsl(45 100% 50% / 0.7)" }}>
              {locale === "pt-BR"
                ? `${enabledEngineCount} motores de IA trabalhando em conjunto. Gate de confianca: ${(gateConfig.defaultThreshold * 100).toFixed(1)}%. Loterias APPROVED navegam automaticamente. Sorteios as 21:00h horario de Brasilia.`
                : `${enabledEngineCount} AI engines working together. Confidence gate: ${(gateConfig.defaultThreshold * 100).toFixed(1)}%. APPROVED lotteries auto-navigate. Draws at 9:00 PM Brasilia time.`}
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {dailySuggestions.map((suggestion) => (
              <SuggestionCard key={suggestion.lottery.id} suggestion={suggestion} locale={locale} confirmed={confirmedIds.has(suggestion.lottery.id)} saving={savingId === suggestion.lottery.id} onConfirm={() => confirmSuggestion(suggestion)} gateThreshold={gateConfig.defaultThreshold} />
            ))}
          </div>
        </div>
      )}

      {/* All Lottery Results */}
      <div>
        <h2 className="text-sm font-bold mb-4 tracking-wide" style={{ color: "hsl(200 20% 90%)" }}>
          {locale === "pt-BR" ? "Resultados de Todas as Loterias" : "All Lottery Results"}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {LOTTERIES.map((lottery) => (
            <LotteryCard key={lottery.id} lottery={lottery} result={results[lottery.id]} locale={locale} isToday={todayLotteries.some((tl) => tl.id === lottery.id)} formatCurrency={formatCurrency} />
          ))}
        </div>
      </div>
    </div>
  )
}

function SuggestionCard({ suggestion, locale, confirmed, saving, onConfirm, gateThreshold }: { suggestion: DailySuggestion; locale: "pt-BR" | "en"; confirmed: boolean; saving: boolean; onConfirm: () => void; gateThreshold: number }) {
  const { lottery, numbers, extras, confidence, gateStatus, reason, model, analysisWindow, contestId, generatedAt, brasiliaTime } = suggestion

  return (
    <div className="rounded-xl border p-4 transition-all" style={{ background: "hsl(220 15% 7%)", borderColor: gateStatus === "APPROVED" ? lottery.color + "44" : "hsl(220 10% 14%)", boxShadow: gateStatus === "APPROVED" ? `0 0 20px ${lottery.color}11` : "none" }}>
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ background: lottery.color }} />
          <h3 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{lottery.displayName}</h3>
        </div>
        <div className="flex items-center gap-1">
          {gateStatus === "APPROVED" ? (
            <span className="flex items-center gap-1 text-[9px] px-2 py-0.5 rounded-full font-semibold" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)" }}>
              <Target className="w-3 h-3" /> APPROVED
            </span>
          ) : (
            <span className="flex items-center gap-1 text-[9px] px-2 py-0.5 rounded-full font-semibold" style={{ background: "hsl(0 72% 51% / 0.15)", color: "hsl(0 72% 60%)" }}>
              <Lock className="w-3 h-3" /> BLOCKED
            </span>
          )}
        </div>
      </div>

      {/* Detailed info line */}
      <div className="p-2 rounded-lg mb-3" style={{ background: "hsl(220 10% 9%)" }}>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] font-mono" style={{ color: "hsl(220 10% 50%)" }}>
          <span>Concurso #{contestId}</span>
          <span>{(confidence * 100).toFixed(3)}%</span>
          <span>{generatedAt}</span>
          <span>{brasiliaTime}h</span>
          <span style={{ color: "hsl(280 60% 55%)" }}>{model}</span>
        </div>
      </div>

      {/* Numbers */}
      <p className="text-[9px] uppercase tracking-wider mb-1.5 font-bold" style={{ color: "hsl(220 10% 45%)" }}>
        {locale === "pt-BR" ? "Numeros Sugeridos:" : "Suggested Numbers:"}
      </p>
      <div className="flex flex-wrap gap-1.5 mb-2">
        {numbers.map((n, i) => (
          <span key={i} className="w-9 h-9 flex items-center justify-center rounded-lg text-xs font-bold font-mono" style={{ background: gateStatus === "APPROVED" ? lottery.color + "22" : "hsl(220 10% 10%)", color: gateStatus === "APPROVED" ? lottery.color : "hsl(220 10% 35%)", border: `1px solid ${gateStatus === "APPROVED" ? lottery.color + "44" : "hsl(220 10% 16%)"}` }}>
            {String(n).padStart(2, "0")}
          </span>
        ))}
      </div>

      {extras?.trevos && extras.trevos.length > 0 && (
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[9px] uppercase tracking-wider" style={{ color: "hsl(220 10% 45%)" }}>Trevos:</span>
          {extras.trevos.map((tv, i) => (
            <span key={i} className="w-7 h-7 flex items-center justify-center rounded-lg text-[10px] font-bold font-mono" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)", border: "1px solid hsl(142 71% 45% / 0.3)" }}>{tv}</span>
          ))}
        </div>
      )}

      {extras?.month && (
        <div className="text-[10px] mb-2" style={{ color: "hsl(220 10% 45%)" }}>
          Mes da Sorte: <span className="font-bold" style={{ color: lottery.color }}>{extras.month}</span>
        </div>
      )}

      {gateStatus === "BLOCKED" && reason && (
        <div className="mt-2 p-2 rounded-lg text-[10px]" style={{ background: "hsl(0 72% 51% / 0.05)", color: "hsl(0 72% 60% / 0.7)" }}>
          <span className="font-mono">{reason}</span>
        </div>
      )}

      {/* Confidence */}
      <div className="mt-3 pt-2 border-t flex items-center justify-between" style={{ borderColor: "hsl(220 10% 12%)" }}>
        <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>
          Gate: {(gateThreshold * 100).toFixed(1)}% | Conf: {(confidence * 100).toFixed(3)}%
        </span>
        <div className="w-20 h-1.5 rounded-full overflow-hidden" style={{ background: "hsl(220 10% 12%)" }}>
          <div className="h-full rounded-full transition-all" style={{ width: `${confidence * 100}%`, background: confidence >= gateThreshold ? "hsl(142 71% 45%)" : confidence >= 0.95 ? "hsl(45 100% 50%)" : "hsl(0 72% 51%)" }} />
        </div>
      </div>

      {/* Prize Tiers */}
      <div className="mt-3 pt-2 border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
        <p className="text-[9px] font-semibold mb-1.5 uppercase tracking-wider" style={{ color: "hsl(220 10% 40%)" }}>Faixas de premiacao</p>
        <div className="flex flex-wrap gap-1">
          {lottery.prizeRanges.slice(0, 3).map((pr, i) => (
            <span key={i} className="text-[8px] px-2 py-0.5 rounded-full" style={{ background: "hsl(220 10% 10%)", color: "hsl(220 10% 55%)", border: "1px solid hsl(220 10% 14%)" }}>{pr.label}</span>
          ))}
        </div>
      </div>

      {/* Confirm Bet Button */}
      <div className="mt-3 pt-2 border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
        <button onClick={onConfirm} disabled={confirmed || saving} className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-[10px] font-bold transition-all disabled:opacity-60" style={{ background: confirmed ? "hsl(142 71% 45% / 0.15)" : "hsl(45 100% 50% / 0.1)", color: confirmed ? "hsl(142 71% 45%)" : "hsl(45 100% 50%)", border: `1px solid ${confirmed ? "hsl(142 71% 45% / 0.3)" : "hsl(45 100% 50% / 0.3)"}` }}>
          {confirmed ? (
            <><Check className="w-3 h-3" />{locale === "pt-BR" ? "Confirmada e Salva no Banco" : "Confirmed & Saved"}</>
          ) : saving ? (
            <><Save className="w-3 h-3 animate-spin" />{locale === "pt-BR" ? "Salvando..." : "Saving..."}</>
          ) : (
            <><Save className="w-3 h-3" />{locale === "pt-BR" ? "Confirmar Aposta" : "Confirm Bet"}</>
          )}
        </button>
      </div>
    </div>
  )
}

function LotteryCard({ lottery, result, locale, isToday, formatCurrency }: { lottery: LotteryConfig; result?: LotteryResult; locale: "pt-BR" | "en"; isToday: boolean; formatCurrency: (v: number) => string }) {
  return (
    <div className="rounded-xl border p-4 transition-all hover:border-opacity-60" style={{ background: "hsl(220 15% 7%)", borderColor: isToday ? lottery.color + "55" : "hsl(220 10% 14%)", boxShadow: isToday ? `0 0 20px ${lottery.color}11` : "none" }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ background: lottery.color }} />
          <h3 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{lottery.displayName}</h3>
        </div>
        {isToday && (
          <span className="text-[9px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider animate-pulse" style={{ background: lottery.color + "22", color: lottery.color }}>
            HOJE 21h
          </span>
        )}
      </div>

      <div className="text-[9px] mb-2" style={{ color: "hsl(220 10% 40%)" }}>{lottery.drawDayNames[locale]}</div>

      {result ? (
        <>
          <div className="flex items-center gap-2 mb-2 text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>
            <span>{t("dashboard.contest", locale)} #{result.contest_id}</span>
            <span>|</span>
            <span>{result.date}</span>
          </div>
          <div className="flex flex-wrap gap-1.5 mb-3">
            {result.numbers.map((n, i) => (
              <span key={i} className="w-8 h-8 flex items-center justify-center rounded-full text-xs font-bold" style={{ background: lottery.color + "22", color: lottery.color, border: `1px solid ${lottery.color}44` }}>
                {String(n).padStart(2, "0")}
              </span>
            ))}
          </div>
          {result.extras.trevos && result.extras.trevos.length > 0 && result.extras.trevos[0] > 0 && (
            <div className="mb-2">
              <span className="text-[9px] uppercase tracking-wider mr-2" style={{ color: "hsl(220 10% 50%)" }}>Trevos:</span>
              {result.extras.trevos.map((tv, i) => (
                <span key={i} className="inline-flex items-center justify-center w-6 h-6 rounded-full text-[10px] font-bold mr-1" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)" }}>{tv}</span>
              ))}
            </div>
          )}
          {result.extras.month && (
            <div className="text-[10px] mb-2" style={{ color: "hsl(220 10% 50%)" }}>
              Mes da Sorte: <span style={{ color: lottery.color }}>{result.extras.month}</span>
            </div>
          )}
          <div className="flex items-center justify-between pt-2 border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
            <div className="text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>
              {result.accumulated && <span className="font-bold" style={{ color: "hsl(45 100% 50%)" }}>{t("dashboard.accumulated", locale)}</span>}
            </div>
            {result.next_prize_estimate > 0 && (
              <div className="flex items-center gap-1">
                <TrendingUp className="w-3 h-3" style={{ color: "hsl(142 71% 45%)" }} />
                <span className="text-xs font-bold" style={{ color: "hsl(142 71% 45%)" }}>{formatCurrency(result.next_prize_estimate)}</span>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="flex flex-col items-center justify-center py-6 text-center">
          <div className="w-8 h-8 rounded-full flex items-center justify-center mb-2" style={{ background: "hsl(220 10% 12%)" }}>
            <ChevronRight className="w-4 h-4" style={{ color: "hsl(220 10% 40%)" }} />
          </div>
          <span className="text-[10px]" style={{ color: "hsl(220 10% 40%)" }}>
            {locale === "pt-BR" ? "Aguardando sincronizacao..." : "Awaiting sync..."}
          </span>
        </div>
      )}
    </div>
  )
}
