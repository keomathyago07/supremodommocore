"use client"

import { useState, useEffect } from "react"
import { useApp } from "@/lib/store"
import { useEvolutionState, confirmEvolutionBet } from "@/components/neural-evolution-engine"
import { LOTTERIES } from "@/lib/lottery-config"
import {
  Brain, Zap, TrendingUp, Clock, Target, CheckCircle, AlertTriangle,
  RefreshCw, Database, Activity, Sparkles, Lock, Calendar, Timer,
  ChevronRight, Save, Check, Cpu, LineChart, BarChart3, Rocket,
} from "lucide-react"

function getBrasiliaTime(): string {
  return new Date().toLocaleTimeString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  })
}

export function EvolutionView() {
  const { locale } = useApp()
  const evolutionState = useEvolutionState()
  const [brasiliaTime, setBrasiliaTime] = useState(getBrasiliaTime())
  const [confirmingId, setConfirmingId] = useState<string | null>(null)
  const [confirmedIds, setConfirmedIds] = useState<Set<string>>(new Set())

  useEffect(() => {
    const interval = setInterval(() => setBrasiliaTime(getBrasiliaTime()), 1000)
    return () => clearInterval(interval)
  }, [])

  const handleConfirmBet = async (prediction: NonNullable<typeof evolutionState>["dailyPredictions"][0]) => {
    setConfirmingId(prediction.lotteryId)
    const success = await confirmEvolutionBet(prediction)
    if (success) {
      setConfirmedIds(prev => new Set(prev).add(prediction.lotteryId))
    }
    setConfirmingId(null)
  }

  if (!evolutionState) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-center space-y-4">
          <RefreshCw className="w-8 h-8 mx-auto animate-spin" style={{ color: "hsl(180 100% 50%)" }} />
          <p className="text-sm" style={{ color: "hsl(220 10% 50%)" }}>
            {locale === "pt-BR" ? "Inicializando Neural Evolution Engine..." : "Initializing Neural Evolution Engine..."}
          </p>
        </div>
      </div>
    )
  }

  const phaseColors: Record<string, string> = {
    LEARNING: "hsl(45 100% 50%)",
    EVOLVING: "hsl(280 60% 55%)",
    OPTIMIZING: "hsl(142 71% 45%)",
    PREDICTING: "hsl(180 100% 50%)",
  }

  const avgMastery = Object.values(evolutionState.lotteryMastery).reduce((a, b) => a + b, 0) / Object.keys(evolutionState.lotteryMastery).length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <Brain className="w-8 h-8" style={{ color: "hsl(280 60% 55%)" }} />
            <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(280 60% 55%)" }}>
              Neural Evolution Engine
            </h1>
          </div>
          <p className="text-xs mt-1" style={{ color: "hsl(220 10% 50%)" }}>
            {locale === "pt-BR"
              ? "Sistema exclusivo de auto-aprendizado 24/7 - Nunca para, sempre evolui"
              : "Exclusive 24/7 self-learning system - Never stops, always evolves"}
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <span className="flex items-center gap-1.5 px-3 py-2 rounded-lg border text-[10px] font-mono" style={{ background: "hsl(180 100% 50% / 0.08)", borderColor: "hsl(180 100% 50% / 0.2)", color: "hsl(180 100% 50%)" }}>
            <Clock className="w-3 h-3" /> {brasiliaTime} BRT
          </span>
          <span className="flex items-center gap-1.5 px-3 py-2 rounded-lg border text-[10px] font-bold" style={{ background: `${phaseColors[evolutionState.currentPhase]}15`, borderColor: `${phaseColors[evolutionState.currentPhase]}40`, color: phaseColors[evolutionState.currentPhase] }}>
            <Activity className="w-3 h-3 animate-pulse" /> {evolutionState.currentPhase}
          </span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: locale === "pt-BR" ? "Ciclos Completos" : "Cycles Completed", value: evolutionState.cyclesCompleted.toLocaleString(), icon: Zap, color: "hsl(45 100% 50%)" },
          { label: locale === "pt-BR" ? "Horas de Analise" : "Analysis Hours", value: evolutionState.totalAnalysisHours.toFixed(2), icon: Timer, color: "hsl(180 100% 50%)" },
          { label: locale === "pt-BR" ? "Padroes Descobertos" : "Patterns Discovered", value: evolutionState.patternsDiscovered.toLocaleString(), icon: Target, color: "hsl(280 60% 55%)" },
          { label: locale === "pt-BR" ? "Dominio Medio" : "Average Mastery", value: `${avgMastery.toFixed(2)}%`, icon: TrendingUp, color: "hsl(142 71% 45%)" },
        ].map((stat, i) => (
          <div key={i} className="p-4 rounded-xl border" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
              <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>{stat.label}</span>
            </div>
            <span className="text-xl font-bold font-mono" style={{ color: stat.color }}>{stat.value}</span>
          </div>
        ))}
      </div>

      {/* Active Engines */}
      <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center gap-2 mb-3">
          <Cpu className="w-4 h-4" style={{ color: "hsl(280 60% 55%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Motores Ativos Agora" : "Active Engines Now"}
          </h2>
        </div>
        <div className="flex flex-wrap gap-2">
          {evolutionState.activeEngines.map((engine, i) => (
            <span key={i} className="px-2 py-1 rounded text-[10px] font-mono" style={{ background: "hsl(280 60% 55% / 0.1)", color: "hsl(280 60% 55%)" }}>
              {engine}
            </span>
          ))}
        </div>
      </div>

      {/* Lottery Mastery */}
      <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center gap-2 mb-4">
          <BarChart3 className="w-4 h-4" style={{ color: "hsl(142 71% 45%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Dominio por Loteria (Nunca Retrocede)" : "Lottery Mastery (Never Regresses)"}
          </h2>
        </div>
        <div className="space-y-3">
          {LOTTERIES.map(lottery => {
            const mastery = evolutionState.lotteryMastery[lottery.id] || 50
            return (
              <div key={lottery.id} className="flex items-center gap-3">
                <div className="w-3 h-3 rounded-full" style={{ background: lottery.color }} />
                <span className="text-xs w-28 truncate" style={{ color: "hsl(200 20% 90%)" }}>{lottery.displayName}</span>
                <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ background: "hsl(220 10% 12%)" }}>
                  <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${mastery}%`, background: lottery.color }} />
                </div>
                <span className="text-[10px] font-mono w-14 text-right" style={{ color: lottery.color }}>{mastery.toFixed(2)}%</span>
              </div>
            )
          })}
        </div>
      </div>

      {/* Daily Predictions with Confirm Button */}
      <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
            <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Predicoes do Dia - Sorteios as 21:00h" : "Today's Predictions - Draws at 9PM"}
            </h2>
          </div>
          <span className="text-[10px] font-mono px-2 py-1 rounded" style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)" }}>
            {evolutionState.dailyPredictions.length} {locale === "pt-BR" ? "loterias" : "lotteries"}
          </span>
        </div>

        {evolutionState.dailyPredictions.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="w-8 h-8 mx-auto mb-2" style={{ color: "hsl(220 10% 30%)" }} />
            <p className="text-xs" style={{ color: "hsl(220 10% 40%)" }}>
              {locale === "pt-BR" ? "Nenhuma loteria com sorteio hoje" : "No lotteries drawing today"}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {evolutionState.dailyPredictions.map(pred => {
              const lottery = LOTTERIES.find(l => l.id === pred.lotteryId)
              const isConfirmed = confirmedIds.has(pred.lotteryId) || pred.confirmed
              const isConfirming = confirmingId === pred.lotteryId

              return (
                <div key={pred.lotteryId} className="p-4 rounded-lg border" style={{ background: "hsl(220 10% 9%)", borderColor: pred.gateStatus === "APPROVED" ? `${lottery?.color}40` : "hsl(220 10% 14%)" }}>
                  {/* Header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full" style={{ background: lottery?.color }} />
                      <span className="font-bold text-sm" style={{ color: "hsl(200 20% 95%)" }}>{pred.lotteryName}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded" style={{ background: "hsl(220 10% 14%)", color: "hsl(220 10% 60%)" }}>
                        #{pred.contestId}
                      </span>
                    </div>
                    <span className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-bold ${pred.gateStatus === "APPROVED" ? "" : ""}`} style={{
                      background: pred.gateStatus === "APPROVED" ? "hsl(142 71% 45% / 0.1)" : "hsl(0 72% 51% / 0.1)",
                      color: pred.gateStatus === "APPROVED" ? "hsl(142 71% 45%)" : "hsl(0 72% 51%)",
                    }}>
                      {pred.gateStatus === "APPROVED" ? <CheckCircle className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                      {pred.gateStatus}
                    </span>
                  </div>

                  {/* Confidence */}
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>
                      {locale === "pt-BR" ? "Confianca:" : "Confidence:"}
                    </span>
                    <span className="text-lg font-bold font-mono" style={{ color: pred.gateStatus === "APPROVED" ? "hsl(142 71% 45%)" : "hsl(45 100% 50%)" }}>
                      {(pred.confidence * 100).toFixed(3)}%
                    </span>
                  </div>

                  {/* Numbers */}
                  <div className="mb-3">
                    <span className="text-[10px] block mb-2" style={{ color: "hsl(220 10% 45%)" }}>
                      {locale === "pt-BR" ? "Numeros Sugeridos:" : "Suggested Numbers:"}
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {pred.numbers.map((n, i) => (
                        <span key={i} className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold" style={{ background: lottery?.color, color: "#000" }}>
                          {String(n).padStart(2, "0")}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Extras */}
                  {pred.extras && (
                    <div className="mb-3">
                      {pred.extras.trevos && (
                        <div className="flex items-center gap-2">
                          <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>Trevos:</span>
                          <div className="flex gap-1">
                            {pred.extras.trevos.map((t, i) => (
                              <span key={i} className="w-6 h-6 rounded flex items-center justify-center text-[10px] font-bold" style={{ background: "hsl(142 71% 45%)", color: "#000" }}>
                                {t}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      {pred.extras.month && (
                        <div className="flex items-center gap-2">
                          <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>Mes da Sorte:</span>
                          <span className="text-xs font-bold" style={{ color: "hsl(45 100% 50%)" }}>{pred.extras.month}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Details */}
                  <div className="grid grid-cols-2 gap-2 mb-4 text-[9px]">
                    <div className="p-2 rounded" style={{ background: "hsl(220 10% 12%)" }}>
                      <span style={{ color: "hsl(220 10% 45%)" }}>Modelo:</span>
                      <span className="block font-mono font-bold" style={{ color: "hsl(280 60% 55%)" }}>{pred.model}</span>
                    </div>
                    <div className="p-2 rounded" style={{ background: "hsl(220 10% 12%)" }}>
                      <span style={{ color: "hsl(220 10% 45%)" }}>Data:</span>
                      <span className="block font-mono font-bold" style={{ color: "hsl(180 100% 50%)" }}>{pred.generatedAt} {pred.brasiliaTime}h</span>
                    </div>
                    <div className="p-2 rounded" style={{ background: "hsl(220 10% 12%)" }}>
                      <span style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Ciclos de Analise:" : "Analysis Cycles:"}</span>
                      <span className="block font-mono font-bold" style={{ color: "hsl(45 100% 50%)" }}>{pred.analysisDepth.toLocaleString()}</span>
                    </div>
                    <div className="p-2 rounded" style={{ background: "hsl(220 10% 12%)" }}>
                      <span style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Padroes Usados:" : "Patterns Used:"}</span>
                      <span className="block font-mono font-bold" style={{ color: "hsl(142 71% 45%)" }}>{pred.patternsUsed.toLocaleString()}</span>
                    </div>
                  </div>

                  {/* Confirm Button */}
                  {pred.gateStatus === "APPROVED" && (
                    <button
                      onClick={() => handleConfirmBet(pred)}
                      disabled={isConfirmed || isConfirming}
                      className="w-full flex items-center justify-center gap-2 py-3 rounded-lg font-bold text-sm transition-all"
                      style={{
                        background: isConfirmed ? "hsl(142 71% 45% / 0.15)" : "hsl(142 71% 45%)",
                        color: isConfirmed ? "hsl(142 71% 45%)" : "#000",
                        opacity: isConfirming ? 0.7 : 1,
                      }}
                    >
                      {isConfirming ? (
                        <><RefreshCw className="w-4 h-4 animate-spin" /> {locale === "pt-BR" ? "Salvando..." : "Saving..."}</>
                      ) : isConfirmed ? (
                        <><Check className="w-4 h-4" /> {locale === "pt-BR" ? "Aposta Confirmada - Conferencia Automatica" : "Bet Confirmed - Auto Check"}</>
                      ) : (
                        <><Database className="w-4 h-4" /> {locale === "pt-BR" ? "CONFIRMAR APOSTA" : "CONFIRM BET"}</>
                      )}
                    </button>
                  )}

                  {pred.gateStatus === "BLOCKED" && (
                    <div className="flex items-center justify-center gap-2 py-2 rounded-lg text-xs" style={{ background: "hsl(0 72% 51% / 0.1)", color: "hsl(0 72% 51%)" }}>
                      <AlertTriangle className="w-4 h-4" />
                      {locale === "pt-BR" ? "Gate nao atingido - Aposta bloqueada" : "Gate not reached - Bet blocked"}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* Evolution Log */}
      <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center gap-2 mb-3">
          <LineChart className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Log de Evolucao" : "Evolution Log"}
          </h2>
        </div>
        <div className="space-y-2 max-h-60 overflow-y-auto">
          {evolutionState.evolutionLog.slice(0, 20).map((log, i) => (
            <div key={i} className="flex items-center gap-3 p-2 rounded text-[10px]" style={{ background: "hsl(220 10% 10%)" }}>
              <span className="font-mono" style={{ color: "hsl(220 10% 40%)" }}>{log.timestamp}</span>
              <span className="px-1.5 py-0.5 rounded" style={{ background: `${phaseColors[log.phase] || "hsl(180 100% 50%)"}20`, color: phaseColors[log.phase] || "hsl(180 100% 50%)" }}>
                {log.phase}
              </span>
              <span style={{ color: "hsl(200 20% 90%)" }}>{log.action}</span>
              {log.confidence && (
                <span className="ml-auto font-mono" style={{ color: "hsl(142 71% 45%)" }}>{(log.confidence * 100).toFixed(2)}%</span>
              )}
            </div>
          ))}
          {evolutionState.evolutionLog.length === 0 && (
            <p className="text-center py-4 text-[10px]" style={{ color: "hsl(220 10% 40%)" }}>
              {locale === "pt-BR" ? "Logs serao exibidos a cada 1000 ciclos" : "Logs will appear every 1000 cycles"}
            </p>
          )}
        </div>
      </div>

      {/* Footer Info */}
      <div className="flex items-center justify-center gap-2 py-4">
        <Rocket className="w-4 h-4" style={{ color: "hsl(280 60% 55%)" }} />
        <p className="text-[10px]" style={{ color: "hsl(220 10% 40%)" }}>
          {locale === "pt-BR"
            ? "Neural Evolution Engine trabalha 24/7 incessantemente. Nunca para, sempre evolui, domina todas as loterias."
            : "Neural Evolution Engine works 24/7 non-stop. Never stops, always evolves, dominates all lotteries."}
        </p>
      </div>
    </div>
  )
}
