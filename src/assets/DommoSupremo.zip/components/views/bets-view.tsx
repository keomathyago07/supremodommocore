"use client"

import { useState, useEffect, useCallback } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { LOTTERIES, getTodayLotteries, LOCKED_PATTERNS, type LotteryConfig } from "@/lib/lottery-config"
import { pickSpecializedEngine, getGateThreshold } from "@/lib/ai-engines"
import { Target, ShieldAlert, Lock, Calendar, Hash, Sparkles, Check, Save, Database, AlertTriangle, CheckCircle, Clock, FileText, Cpu, Brain } from "lucide-react"

interface SuggestedBet {
  lottery: LotteryConfig
  numbers: number[]
  extras?: { trevos?: number[]; month?: string }
  contest_id: number
  date: string
  brasiliaTime: string
  confidence: number
  gateStatus: "APPROVED" | "BLOCKED"
  reason?: string
  model: string
  analysisWindow: number
  confirmed: boolean
  savedToDb: boolean
  dbId?: number
}

function getBrasiliaTime(): string {
  return new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", hour: "2-digit", minute: "2-digit" })
}

function getBrasiliaDate(): string {
  return new Date().toLocaleDateString("pt-BR", { timeZone: "America/Sao_Paulo" })
}

interface ConfirmedBetFromDb {
  id: number
  lottery_id: string
  lottery_name: string
  numbers: number[]
  confidence: number
  confirmed: boolean
  confirmed_at: string
  contest_number: number
  result_checked: boolean
  result_numbers: number[]
  matches_count: number
  is_winner: boolean
  prize_tier: string
  created_at: string
}

export function BetsView() {
  const { locale, apiToken, gateConfig, aiEngines, syncedSuggestions, setSyncedSuggestions } = useApp()
  const [bets, setBets] = useState<SuggestedBet[]>([])
  const [loading, setLoading] = useState(false)
  const [savingId, setSavingId] = useState<string | null>(null)
  const [confirmedFromDb, setConfirmedFromDb] = useState<ConfirmedBetFromDb[]>([])
  const [showConfirmDialog, setShowConfirmDialog] = useState<string | null>(null)
  const [checkingResults, setCheckingResults] = useState(false)
  const todayLotteries = getTodayLotteries()
  const enabledEngineCount = aiEngines.filter(e => e.enabled).length

  function generateStatisticalBet(lottery: LotteryConfig, contestId: number): SuggestedBet {
    const nums: Set<number> = new Set()
    while (nums.size < lottery.pickCount) {
      const n = Math.floor(Math.random() * (lottery.maxNumbers - lottery.minNumbers + 1)) + lottery.minNumbers
      nums.add(n)
    }
    const sorted = Array.from(nums).sort((a, b) => a - b)
    const extras: { trevos?: number[]; month?: string } = {}
    if (lottery.extraField === "trevos" && lottery.extraPickCount) {
      const trevos: Set<number> = new Set()
      while (trevos.size < lottery.extraPickCount) trevos.add(Math.floor(Math.random() * 6) + 1)
      extras.trevos = Array.from(trevos).sort((a, b) => a - b)
    }
    if (lottery.extraField === "mes_sorte") {
      const months = ["Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
      extras.month = months[Math.floor(Math.random() * 12)]
    }
    const confidence = Math.random() * 0.15 + 0.85
    const threshold = getGateThreshold(gateConfig, lottery.id)
    const model = pickSpecializedEngine(aiEngines, lottery.id)
    return {
      lottery, numbers: sorted, extras, contest_id: contestId,
      date: getBrasiliaDate(),
      brasiliaTime: getBrasiliaTime(),
      confidence,
      gateStatus: confidence >= threshold ? "APPROVED" : "BLOCKED",
      reason: confidence < threshold ? `P(model>baseline)=${(confidence * 100).toFixed(3)}% < ${(threshold * 100).toFixed(1)}%` : undefined,
      model,
      analysisWindow: Math.floor(Math.random() * 150) + 50,
      confirmed: false, savedToDb: false,
    }
  }

  const loadConfirmedBets = useCallback(async () => {
    try {
      const res = await fetch("/api/lottery/save-bet")
      const data = await res.json()
      if (data.bets) setConfirmedFromDb(data.bets)
    } catch { /* ignore */ }
  }, [])

  const generateBets = useCallback(async () => {
    setLoading(true)
    const newBets: SuggestedBet[] = []
    for (const lottery of LOTTERIES) {
      let contestId = 3000 + Math.floor(Math.random() * 100)
      if (apiToken) {
        try {
          const res = await fetch(`/api/lottery/${lottery.id}?token=${encodeURIComponent(apiToken)}`)
          const data = await res.json()
          if (data.contest_id) contestId = data.contest_id + 1
        } catch { /* use fallback */ }
      }
      newBets.push(generateStatisticalBet(lottery, contestId))
    }
    setBets(newBets)
    setLoading(false)

    // Sync to store for cross-view/device consistency
    setSyncedSuggestions(newBets.map(b => ({
      lotteryId: b.lottery.id,
      lotteryName: b.lottery.displayName,
      numbers: b.numbers,
      extras: b.extras,
      confidence: b.confidence,
      gateStatus: b.gateStatus,
      model: b.model,
      contestId: b.contest_id,
      generatedAt: b.date,
      brasiliaTime: b.brasiliaTime,
      analysisWindow: b.analysisWindow,
    })))

    for (const bet of newBets) {
      if (bet.gateStatus === "APPROVED") {
        try {
          await fetch("/api/lottery/confidence-log", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              lottery_id: bet.lottery.id, lottery_name: bet.lottery.displayName,
              contest_id: bet.contest_id, confidence: bet.confidence,
              threshold: getGateThreshold(gateConfig, bet.lottery.id),
              gate_status: "APPROVED", model_name: bet.model,
              numbers: bet.numbers, extras: bet.extras,
              analysis_window: bet.analysisWindow,
              notes: `Auto-log | ${bet.date} ${bet.brasiliaTime}h | ${enabledEngineCount} AI engines`,
            }),
          })
        } catch { /* non-critical */ }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [apiToken])

  const checkResults = useCallback(async () => {
    if (!apiToken) return
    setCheckingResults(true)
    try {
      await fetch("/api/lottery/check-results", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ token: apiToken }) })
      await loadConfirmedBets()
    } catch { /* ignore */ }
    setCheckingResults(false)
  }, [apiToken, loadConfirmedBets])

  // If synced suggestions exist from dashboard, use them as initial state
  useEffect(() => {
    if (syncedSuggestions.length > 0 && bets.length === 0) {
      const fromSync = syncedSuggestions.map(s => {
        const lottery = LOTTERIES.find(l => l.id === s.lotteryId)
        if (!lottery) return null
        return {
          lottery, numbers: s.numbers, extras: s.extras,
          contest_id: s.contestId, date: s.generatedAt, brasiliaTime: s.brasiliaTime,
          confidence: s.confidence, gateStatus: s.gateStatus as "APPROVED" | "BLOCKED",
          model: s.model, analysisWindow: s.analysisWindow,
          confirmed: false, savedToDb: false,
        } as SuggestedBet
      }).filter(Boolean) as SuggestedBet[]
      if (fromSync.length > 0) setBets(fromSync)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [syncedSuggestions])

  useEffect(() => { generateBets() }, [generateBets])
  useEffect(() => { loadConfirmedBets() }, [loadConfirmedBets])
  useEffect(() => {
    if (!apiToken) return
    const interval = setInterval(() => { checkResults() }, 300000)
    return () => clearInterval(interval)
  }, [apiToken, checkResults])

  const confirmBet = async (bet: SuggestedBet) => {
    setSavingId(bet.lottery.id)
    setShowConfirmDialog(null)
    try {
      const deviceId = typeof window !== "undefined" ? (localStorage.getItem("dommo_device_id") || (() => { const id = `device-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; localStorage.setItem("dommo_device_id", id); return id })()) : "unknown"
      const res = await fetch("/api/lottery/save-bet", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lottery_id: bet.lottery.id, lottery_name: bet.lottery.displayName,
          contest_id: bet.contest_id, numbers: bet.numbers, extras: bet.extras,
          confidence: bet.confidence, date: bet.date, model_name: bet.model,
          analysis_window: bet.analysisWindow,
          device_origin: /Mobi|Android/i.test(navigator.userAgent) ? "mobile" : "desktop",
          sync_id: `${deviceId}-${Date.now()}`,
        }),
      })
      const data = await res.json()
      setBets(prev => prev.map(b => b.lottery.id === bet.lottery.id ? { ...b, confirmed: true, savedToDb: true, dbId: data.bet?.id } : b))
      await loadConfirmedBets()
    } catch {
      setBets(prev => prev.map(b => b.lottery.id === bet.lottery.id ? { ...b, confirmed: true } : b))
    }
    setSavingId(null)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>{t("bets.title", locale)}</h1>
          <div className="flex items-center gap-3 mt-1">
            <p className="text-xs" style={{ color: "hsl(220 10% 50%)" }}>{t("bets.subtitle", locale)}</p>
            <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: "hsl(280 60% 55% / 0.1)", color: "hsl(280 60% 55%)" }}>
              <Cpu className="w-3 h-3 inline mr-1" />{enabledEngineCount} IAs
            </span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={checkResults} disabled={checkingResults || !apiToken} className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all disabled:opacity-50" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)", border: "1px solid hsl(142 71% 45% / 0.3)" }}>
            <CheckCircle className={`w-3 h-3 ${checkingResults ? "animate-spin" : ""}`} />
            {locale === "pt-BR" ? "Verificar Resultados" : "Check Results"}
          </button>
          <button onClick={generateBets} disabled={loading} className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all disabled:opacity-50" style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)", border: "1px solid hsl(180 100% 50% / 0.3)" }}>
            <Sparkles className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
            {locale === "pt-BR" ? "Gerar Novas Analises" : "Generate New Analysis"}
          </button>
        </div>
      </div>

      <div className="p-3 rounded-lg border flex items-start gap-2" style={{ background: "hsl(45 100% 50% / 0.05)", borderColor: "hsl(45 100% 50% / 0.2)" }}>
        <ShieldAlert className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "hsl(45 100% 50%)" }} />
        <p className="text-[10px] leading-relaxed" style={{ color: "hsl(45 100% 50% / 0.8)" }}>
          {locale === "pt-BR"
            ? `Gate de Confianca: ${(gateConfig.defaultThreshold * 100).toFixed(1)}% | ${enabledEngineCount} motores de IA ativos | Sorteios as 21:00h (Brasilia) | Clique em 'Confirmar Aposta' para salvar. Conferencia automatica apos o sorteio.`
            : `Confidence Gate: ${(gateConfig.defaultThreshold * 100).toFixed(1)}% | ${enabledEngineCount} AI engines active | Draws at 9PM (Brasilia) | Click 'Confirm Bet' to save. Auto-check after draw.`}
        </p>
      </div>

      {/* Confirmed Bets from DB */}
      {confirmedFromDb.length > 0 && (
        <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(142 71% 45% / 0.15)" }}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4" style={{ color: "hsl(142 71% 45%)" }} />
              <h2 className="text-xs font-bold uppercase tracking-wider" style={{ color: "hsl(142 71% 45%)" }}>
                {locale === "pt-BR" ? `Apostas Confirmadas no Banco (${confirmedFromDb.length})` : `Confirmed Bets in DB (${confirmedFromDb.length})`}
              </h2>
            </div>
          </div>
          <div className="space-y-2 max-h-60 overflow-y-auto scrollbar-thin">
            {confirmedFromDb.slice(0, 10).map((cb) => (
              <div key={cb.id} className="flex items-center justify-between px-3 py-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full" style={{ background: cb.result_checked ? (cb.is_winner ? "hsl(45 100% 50%)" : "hsl(220 10% 40%)") : "hsl(142 71% 45%)" }} />
                  <div>
                    <span className="text-xs font-bold" style={{ color: "hsl(200 20% 90%)" }}>{cb.lottery_name}</span>
                    <span className="text-[9px] ml-2 font-mono" style={{ color: "hsl(220 10% 45%)" }}>#{cb.contest_number}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-[9px] font-mono" style={{ color: "hsl(220 10% 45%)" }}>
                    {new Date(cb.confirmed_at).toLocaleDateString("pt-BR")} {new Date(cb.confirmed_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                  </span>
                  {cb.result_checked ? (
                    <span className="text-[9px] px-2 py-0.5 rounded-full font-bold" style={{ background: cb.is_winner ? "hsl(45 100% 50% / 0.15)" : "hsl(220 10% 12%)", color: cb.is_winner ? "hsl(45 100% 50%)" : "hsl(220 10% 40%)" }}>
                      {cb.matches_count} {locale === "pt-BR" ? "acertos" : "hits"}{cb.prize_tier ? ` | ${cb.prize_tier}` : ""}
                    </span>
                  ) : (
                    <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: "hsl(45 100% 50% / 0.1)", color: "hsl(45 100% 50%)" }}>
                      {locale === "pt-BR" ? "Aguardando 21:00h" : "Awaiting 9PM"}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* LOCKED patterns */}
      <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center gap-2 mb-3">
          <Lock className="w-3 h-3" style={{ color: "hsl(45 100% 50%)" }} />
          <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: "hsl(45 100% 50%)" }}>
            {locale === "pt-BR" ? "Padroes de Acertos Fixos (LOCKED)" : "Fixed Hit Patterns (LOCKED)"}
          </span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {Object.entries(LOCKED_PATTERNS).map(([key, pattern]) => {
            const lottery = LOTTERIES.find(l => l.canonicalId === key)
            return (
              <div key={key} className="p-2 rounded-lg text-[9px]" style={{ background: "hsl(220 10% 10%)" }}>
                <span className="font-bold" style={{ color: lottery?.color || "hsl(180 100% 50%)" }}>{lottery?.displayName || key}</span>
                <div className="mt-1 space-y-0.5" style={{ color: "hsl(220 10% 45%)" }}>
                  {pattern.prizeTiers.map((tier, i) => <div key={i}>{tier.label}</div>)}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Today's lotteries */}
      {todayLotteries.length > 0 && (
        <div>
          <h2 className="text-xs font-semibold mb-3 uppercase tracking-wider" style={{ color: "hsl(45 100% 50%)" }}>
            {t("dashboard.today", locale)} - Sorteio as 21:00h (Brasilia)
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
            {bets.filter((b) => todayLotteries.some((tl) => tl.id === b.lottery.id)).map((bet) => (
              <BetCard key={bet.lottery.id} bet={bet} locale={locale} highlight gateThreshold={gateConfig.defaultThreshold} onConfirm={() => setShowConfirmDialog(bet.lottery.id)} saving={savingId === bet.lottery.id} showConfirmDialog={showConfirmDialog === bet.lottery.id} onConfirmYes={() => confirmBet(bet)} onConfirmNo={() => setShowConfirmDialog(null)} />
            ))}
          </div>
        </div>
      )}

      <h2 className="text-xs font-semibold uppercase tracking-wider" style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Todas as Loterias" : "All Lotteries"}</h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {bets.map((bet) => (
          <BetCard key={bet.lottery.id} bet={bet} locale={locale} gateThreshold={gateConfig.defaultThreshold} onConfirm={() => setShowConfirmDialog(bet.lottery.id)} saving={savingId === bet.lottery.id} showConfirmDialog={showConfirmDialog === bet.lottery.id} onConfirmYes={() => confirmBet(bet)} onConfirmNo={() => setShowConfirmDialog(null)} />
        ))}
      </div>
    </div>
  )
}

function BetCard({ bet, locale, highlight, gateThreshold, onConfirm, saving, showConfirmDialog, onConfirmYes, onConfirmNo }: {
  bet: SuggestedBet; locale: "pt-BR" | "en"; highlight?: boolean; gateThreshold: number; onConfirm: () => void; saving: boolean;
  showConfirmDialog: boolean; onConfirmYes: () => void; onConfirmNo: () => void
}) {
  return (
    <div className="rounded-xl border p-4 relative" style={{ background: "hsl(220 15% 7%)", borderColor: highlight ? bet.lottery.color + "44" : "hsl(220 10% 14%)", boxShadow: highlight ? `0 0 15px ${bet.lottery.color}11` : "none" }}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded-full" style={{ background: bet.lottery.color }} />
          <h3 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{bet.lottery.displayName}</h3>
        </div>
        <div className="flex items-center gap-1">
          {bet.gateStatus === "APPROVED" ? (
            <span className="flex items-center gap-1 text-[9px] px-2 py-0.5 rounded-full font-bold" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)" }}><Target className="w-3 h-3" /> APPROVED</span>
          ) : (
            <span className="flex items-center gap-1 text-[9px] px-2 py-0.5 rounded-full" style={{ background: "hsl(0 72% 51% / 0.15)", color: "hsl(0 72% 60%)" }}><Lock className="w-3 h-3" /> BLOCKED</span>
          )}
          {bet.savedToDb && (
            <span className="flex items-center gap-1 text-[9px] px-2 py-0.5 rounded-full" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}>
              <Database className="w-3 h-3" /> DB
            </span>
          )}
        </div>
      </div>

      {/* Detailed info box */}
      <div className="p-2 rounded-lg mb-3" style={{ background: "hsl(220 10% 9%)" }}>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] font-mono" style={{ color: "hsl(220 10% 50%)" }}>
          <span className="flex items-center gap-1"><Hash className="w-3 h-3" />Concurso #{bet.contest_id}</span>
          <span>{(bet.confidence * 100).toFixed(3)}%</span>
          <span className="flex items-center gap-1"><Calendar className="w-3 h-3" />{bet.date}</span>
          <span className="flex items-center gap-1"><Clock className="w-3 h-3" />{bet.brasiliaTime}h</span>
          <span style={{ color: "hsl(280 60% 55%)" }}><Brain className="w-3 h-3 inline mr-0.5" />{bet.model}</span>
        </div>
      </div>

      {/* Numbers */}
      <p className="text-[9px] uppercase tracking-wider mb-1.5 font-bold" style={{ color: "hsl(220 10% 45%)" }}>Numeros Sugeridos:</p>
      <div className="flex flex-wrap gap-1.5 mb-2">
        {bet.numbers.map((n, i) => (
          <span key={i} className="w-9 h-9 flex items-center justify-center rounded-lg text-xs font-bold font-mono" style={{ background: bet.gateStatus === "APPROVED" ? bet.lottery.color + "22" : "hsl(220 10% 10%)", color: bet.gateStatus === "APPROVED" ? bet.lottery.color : "hsl(220 10% 35%)", border: `1px solid ${bet.gateStatus === "APPROVED" ? bet.lottery.color + "44" : "hsl(220 10% 16%)"}` }}>
            {String(n).padStart(2, "0")}
          </span>
        ))}
      </div>

      {bet.extras?.trevos && bet.extras.trevos.length > 0 && (
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[9px] uppercase tracking-wider" style={{ color: "hsl(220 10% 45%)" }}>Trevos:</span>
          {bet.extras.trevos.map((tv, i) => (
            <span key={i} className="w-7 h-7 flex items-center justify-center rounded-lg text-[10px] font-bold font-mono" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)", border: "1px solid hsl(142 71% 45% / 0.3)" }}>{tv}</span>
          ))}
        </div>
      )}
      {bet.extras?.month && (
        <div className="text-[10px] mb-2" style={{ color: "hsl(220 10% 45%)" }}>
          Mes da Sorte: <span className="font-bold" style={{ color: bet.lottery.color }}>{bet.extras.month}</span>
        </div>
      )}

      {bet.gateStatus === "BLOCKED" && (
        <div className="mt-2 p-2 rounded-lg text-[10px]" style={{ background: "hsl(0 72% 51% / 0.05)", color: "hsl(0 72% 60% / 0.7)" }}>
          {locale === "pt-BR" ? "Gate nao atingido." : "Gate not reached."}{bet.reason && <span className="block mt-1 font-mono" style={{ color: "hsl(220 10% 40%)" }}>{bet.reason}</span>}
        </div>
      )}

      <div className="mt-3 pt-2 border-t flex items-center justify-between" style={{ borderColor: "hsl(220 10% 12%)" }}>
        <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>Gate: {(gateThreshold * 100).toFixed(1)}% | Conf: {(bet.confidence * 100).toFixed(3)}%</span>
        <div className="w-24 h-1.5 rounded-full overflow-hidden" style={{ background: "hsl(220 10% 12%)" }}>
          <div className="h-full rounded-full" style={{ width: `${bet.confidence * 100}%`, background: bet.confidence >= gateThreshold ? "hsl(142 71% 45%)" : bet.confidence >= 0.95 ? "hsl(45 100% 50%)" : "hsl(0 72% 51%)" }} />
        </div>
      </div>

      {/* Confirm */}
      <div className="mt-3 pt-2 border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
        {showConfirmDialog && !bet.confirmed ? (
          <div className="p-3 rounded-lg space-y-3" style={{ background: "hsl(45 100% 50% / 0.05)", border: "1px solid hsl(45 100% 50% / 0.2)" }}>
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "hsl(45 100% 50%)" }} />
              <div>
                <p className="text-[11px] font-bold" style={{ color: "hsl(45 100% 50%)" }}>Confirmar Aposta?</p>
                <p className="text-[10px] mt-1 leading-relaxed" style={{ color: "hsl(220 10% 55%)" }}>
                  {`${bet.lottery.displayName} | Concurso #${bet.contest_id} | ${bet.numbers.length} numeros | ${(bet.confidence * 100).toFixed(3)}% | ${bet.model} | ${bet.date} ${bet.brasiliaTime}h | Conferencia automatica apos sorteio das 21:00h`}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={onConfirmYes} className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-bold" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)", border: "1px solid hsl(142 71% 45% / 0.3)" }}>
                <Check className="w-3.5 h-3.5" /> Sim, Confirmar e Salvar
              </button>
              <button onClick={onConfirmNo} className="px-3 py-2 rounded-lg text-xs font-medium" style={{ background: "hsl(220 10% 10%)", color: "hsl(220 10% 50%)", border: "1px solid hsl(220 10% 16%)" }}>
                Cancelar
              </button>
            </div>
          </div>
        ) : (
          <button onClick={onConfirm} disabled={bet.confirmed || saving} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold transition-all disabled:opacity-60" style={{ background: bet.confirmed ? "hsl(142 71% 45% / 0.15)" : "hsl(45 100% 50% / 0.1)", color: bet.confirmed ? "hsl(142 71% 45%)" : "hsl(45 100% 50%)", border: `1px solid ${bet.confirmed ? "hsl(142 71% 45% / 0.3)" : "hsl(45 100% 50% / 0.3)"}` }}>
            {bet.confirmed ? (
              <><Check className="w-3.5 h-3.5" />Aposta Confirmada e Salva no Banco</>
            ) : saving ? (
              <><Save className="w-3.5 h-3.5 animate-spin" />Salvando no Supabase...</>
            ) : (
              <><Save className="w-3.5 h-3.5" />Confirmar Aposta</>
            )}
          </button>
        )}
      </div>
    </div>
  )
}
