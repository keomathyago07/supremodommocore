"use client"

import { useState } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { LOTTERIES, LOCKED_PATTERNS, type LotteryConfig } from "@/lib/lottery-config"
import { Info, Hash, Calendar, Award, Columns, Lock, ShieldCheck } from "lucide-react"

export function LotteriesView() {
  const { locale } = useApp()
  const [selected, setSelected] = useState<LotteryConfig>(LOTTERIES[0])

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
        {t("nav.lotteries", locale)}
      </h1>

      <div className="flex flex-wrap gap-2">
        {LOTTERIES.map((l) => (
          <button
            key={l.id}
            onClick={() => setSelected(l)}
            className="px-4 py-2 rounded-lg text-xs font-medium transition-all"
            style={{
              background: selected.id === l.id ? l.color + "22" : "hsl(220 15% 8%)",
              color: selected.id === l.id ? l.color : "hsl(220 10% 55%)",
              border: `1px solid ${selected.id === l.id ? l.color + "55" : "hsl(220 10% 16%)"}`,
            }}
          >
            {l.displayName}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border p-6" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-3 mb-6">
            <div className="w-4 h-4 rounded-full" style={{ background: selected.color }} />
            <h2 className="text-lg font-bold" style={{ color: "hsl(200 20% 95%)" }}>{selected.displayName}</h2>
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <Info className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(180 100% 50%)" }} />
              <div>
                <p className="text-xs font-semibold mb-1" style={{ color: "hsl(200 20% 90%)" }}>
                  {t("bets.how_to_play", locale)}
                </p>
                <p className="text-xs leading-relaxed" style={{ color: "hsl(220 10% 55%)" }}>
                  {t(`howto.${selected.id}`, locale)}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Hash className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(180 100% 50%)" }} />
              <div>
                <p className="text-xs font-semibold mb-1" style={{ color: "hsl(200 20% 90%)" }}>
                  {locale === "pt-BR" ? "Numeros" : "Numbers"}
                </p>
                <p className="text-xs" style={{ color: "hsl(220 10% 55%)" }}>
                  {locale === "pt-BR"
                    ? `Escolha ${selected.pickCount} numeros de ${selected.minNumbers} a ${selected.maxNumbers}`
                    : `Pick ${selected.pickCount} numbers from ${selected.minNumbers} to ${selected.maxNumbers}`}
                </p>
              </div>
            </div>

            {selected.columns && (
              <div className="flex items-start gap-3">
                <Columns className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(180 100% 50%)" }} />
                <div>
                  <p className="text-xs font-semibold mb-1" style={{ color: "hsl(200 20% 90%)" }}>
                    {locale === "pt-BR" ? "Colunas" : "Columns"}
                  </p>
                  <p className="text-xs" style={{ color: "hsl(220 10% 55%)" }}>
                    {selected.columns} {locale === "pt-BR" ? "colunas (0-9 cada)" : "columns (0-9 each)"}
                  </p>
                </div>
              </div>
            )}

            {selected.extraField && (
              <div className="flex items-start gap-3">
                <Award className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(45 100% 50%)" }} />
                <div>
                  <p className="text-xs font-semibold mb-1" style={{ color: "hsl(200 20% 90%)" }}>
                    {selected.extraField === "trevos" ? (locale === "pt-BR" ? "Trevos" : "Clovers") :
                     selected.extraField === "mes_sorte" ? (locale === "pt-BR" ? "Mes da Sorte" : "Lucky Month") :
                     selected.extraField === "time_coracao" ? (locale === "pt-BR" ? "Time do Coracao" : "Heart Team") : selected.extraField}
                  </p>
                  <p className="text-xs" style={{ color: "hsl(220 10% 55%)" }}>
                    {selected.extraField === "trevos"
                      ? `${locale === "pt-BR" ? "Escolha" : "Pick"} ${selected.extraPickCount} ${locale === "pt-BR" ? "trevos de 1 a 6" : "clovers from 1 to 6"}`
                      : selected.extraField === "mes_sorte"
                      ? `${locale === "pt-BR" ? "Escolha 1 mes" : "Pick 1 month"}`
                      : `${locale === "pt-BR" ? "Escolha 1 time" : "Pick 1 team"}`}
                  </p>
                </div>
              </div>
            )}

            <div className="flex items-start gap-3">
              <Calendar className="w-4 h-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(180 100% 50%)" }} />
              <div>
                <p className="text-xs font-semibold mb-1" style={{ color: "hsl(200 20% 90%)" }}>
                  {locale === "pt-BR" ? "Dias de Sorteio" : "Draw Days"}
                </p>
                <div className="flex gap-1">
                  {["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"].map((day, i) => (
                    <span
                      key={i}
                      className="w-8 h-8 flex items-center justify-center rounded-lg text-[9px] font-medium"
                      style={{
                        background: selected.drawDays.includes(i) ? selected.color + "22" : "hsl(220 10% 10%)",
                        color: selected.drawDays.includes(i) ? selected.color : "hsl(220 10% 30%)",
                        border: `1px solid ${selected.drawDays.includes(i) ? selected.color + "44" : "hsl(220 10% 14%)"}`,
                      }}
                    >
                      {locale === "pt-BR" ? day : ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][i]}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-xl border p-6" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
          <h2 className="text-sm font-bold mb-4" style={{ color: "hsl(200 20% 90%)" }}>
            {locale === "pt-BR" ? "Faixas de Premiacao" : "Prize Tiers"}
          </h2>
          <div className="space-y-2">
            {selected.prizeRanges.map((pr, i) => (
              <div
                key={i}
                className="flex items-center justify-between px-4 py-3 rounded-lg"
                style={{ background: "hsl(220 10% 10%)" }}
              >
                <span className="text-xs" style={{ color: "hsl(200 20% 90%)" }}>{pr.label}</span>
                <span
                  className="text-xs font-mono font-bold px-2 py-0.5 rounded"
                  style={{ background: selected.color + "22", color: selected.color }}
                >
                  {pr.hits} {locale === "pt-BR" ? "acertos" : "hits"}
                </span>
              </div>
            ))}
          </div>

          {LOCKED_PATTERNS[selected.id] && (
            <div className="mb-6 p-4 rounded-lg border" style={{ background: "hsl(45 100% 50% / 0.03)", borderColor: "hsl(45 100% 50% / 0.15)" }}>
              <div className="flex items-center gap-2 mb-3">
                <Lock className="w-3.5 h-3.5" style={{ color: "hsl(45 100% 50%)" }} />
                <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: "hsl(45 100% 50%)" }}>
                  {locale === "pt-BR" ? "Padroes Travados (IA)" : "Locked Patterns (AI)"}
                </span>
                <ShieldCheck className="w-3.5 h-3.5 ml-auto" style={{ color: "hsl(142 71% 45%)" }} />
              </div>
              <div className="space-y-1.5">
                {LOCKED_PATTERNS[selected.id].prizeTiers.map((pt, i) => (
                  <div key={i} className="flex items-center gap-2 text-[10px]">
                    <div className="w-1.5 h-1.5 rounded-full" style={{ background: "hsl(45 100% 50%)" }} />
                    <span style={{ color: "hsl(200 20% 85%)" }}>{pt.label}</span>
                  </div>
                ))}
              </div>
              <p className="text-[8px] mt-2 font-mono" style={{ color: "hsl(220 10% 35%)" }}>
                {locale === "pt-BR" ? "Estes padroes NAO podem ser alterados. As IAs trabalham exclusivamente com eles." : "These patterns CANNOT be changed. AIs work exclusively with them."}
              </p>
            </div>
          )}

          <div className="mt-6 p-4 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
            <p className="text-[10px] uppercase tracking-wider mb-2" style={{ color: "hsl(220 10% 40%)" }}>
              {locale === "pt-BR" ? "Numeros disponiveis" : "Available numbers"}
            </p>
            <div className="flex flex-wrap gap-1">
              {Array.from({ length: Math.min(selected.maxNumbers - selected.minNumbers + 1, 60) }, (_, i) => selected.minNumbers + i).map((n) => (
                <span
                  key={n}
                  className="w-6 h-6 flex items-center justify-center rounded text-[8px] font-mono"
                  style={{ background: "hsl(220 15% 8%)", color: "hsl(220 10% 45%)", border: "1px solid hsl(220 10% 14%)" }}
                >
                  {n}
                </span>
              ))}
              {selected.maxNumbers - selected.minNumbers + 1 > 60 && (
                <span className="text-[10px] px-2 flex items-center" style={{ color: "hsl(220 10% 40%)" }}>
                  ...{selected.maxNumbers}
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
