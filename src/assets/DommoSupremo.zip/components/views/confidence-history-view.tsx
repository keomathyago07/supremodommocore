"use client"

import { useState, useEffect, useCallback } from "react"
import { useApp } from "@/lib/store"
import { LOTTERIES } from "@/lib/lottery-config"
import {
  ShieldCheck, RefreshCw, Target, Clock, Calendar, Hash,
  ChevronDown, ChevronUp, Filter, Search, TrendingUp,
} from "lucide-react"

interface ConfidenceLog {
  id: number
  lottery_id: string
  lottery_name: string
  contest_id: number
  confidence: number
  threshold: number
  gate_status: string
  model_name: string
  numbers: number[]
  extras: Record<string, unknown>
  analysis_window: number
  triggered_at: string
  year: number
  month: number
  day: number
  hour: number
  minute: number
  notes: string
}

interface GroupedLogs {
  [lotteryId: string]: ConfidenceLog[]
}

export function ConfidenceHistoryView() {
  const { locale } = useApp()
  const [logs, setLogs] = useState<ConfidenceLog[]>([])
  const [loading, setLoading] = useState(false)
  const [expandedLottery, setExpandedLottery] = useState<string | null>(null)
  const [filterStatus, setFilterStatus] = useState<"all" | "APPROVED" | "BLOCKED">("all")
  const [searchQuery, setSearchQuery] = useState("")

  const loadLogs = useCallback(async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/lottery/confidence-log")
      const data = await res.json()
      setLogs(data.logs || [])
    } catch { /* ignore */ }
    setLoading(false)
  }, [])

  useEffect(() => { loadLogs() }, [loadLogs])

  // Auto-refresh every 60 seconds
  useEffect(() => {
    const interval = setInterval(loadLogs, 60000)
    return () => clearInterval(interval)
  }, [loadLogs])

  const filteredLogs = logs.filter(l => {
    if (l.lottery_id === "system") return false
    if (filterStatus !== "all" && l.gate_status !== filterStatus) return false
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      return l.lottery_name.toLowerCase().includes(q) || l.lottery_id.toLowerCase().includes(q) || l.model_name.toLowerCase().includes(q)
    }
    return true
  })

  const grouped: GroupedLogs = {}
  filteredLogs.forEach(log => {
    if (!grouped[log.lottery_id]) grouped[log.lottery_id] = []
    grouped[log.lottery_id].push(log)
  })

  const lotteryOrder = LOTTERIES.map(l => l.id)
  const sortedKeys = Object.keys(grouped).sort((a, b) => {
    const ia = lotteryOrder.indexOf(a)
    const ib = lotteryOrder.indexOf(b)
    return (ia === -1 ? 999 : ia) - (ib === -1 ? 999 : ib)
  })

  const getLotteryColor = (id: string) => LOTTERIES.find(l => l.id === id)?.color || "hsl(180 100% 50%)"
  const approvedCount = logs.filter(l => l.gate_status === "APPROVED" && l.lottery_id !== "system").length
  const totalCount = logs.filter(l => l.lottery_id !== "system").length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl" style={{ background: "hsl(142 71% 45% / 0.1)", border: "1px solid hsl(142 71% 45% / 0.2)" }}>
              <ShieldCheck className="w-6 h-6" style={{ color: "hsl(142 71% 45%)" }} />
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
                {locale === "pt-BR" ? "Historico Gate de Confianca 0.999" : "Confidence Gate 0.999 History"}
              </h1>
              <p className="text-xs mt-0.5" style={{ color: "hsl(220 10% 50%)" }}>
                {locale === "pt-BR"
                  ? "Registro permanente de todas as loterias que atingiram o criterio de confianca. Dados nunca sao apagados."
                  : "Permanent record of all lotteries that hit the confidence criteria. Data is never deleted."}
              </p>
            </div>
          </div>
        </div>
        <button onClick={loadLogs} disabled={loading} className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold" style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)", border: "1px solid hsl(180 100% 50% / 0.3)" }}>
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          {locale === "pt-BR" ? "Atualizar Dados" : "Refresh Data"}
        </button>
      </div>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: locale === "pt-BR" ? "Total de Registros" : "Total Records", value: totalCount, color: "hsl(180 100% 50%)", icon: Hash },
          { label: locale === "pt-BR" ? "Gate Aprovados" : "Gate Approved", value: approvedCount, color: "hsl(142 71% 45%)", icon: ShieldCheck },
          { label: locale === "pt-BR" ? "Loterias Ativas" : "Active Lotteries", value: sortedKeys.length, color: "hsl(45 100% 50%)", icon: Target },
          { label: locale === "pt-BR" ? "Threshold" : "Threshold", value: "99.9%", color: "hsl(280 60% 55%)", icon: TrendingUp },
        ].map(({ label, value, color, icon: Icon }) => (
          <div key={label} className="p-4 rounded-xl border" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
            <div className="flex items-center gap-2 mb-2">
              <Icon className="w-3.5 h-3.5" style={{ color }} />
              <span className="text-[9px] uppercase tracking-wider font-bold" style={{ color: "hsl(220 10% 45%)" }}>{label}</span>
            </div>
            <span className="text-xl font-bold font-mono" style={{ color }}>{value}</span>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "hsl(220 10% 40%)" }} />
          <input
            type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            placeholder={locale === "pt-BR" ? "Buscar por loteria, modelo..." : "Search by lottery, model..."}
            className="w-full pl-9 pr-4 py-2.5 rounded-xl text-xs outline-none border"
            style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)", color: "hsl(200 20% 95%)" }}
          />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5" style={{ color: "hsl(220 10% 45%)" }} />
          {(["all", "APPROVED", "BLOCKED"] as const).map(status => (
            <button key={status} onClick={() => setFilterStatus(status)} className="px-3 py-2 rounded-lg text-[10px] font-bold transition-all" style={{
              background: filterStatus === status ? (status === "APPROVED" ? "hsl(142 71% 45% / 0.1)" : status === "BLOCKED" ? "hsl(0 72% 51% / 0.1)" : "hsl(180 100% 50% / 0.1)") : "hsl(220 10% 10%)",
              color: filterStatus === status ? (status === "APPROVED" ? "hsl(142 71% 45%)" : status === "BLOCKED" ? "hsl(0 72% 60%)" : "hsl(180 100% 50%)") : "hsl(220 10% 45%)",
              border: `1px solid ${filterStatus === status ? (status === "APPROVED" ? "hsl(142 71% 45% / 0.3)" : status === "BLOCKED" ? "hsl(0 72% 51% / 0.3)" : "hsl(180 100% 50% / 0.3)") : "hsl(220 10% 16%)"}`,
            }}>
              {status === "all" ? (locale === "pt-BR" ? "Todos" : "All") : status}
            </button>
          ))}
        </div>
      </div>

      {/* Lottery Groups */}
      {sortedKeys.length === 0 ? (
        <div className="p-12 rounded-xl border text-center" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
          <ShieldCheck className="w-12 h-12 mx-auto mb-3" style={{ color: "hsl(220 10% 20%)" }} />
          <p className="text-sm font-bold" style={{ color: "hsl(220 10% 40%)" }}>
            {locale === "pt-BR" ? "Nenhum registro encontrado" : "No records found"}
          </p>
          <p className="text-xs mt-1" style={{ color: "hsl(220 10% 30%)" }}>
            {locale === "pt-BR" ? "Os registros aparecero aqui quando as loterias atingirem o gate de confianca 0.999" : "Records will appear here when lotteries hit the 0.999 confidence gate"}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {sortedKeys.map(lotteryId => {
            const lotteryLogs = grouped[lotteryId]
            const latestLog = lotteryLogs[0]
            const color = getLotteryColor(lotteryId)
            const isExpanded = expandedLottery === lotteryId
            const approvedInGroup = lotteryLogs.filter(l => l.gate_status === "APPROVED").length

            return (
              <div key={lotteryId} className="rounded-xl border overflow-hidden" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
                {/* Lottery Header */}
                <button onClick={() => setExpandedLottery(isExpanded ? null : lotteryId)} className="w-full flex items-center justify-between p-4 transition-all hover:bg-white/[0.02]">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xs font-bold" style={{ background: `${color}15`, color, border: `1px solid ${color}30` }}>
                      {latestLog.lottery_name.slice(0, 2).toUpperCase()}
                    </div>
                    <div className="text-left">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{latestLog.lottery_name}</span>
                        <span className="text-[9px] px-2 py-0.5 rounded-full font-bold" style={{ background: `${color}15`, color }}>{lotteryLogs.length} {locale === "pt-BR" ? "registros" : "records"}</span>
                        {approvedInGroup > 0 && (
                          <span className="text-[9px] px-2 py-0.5 rounded-full font-bold" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}>{approvedInGroup} APPROVED</span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-0.5">
                        <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 45%)" }}>
                          {locale === "pt-BR" ? "Ultimo" : "Latest"}: {String(latestLog.day).padStart(2, "0")}/{String(latestLog.month).padStart(2, "0")}/{latestLog.year} {String(latestLog.hour).padStart(2, "0")}:{String(latestLog.minute).padStart(2, "0")}
                        </span>
                        <span className="text-[10px] font-mono" style={{ color: "hsl(142 71% 45%)" }}>{(Number(latestLog.confidence) * 100).toFixed(2)}%</span>
                      </div>
                    </div>
                  </div>
                  {isExpanded ? <ChevronUp className="w-4 h-4" style={{ color: "hsl(220 10% 45%)" }} /> : <ChevronDown className="w-4 h-4" style={{ color: "hsl(220 10% 45%)" }} />}
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="border-t px-4 pb-4" style={{ borderColor: "hsl(220 10% 12%)" }}>
                    <div className="space-y-2 mt-3">
                      {lotteryLogs.map((log) => (
                        <div key={log.id} className="rounded-xl p-4 border" style={{ background: "hsl(220 10% 8%)", borderColor: log.gate_status === "APPROVED" ? "hsl(142 71% 45% / 0.15)" : "hsl(220 10% 14%)" }}>
                          {/* Top row */}
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full" style={{ background: log.gate_status === "APPROVED" ? "hsl(142 71% 45%)" : "hsl(0 72% 51%)" }} />
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full" style={{
                                background: log.gate_status === "APPROVED" ? "hsl(142 71% 45% / 0.1)" : "hsl(0 72% 51% / 0.1)",
                                color: log.gate_status === "APPROVED" ? "hsl(142 71% 45%)" : "hsl(0 72% 60%)",
                              }}>{log.gate_status}</span>
                              {log.contest_id > 0 && (
                                <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 50%)" }}>
                                  {locale === "pt-BR" ? "Concurso" : "Contest"} #{log.contest_id}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] font-mono" style={{ color }}>
                              {(Number(log.confidence) * 100).toFixed(3)}%
                            </span>
                          </div>

                          {/* Numbers */}
                          {log.numbers && log.numbers.length > 0 && (
                            <div className="mb-3">
                              <p className="text-[9px] uppercase tracking-wider font-bold mb-1.5" style={{ color: "hsl(220 10% 40%)" }}>
                                {locale === "pt-BR" ? "Numeros Sugeridos" : "Suggested Numbers"}
                              </p>
                              <div className="flex flex-wrap gap-1.5">
                                {log.numbers.map((n, i) => (
                                  <span key={i} className="w-8 h-8 rounded-lg flex items-center justify-center text-[11px] font-bold font-mono" style={{ background: `${color}15`, color, border: `1px solid ${color}30` }}>
                                    {String(n).padStart(2, "0")}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Metadata */}
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                            <div className="flex items-center gap-1.5">
                              <Calendar className="w-3 h-3" style={{ color: "hsl(220 10% 40%)" }} />
                              <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 55%)" }}>
                                {String(log.day).padStart(2, "0")}/{String(log.month).padStart(2, "0")}/{log.year}
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Clock className="w-3 h-3" style={{ color: "hsl(220 10% 40%)" }} />
                              <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 55%)" }}>
                                {String(log.hour).padStart(2, "0")}:{String(log.minute).padStart(2, "0")}h
                              </span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Target className="w-3 h-3" style={{ color: "hsl(220 10% 40%)" }} />
                              <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 55%)" }}>
                                {log.model_name || "CertusV2"}
                              </span>
                            </div>
                            {log.analysis_window > 0 && (
                              <div className="flex items-center gap-1.5">
                                <TrendingUp className="w-3 h-3" style={{ color: "hsl(220 10% 40%)" }} />
                                <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 55%)" }}>
                                  {log.analysis_window} {locale === "pt-BR" ? "concursos" : "contests"}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
