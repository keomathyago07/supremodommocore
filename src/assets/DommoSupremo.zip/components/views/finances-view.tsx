"use client"

import { useState, useEffect } from "react"
import { useApp } from "@/lib/store"
import { LOTTERIES } from "@/lib/lottery-config"
import { DollarSign, TrendingUp, Calendar, Hash, Trophy, BarChart3, Wallet } from "lucide-react"

interface WinRecord {
  lottery_id: string
  lottery_name: string
  contest_id: number
  date: string
  hits: number
  tier: string
  prize_value: number
  color: string
}

export function FinancesView() {
  const { locale } = useApp()
  const [wins, setWins] = useState<WinRecord[]>([])
  const [totalByLottery, setTotalByLottery] = useState<Record<string, { total: number; count: number; name: string; color: string }>>({})

  useEffect(() => {
    const stored = localStorage.getItem("dommo_win_history")
    if (stored) {
      const parsed: WinRecord[] = JSON.parse(stored)
      setWins(parsed)
      const byLot: Record<string, { total: number; count: number; name: string; color: string }> = {}
      for (const w of parsed) {
        if (!byLot[w.lottery_id]) byLot[w.lottery_id] = { total: 0, count: 0, name: w.lottery_name, color: w.color }
        byLot[w.lottery_id].total += w.prize_value
        byLot[w.lottery_id].count += 1
      }
      setTotalByLottery(byLot)
    }
  }, [])

  const grandTotal = wins.reduce((sum, w) => sum + w.prize_value, 0)
  const formatCurrency = (v: number) => new Intl.NumberFormat(locale === "pt-BR" ? "pt-BR" : "en-US", { style: "currency", currency: "BRL" }).format(v)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
          {locale === "pt-BR" ? "Sistema Financeiro" : "Financial System"}
        </h1>
        <p className="text-xs mt-1" style={{ color: "hsl(220 10% 50%)" }}>
          {locale === "pt-BR" ? "Acompanhamento detalhado de todos os seus premios" : "Detailed tracking of all your prizes"}
        </p>
      </div>

      {/* Grand Total */}
      <div className="rounded-xl border p-6" style={{ background: "linear-gradient(135deg, hsl(220 15% 7%), hsl(220 15% 9%))", borderColor: "hsl(45 100% 50% / 0.3)", boxShadow: "0 0 40px hsl(45 100% 50% / 0.05)" }}>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: "hsl(45 100% 50% / 0.1)" }}>
            <Wallet className="w-6 h-6" style={{ color: "hsl(45 100% 50%)" }} />
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-wider" style={{ color: "hsl(45 100% 50% / 0.7)" }}>
              {locale === "pt-BR" ? "Total Acumulado de Premios" : "Total Accumulated Prizes"}
            </p>
            <p className="text-3xl font-bold font-mono" style={{ color: "hsl(45 100% 50%)" }}>{formatCurrency(grandTotal)}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 mt-3 text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>
          <span className="flex items-center gap-1"><Trophy className="w-3 h-3" /> {wins.length} {locale === "pt-BR" ? "premios ganhos" : "prizes won"}</span>
          <span className="flex items-center gap-1"><BarChart3 className="w-3 h-3" /> {Object.keys(totalByLottery).length} {locale === "pt-BR" ? "loterias com premio" : "lotteries with prizes"}</span>
        </div>
      </div>

      {/* Per-lottery breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {LOTTERIES.map((lottery) => {
          const data = totalByLottery[lottery.id]
          return (
            <div key={lottery.id} className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: data ? lottery.color + "44" : "hsl(220 10% 14%)" }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: lottery.color }} />
                  <h3 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{lottery.displayName}</h3>
                </div>
                {data && <span className="text-[9px] px-2 py-0.5 rounded-full font-bold" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)" }}>{data.count}x</span>}
              </div>
              <div className="text-lg font-bold font-mono mb-1" style={{ color: data ? "hsl(45 100% 50%)" : "hsl(220 10% 25%)" }}>
                {formatCurrency(data?.total || 0)}
              </div>
              <p className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>
                {data ? (locale === "pt-BR" ? `${data.count} premio(s) recebido(s)` : `${data.count} prize(s) received`) : (locale === "pt-BR" ? "Nenhum premio ainda" : "No prizes yet")}
              </p>
            </div>
          )
        })}
      </div>

      {/* Detailed history */}
      {wins.length > 0 ? (
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <DollarSign className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
            <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Historico Detalhado de Premios" : "Detailed Prize History"}
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px]">
              <thead>
                <tr style={{ color: "hsl(220 10% 45%)" }}>
                  <th className="text-left p-2">{locale === "pt-BR" ? "Loteria" : "Lottery"}</th>
                  <th className="text-left p-2">{locale === "pt-BR" ? "Concurso" : "Contest"}</th>
                  <th className="text-left p-2">{locale === "pt-BR" ? "Data" : "Date"}</th>
                  <th className="text-left p-2">{locale === "pt-BR" ? "Acertos" : "Hits"}</th>
                  <th className="text-left p-2">{locale === "pt-BR" ? "Faixa" : "Tier"}</th>
                  <th className="text-right p-2">{locale === "pt-BR" ? "Valor" : "Value"}</th>
                </tr>
              </thead>
              <tbody>
                {wins.map((w, i) => (
                  <tr key={i} className="border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
                    <td className="p-2">
                      <div className="flex items-center gap-1.5">
                        <div className="w-2 h-2 rounded-full" style={{ background: w.color }} />
                        <span style={{ color: "hsl(200 20% 90%)" }}>{w.lottery_name}</span>
                      </div>
                    </td>
                    <td className="p-2 font-mono" style={{ color: "hsl(180 100% 50%)" }}>
                      <div className="flex items-center gap-1"><Hash className="w-3 h-3" />{w.contest_id}</div>
                    </td>
                    <td className="p-2" style={{ color: "hsl(220 10% 50%)" }}>
                      <div className="flex items-center gap-1"><Calendar className="w-3 h-3" />{w.date}</div>
                    </td>
                    <td className="p-2 font-bold" style={{ color: "hsl(142 71% 45%)" }}>{w.hits}</td>
                    <td className="p-2" style={{ color: "hsl(220 10% 55%)" }}>{w.tier}</td>
                    <td className="p-2 text-right font-bold font-mono" style={{ color: "hsl(45 100% 50%)" }}>
                      <div className="flex items-center justify-end gap-1"><TrendingUp className="w-3 h-3" />{formatCurrency(w.prize_value)}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="rounded-xl border p-8 text-center" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
          <DollarSign className="w-10 h-10 mx-auto mb-3" style={{ color: "hsl(220 10% 25%)" }} />
          <p className="text-sm" style={{ color: "hsl(220 10% 45%)" }}>
            {locale === "pt-BR" ? "Nenhum premio registrado ainda" : "No prizes registered yet"}
          </p>
          <p className="text-[10px] mt-1" style={{ color: "hsl(220 10% 35%)" }}>
            {locale === "pt-BR" ? "Confirme apostas e aguarde os resultados. O sistema verifica automaticamente." : "Confirm bets and wait for results. The system verifies automatically."}
          </p>
        </div>
      )}
    </div>
  )
}
