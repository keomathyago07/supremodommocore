"use client"

import { useState, useRef, useEffect } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { Send, Bot, User, Sparkles, AlertTriangle, Clock, CheckCircle } from "lucide-react"

interface ChatMessage {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  metadata?: {
    type?: "analysis" | "proposal" | "info" | "warning"
    proposal?: {
      title: string
      impact: string
      risk: "low" | "medium" | "high"
      status: "pending" | "approved" | "rejected"
    }
  }
}

const SYSTEM_RESPONSES: Record<string, string[]> = {
  "pt-BR": [
    "Analise processada. Baseado nos dados disponiveis, o padrao estatistico indica estabilidade nos ultimos 50 concursos. Janela: 50 concursos. Modelo: CertusV2. Dataset_hash: sha256:a1b2c3.",
    "Sentinel Gate Status: P(model>baseline) = 0.912. Criterio minimo: 0.998. Status: BLOCKED. O modelo precisa de mais dados para atingir confianca estatistica.",
    "Proposta de Melhoria detectada: Ajustar janela de analise de 50 para 100 concursos pode melhorar a convergencia do modelo. Risco: baixo. Impacto: melhoria de ~3% na estabilidade temporal.",
    "Dados sincronizados com sucesso. 9 loterias atualizadas. Ultima verificacao cruzada: CONSENSUS em 8/9. 1 loteria pendente (diadesorte - aguardando fonte oficial).",
    "Backtesting Veritas executado. Walk-forward: 20 janelas. Bootstrap: 10.000 amostras. Resultado: modelo nao superou baseline no criterio 0.998. Sugestoes bloqueadas.",
    "Sistema operacional. 2 instancias ativas. Uptime: 99.97%. Banco: saudavel. Cache: operacional. Workers: 2/2 ativos. Nenhum alerta critico.",
  ],
  en: [
    "Analysis processed. Based on available data, the statistical pattern indicates stability over the last 50 contests. Window: 50 contests. Model: CertusV2. Dataset_hash: sha256:a1b2c3.",
    "Sentinel Gate Status: P(model>baseline) = 0.912. Minimum criteria: 0.998. Status: BLOCKED. The model needs more data to reach statistical confidence.",
    "Improvement Proposal detected: Adjusting analysis window from 50 to 100 contests may improve model convergence. Risk: low. Impact: ~3% improvement in temporal stability.",
    "Data synced successfully. 9 lotteries updated. Last cross-verification: CONSENSUS on 8/9. 1 lottery pending (diadesorte - awaiting official source).",
    "Veritas backtesting executed. Walk-forward: 20 windows. Bootstrap: 10,000 samples. Result: model did not surpass baseline at 0.998 criteria. Suggestions blocked.",
    "System operational. 2 active instances. Uptime: 99.97%. Database: healthy. Cache: operational. Workers: 2/2 active. No critical alerts.",
  ],
}

export function ChatView() {
  const { locale } = useApp()
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: locale === "pt-BR"
        ? "DOMMO CORE ativo. Canal de controle e analise pronto. Posso explicar relatorios, rodar analises, consultar premios, criar propostas de melhoria ou discutir estrategias. O que deseja?"
        : "DOMMO CORE active. Control and analysis channel ready. I can explain reports, run analyses, check prizes, create improvement proposals, or discuss strategies. What do you need?",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isThinking, setIsThinking] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const sendMessage = async () => {
    if (!input.trim() || isThinking) return

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: "user",
      content: input.trim(),
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMsg])
    const currentInput = input.trim()
    setInput("")
    setIsThinking(true)

    const openaiKey = typeof window !== "undefined" ? localStorage.getItem("dommo_openai_key") : null

    if (openaiKey) {
      try {
        const res = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: { "Content-Type": "application/json", "Authorization": `Bearer ${openaiKey}` },
          body: JSON.stringify({
            model: "gpt-4o-mini",
            messages: [
              { role: "system", content: "Voce e o DOMMO CORE, um sistema de inteligencia estatistica para loterias brasileiras. Voce analisa padroes, dados historicos e ajuda o usuario com estrategias. Criterio de confianca: 0.998. Sempre responda de forma tecnica e precisa. Loterias: Mega-Sena, Lotofacil, Quina, Lotomania, Timemania, Dupla Sena, Dia de Sorte, Super Sete, +Milionaria." },
              ...messages.slice(-10).map(m => ({ role: m.role as "user" | "assistant", content: m.content })),
              { role: "user", content: currentInput }
            ],
            max_tokens: 800, temperature: 0.7,
          }),
        })
        const data = await res.json()
        const reply = data.choices?.[0]?.message?.content || "Erro ao processar resposta."
        setMessages((prev) => [...prev, { id: (Date.now() + 1).toString(), role: "assistant", content: reply, timestamp: new Date(), metadata: { type: "info" } }])
        setIsThinking(false)
        return
      } catch { /* fallback to local responses */ }
    }

    const lower = currentInput.toLowerCase()
    let responseType: "analysis" | "proposal" | "info" | "warning" = "info"
    if (lower.includes("proposta") || lower.includes("melhor") || lower.includes("proposal") || lower.includes("improve")) {
      responseType = "proposal"
    } else if (lower.includes("analise") || lower.includes("analys") || lower.includes("backtest")) {
      responseType = "analysis"
    } else if (lower.includes("gate") || lower.includes("sentinel") || lower.includes("block")) {
      responseType = "warning"
    }

    setTimeout(() => {
      const responses = SYSTEM_RESPONSES[locale] || SYSTEM_RESPONSES["pt-BR"]
      const randomResponse = responses[Math.floor(Math.random() * responses.length)]

      const proposal = responseType === "proposal"
        ? { title: locale === "pt-BR" ? "Ajuste de Janela Temporal" : "Temporal Window Adjustment", impact: locale === "pt-BR" ? "Melhoria de ~3% na estabilidade" : "~3% stability improvement", risk: "low" as const, status: "pending" as const }
        : undefined

      const assistantMsg: ChatMessage = {
        id: (Date.now() + 1).toString(), role: "assistant", content: randomResponse,
        timestamp: new Date(), metadata: { type: responseType, proposal },
      }
      setMessages((prev) => [...prev, assistantMsg])
      setIsThinking(false)
    }, 1500 + Math.random() * 2000)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-2rem)]">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
            {t("chat.title", locale)}
          </h1>
          <p className="text-xs" style={{ color: "hsl(220 10% 50%)" }}>
            {t("chat.subtitle", locale)}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {typeof window !== "undefined" && localStorage.getItem("dommo_openai_key") ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ background: "hsl(260 60% 55% / 0.1)" }}>
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "hsl(260 60% 55%)" }} />
              <span className="text-[10px] font-medium" style={{ color: "hsl(260 60% 55%)" }}>GPT Active</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
              <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Local Mode" : "Local Mode"}</span>
            </div>
          )}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ background: "hsl(142 71% 45% / 0.1)" }}>
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "hsl(142 71% 45%)" }} />
            <span className="text-[10px] font-medium" style={{ color: "hsl(142 71% 45%)" }}>24/7</span>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin rounded-xl border p-4 space-y-4 mb-4" style={{ background: "hsl(220 15% 5%)", borderColor: "hsl(220 10% 12%)" }}>
        {messages.map((msg) => (
          <div key={msg.id} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
              style={{
                background: msg.role === "user" ? "hsl(180 100% 50% / 0.15)" : "hsl(220 10% 12%)",
              }}
            >
              {msg.role === "user" ? (
                <User className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
              ) : (
                <Bot className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
              )}
            </div>
            <div className={`max-w-[80%] ${msg.role === "user" ? "text-right" : ""}`}>
              <div
                className="rounded-xl px-4 py-3 text-xs leading-relaxed"
                style={{
                  background: msg.role === "user" ? "hsl(180 100% 50% / 0.1)" : "hsl(220 15% 8%)",
                  border: `1px solid ${msg.role === "user" ? "hsl(180 100% 50% / 0.2)" : "hsl(220 10% 14%)"}`,
                  color: "hsl(200 20% 90%)",
                }}
              >
                {msg.content}
              </div>

              {msg.metadata?.proposal && (
                <div className="mt-2 p-3 rounded-lg border" style={{ background: "hsl(45 100% 50% / 0.05)", borderColor: "hsl(45 100% 50% / 0.2)" }}>
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-3 h-3" style={{ color: "hsl(45 100% 50%)" }} />
                    <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: "hsl(45 100% 50%)" }}>
                      {locale === "pt-BR" ? "Proposta de Melhoria" : "Improvement Proposal"}
                    </span>
                  </div>
                  <p className="text-[10px] mb-1" style={{ color: "hsl(200 20% 90%)" }}>{msg.metadata.proposal.title}</p>
                  <p className="text-[9px]" style={{ color: "hsl(220 10% 50%)" }}>
                    {locale === "pt-BR" ? "Impacto" : "Impact"}: {msg.metadata.proposal.impact} |{" "}
                    {locale === "pt-BR" ? "Risco" : "Risk"}: {msg.metadata.proposal.risk}
                  </p>
                  <div className="flex gap-2 mt-2">
                    <button className="px-3 py-1 rounded text-[9px] font-medium" style={{ background: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 45%)" }}>
                      {locale === "pt-BR" ? "Aprovar" : "Approve"}
                    </button>
                    <button className="px-3 py-1 rounded text-[9px] font-medium" style={{ background: "hsl(0 72% 51% / 0.15)", color: "hsl(0 72% 60%)" }}>
                      {locale === "pt-BR" ? "Rejeitar" : "Reject"}
                    </button>
                  </div>
                </div>
              )}

              {msg.metadata?.type === "warning" && (
                <div className="flex items-center gap-1 mt-1">
                  <AlertTriangle className="w-3 h-3" style={{ color: "hsl(45 100% 50%)" }} />
                  <span className="text-[9px]" style={{ color: "hsl(45 100% 50%)" }}>Sentinel Gate Alert</span>
                </div>
              )}

              <div className="flex items-center gap-1 mt-1" style={{ color: "hsl(220 10% 30%)" }}>
                <Clock className="w-2.5 h-2.5" />
                <span className="text-[8px]">{msg.timestamp.toLocaleTimeString()}</span>
                {msg.role === "assistant" && <CheckCircle className="w-2.5 h-2.5 ml-1" />}
              </div>
            </div>
          </div>
        ))}

        {isThinking && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "hsl(220 10% 12%)" }}>
              <Bot className="w-4 h-4 animate-pulse" style={{ color: "hsl(45 100% 50%)" }} />
            </div>
            <div className="rounded-xl px-4 py-3 flex items-center gap-2" style={{ background: "hsl(220 15% 8%)", border: "1px solid hsl(220 10% 14%)" }}>
              <div className="flex gap-1">
                <div className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: "hsl(180 100% 50%)", animationDelay: "0ms" }} />
                <div className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: "hsl(180 100% 50%)", animationDelay: "150ms" }} />
                <div className="w-1.5 h-1.5 rounded-full animate-bounce" style={{ background: "hsl(180 100% 50%)", animationDelay: "300ms" }} />
              </div>
              <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>{t("chat.thinking", locale)}</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className="flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          placeholder={t("chat.placeholder", locale)}
          className="flex-1 px-4 py-3 rounded-xl text-sm outline-none border"
          style={{
            background: "hsl(220 15% 8%)",
            borderColor: "hsl(220 10% 16%)",
            color: "hsl(200 20% 95%)",
          }}
        />
        <button
          onClick={sendMessage}
          disabled={!input.trim() || isThinking}
          className="px-4 py-3 rounded-xl transition-all disabled:opacity-50"
          style={{ background: "hsl(180 100% 50% / 0.15)", border: "1px solid hsl(180 100% 50% / 0.3)" }}
        >
          <Send className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
        </button>
      </div>
    </div>
  )
}
