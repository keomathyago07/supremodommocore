"use client"

import { useState, useEffect, useMemo } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { LOTTERIES } from "@/lib/lottery-config"
import {
  Activity,
  Brain,
  Cpu,
  Database,
  Wifi,
  Shield,
  Zap,
  Clock,
  TrendingUp,
  BarChart3,
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Eye,
  Server,
  HardDrive,
  Lock,
} from "lucide-react"
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
  LineChart,
  Line,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface AIModelStatus {
  name: string
  status: "active" | "training" | "idle" | "error"
  confidence: number
  lastRun: string
  processingTime: number
  accuracy: number
  datasetSize: number
  color: string
}

interface SystemMetric {
  time: string
  cpu: number
  memory: number
  requests: number
  latency: number
}

function generateMetrics(): SystemMetric[] {
  const metrics: SystemMetric[] = []
  const now = new Date()
  for (let i = 23; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 3600000)
    metrics.push({
      time: `${String(d.getHours()).padStart(2, "0")}:00`,
      cpu: Math.floor(Math.random() * 40) + 20,
      memory: Math.floor(Math.random() * 30) + 50,
      requests: Math.floor(Math.random() * 200) + 50,
      latency: Math.floor(Math.random() * 100) + 30,
    })
  }
  return metrics
}

function generateConfidenceHistory(): { epoch: string; certus: number; bayesian: number; markov: number; neural: number; temporal: number }[] {
  const data: { epoch: string; certus: number; bayesian: number; markov: number; neural: number; temporal: number }[] = []
  for (let i = 0; i < 20; i++) {
    data.push({
      epoch: `E${i + 1}`,
      certus: Math.min(1, 0.85 + Math.random() * 0.15),
      bayesian: Math.min(1, 0.80 + Math.random() * 0.18),
      markov: Math.min(1, 0.78 + Math.random() * 0.20),
      neural: Math.min(1, 0.82 + Math.random() * 0.16),
      temporal: Math.min(1, 0.75 + Math.random() * 0.22),
    })
  }
  return data
}

function generateLotteryAnalysis(): { name: string; analyzed: number; patterns: number; confidence: number; color: string }[] {
  return LOTTERIES.map((l) => ({
    name: l.displayName.length > 8 ? l.displayName.slice(0, 8) : l.displayName,
    analyzed: Math.floor(Math.random() * 2000) + 500,
    patterns: Math.floor(Math.random() * 50) + 10,
    confidence: Math.random() * 0.3 + 0.7,
    color: l.color,
  }))
}

function generateRadarData(): { metric: string; value: number; fullMark: number }[] {
  return [
    { metric: "Accuracy", value: Math.random() * 30 + 70, fullMark: 100 },
    { metric: "Speed", value: Math.random() * 30 + 70, fullMark: 100 },
    { metric: "Coverage", value: Math.random() * 25 + 75, fullMark: 100 },
    { metric: "Stability", value: Math.random() * 20 + 80, fullMark: 100 },
    { metric: "Precision", value: Math.random() * 25 + 75, fullMark: 100 },
    { metric: "Recall", value: Math.random() * 30 + 70, fullMark: 100 },
  ]
}

const AI_MODELS: AIModelStatus[] = [
  { name: "CertusV2", status: "active", confidence: 0.912, lastRun: "2m ago", processingTime: 1.2, accuracy: 94.3, datasetSize: 15420, color: "hsl(180 100% 50%)" },
  { name: "BayesianNet", status: "active", confidence: 0.887, lastRun: "5m ago", processingTime: 0.8, accuracy: 91.7, datasetSize: 12800, color: "hsl(142 71% 45%)" },
  { name: "MarkovChain", status: "training", confidence: 0.845, lastRun: "12m ago", processingTime: 2.1, accuracy: 88.9, datasetSize: 9600, color: "hsl(45 100% 50%)" },
  { name: "NeuralFreq", status: "active", confidence: 0.901, lastRun: "3m ago", processingTime: 3.5, accuracy: 93.1, datasetSize: 18200, color: "hsl(280 80% 60%)" },
  { name: "TemporalGAN", status: "idle", confidence: 0.823, lastRun: "30m ago", processingTime: 5.2, accuracy: 86.4, datasetSize: 7400, color: "hsl(0 72% 60%)" },
  { name: "EnsembleVote", status: "active", confidence: 0.934, lastRun: "1m ago", processingTime: 0.3, accuracy: 95.8, datasetSize: 20000, color: "hsl(200 80% 60%)" },
]

export function MonitoringView() {
  const { locale } = useApp()
  const [refreshKey, setRefreshKey] = useState(0)
  const [liveSeconds, setLiveSeconds] = useState(0)

  const systemMetrics = useMemo(() => generateMetrics(), [refreshKey])
  const confidenceHistory = useMemo(() => generateConfidenceHistory(), [refreshKey])
  const lotteryAnalysis = useMemo(() => generateLotteryAnalysis(), [refreshKey])
  const radarData = useMemo(() => generateRadarData(), [refreshKey])

  const modelDistribution = useMemo(() => {
    return AI_MODELS.map((m) => ({
      name: m.name,
      value: m.datasetSize,
      color: m.color,
    }))
  }, [])

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveSeconds((p) => p + 1)
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  const uptime = `${Math.floor(liveSeconds / 3600)}h ${Math.floor((liveSeconds % 3600) / 60)}m ${liveSeconds % 60}s`

  const statusColor = (s: string) => {
    switch (s) {
      case "active": return "hsl(142 71% 45%)"
      case "training": return "hsl(45 100% 50%)"
      case "idle": return "hsl(220 10% 50%)"
      case "error": return "hsl(0 72% 51%)"
      default: return "hsl(220 10% 50%)"
    }
  }

  const statusLabel = (s: string) => {
    if (locale === "pt-BR") {
      switch (s) {
        case "active": return "Ativo"
        case "training": return "Treinando"
        case "idle": return "Ocioso"
        case "error": return "Erro"
        default: return s
      }
    }
    return s.charAt(0).toUpperCase() + s.slice(1)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
            {t("monitoring.title", locale)}
          </h1>
          <p className="text-xs mt-1" style={{ color: "hsl(220 10% 50%)" }}>
            {t("monitoring.subtitle", locale)}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "hsl(142 71% 45% / 0.08)", border: "1px solid hsl(142 71% 45% / 0.2)" }}>
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "hsl(142 71% 45%)" }} />
            <span className="text-[10px] font-medium font-mono" style={{ color: "hsl(142 71% 45%)" }}>LIVE {uptime}</span>
          </div>
          <button
            onClick={() => setRefreshKey((k) => k + 1)}
            className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium"
            style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)", border: "1px solid hsl(180 100% 50% / 0.3)" }}
          >
            <RefreshCw className="w-3 h-3" />
            {locale === "pt-BR" ? "Atualizar" : "Refresh"}
          </button>
        </div>
      </div>

      {/* System Status Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatusCard
          icon={<Wifi className="w-4 h-4" />}
          label={t("monitoring.api_status", locale)}
          value={t("monitoring.healthy", locale)}
          color="hsl(142 71% 45%)"
          detail="200 OK | 45ms"
        />
        <StatusCard
          icon={<Database className="w-4 h-4" />}
          label={t("monitoring.db_status", locale)}
          value={t("monitoring.healthy", locale)}
          color="hsl(142 71% 45%)"
          detail="Supabase | 9 tables"
        />
        <StatusCard
          icon={<Server className="w-4 h-4" />}
          label={t("monitoring.cache_status", locale)}
          value={t("monitoring.healthy", locale)}
          color="hsl(142 71% 45%)"
          detail="Hit Rate: 94.2%"
        />
        <StatusCard
          icon={<Cpu className="w-4 h-4" />}
          label={t("monitoring.workers", locale)}
          value="6/6"
          color="hsl(180 100% 50%)"
          detail={locale === "pt-BR" ? "Todos ativos" : "All active"}
        />
      </div>

      {/* Sentinel Gate */}
      <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(45 100% 50% / 0.15)" }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5" style={{ color: "hsl(45 100% 50%)" }} />
            <h2 className="text-sm font-bold" style={{ color: "hsl(45 100% 50%)" }}>
              {t("monitoring.sentinel_gate", locale)}
            </h2>
          </div>
          <span className="text-[9px] px-2 py-1 rounded-full font-mono" style={{ background: "hsl(45 100% 50% / 0.1)", color: "hsl(45 100% 50%)" }}>
            THRESHOLD: 0.999
          </span>
        </div>
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg text-center" style={{ background: "hsl(220 10% 8%)" }}>
            <p className="text-2xl font-bold font-mono" style={{ color: "hsl(45 100% 50%)" }}>0.912</p>
            <p className="text-[9px] uppercase tracking-wider mt-1" style={{ color: "hsl(220 10% 45%)" }}>
              P(model{'>'}baseline)
            </p>
          </div>
          <div className="p-3 rounded-lg text-center" style={{ background: "hsl(220 10% 8%)" }}>
            <p className="text-2xl font-bold font-mono" style={{ color: "hsl(0 72% 60%)" }}>BLOCKED</p>
            <p className="text-[9px] uppercase tracking-wider mt-1" style={{ color: "hsl(220 10% 45%)" }}>
              Gate Status
            </p>
          </div>
          <div className="p-3 rounded-lg text-center" style={{ background: "hsl(220 10% 8%)" }}>
            <p className="text-2xl font-bold font-mono" style={{ color: "hsl(180 100% 50%)" }}>0.086</p>
            <p className="text-[9px] uppercase tracking-wider mt-1" style={{ color: "hsl(220 10% 45%)" }}>
              {locale === "pt-BR" ? "Distancia para 0.999" : "Distance to 0.999"}
            </p>
          </div>
        </div>
      </div>

      {/* AI Models Panel */}
      <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(180 100% 50% / 0.12)" }}>
        <div className="flex items-center gap-2 mb-4">
          <Brain className="w-5 h-5" style={{ color: "hsl(180 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "IAs Trabalhando e Estudando" : "AIs Working and Studying"}
          </h2>
          <span className="text-[9px] px-2 py-0.5 rounded-full ml-auto" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}>
            {AI_MODELS.filter((m) => m.status === "active").length}/{AI_MODELS.length} {locale === "pt-BR" ? "ativos" : "active"}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {AI_MODELS.map((model) => (
            <div key={model.name} className="rounded-lg border p-4 transition-all" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: statusColor(model.status) }} />
                  <span className="text-xs font-bold font-mono" style={{ color: model.color }}>{model.name}</span>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: statusColor(model.status) + "15", color: statusColor(model.status) }}>
                  {statusLabel(model.status)}
                </span>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-[10px]">
                  <span style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Confianca" : "Confidence"}</span>
                  <span className="font-mono font-bold" style={{ color: model.color }}>{(model.confidence * 100).toFixed(1)}%</span>
                </div>
                <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: "hsl(220 10% 12%)" }}>
                  <div className="h-full rounded-full transition-all" style={{ width: `${model.confidence * 100}%`, background: model.color }} />
                </div>

                <div className="flex justify-between text-[10px]">
                  <span style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Acuracia" : "Accuracy"}</span>
                  <span className="font-mono" style={{ color: "hsl(200 20% 90%)" }}>{model.accuracy}%</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Tempo de proc." : "Processing"}</span>
                  <span className="font-mono" style={{ color: "hsl(200 20% 90%)" }}>{model.processingTime}s</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span style={{ color: "hsl(220 10% 50%)" }}>Dataset</span>
                  <span className="font-mono" style={{ color: "hsl(200 20% 90%)" }}>{model.datasetSize.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Ultima exec." : "Last run"}</span>
                  <span className="font-mono" style={{ color: "hsl(220 10% 40%)" }}>{model.lastRun}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* AI Confidence Evolution */}
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
            <h3 className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Evolucao de Confianca dos Modelos" : "Model Confidence Evolution"}
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={confidenceHistory}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 10% 12%)" />
                <XAxis dataKey="epoch" tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <YAxis domain={[0.7, 1]} tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <Tooltip
                  contentStyle={{ background: "hsl(220 15% 8%)", border: "1px solid hsl(220 10% 16%)", borderRadius: 8, fontSize: 10, color: "hsl(200 20% 90%)" }}
                  formatter={(value: number) => [(value * 100).toFixed(2) + "%"]}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Line type="monotone" dataKey="certus" stroke="hsl(180 100% 50%)" strokeWidth={2} dot={false} name="CertusV2" />
                <Line type="monotone" dataKey="bayesian" stroke="hsl(142 71% 45%)" strokeWidth={2} dot={false} name="BayesianNet" />
                <Line type="monotone" dataKey="markov" stroke="hsl(45 100% 50%)" strokeWidth={2} dot={false} name="MarkovChain" />
                <Line type="monotone" dataKey="neural" stroke="hsl(280 80% 60%)" strokeWidth={2} dot={false} name="NeuralFreq" />
                <Line type="monotone" dataKey="temporal" stroke="hsl(0 72% 60%)" strokeWidth={2} dot={false} name="TemporalGAN" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* System Performance */}
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Activity className="w-4 h-4" style={{ color: "hsl(142 71% 45%)" }} />
            <h3 className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Performance do Sistema (24h)" : "System Performance (24h)"}
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={systemMetrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 10% 12%)" />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <YAxis tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <Tooltip
                  contentStyle={{ background: "hsl(220 15% 8%)", border: "1px solid hsl(220 10% 16%)", borderRadius: 8, fontSize: 10, color: "hsl(200 20% 90%)" }}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Area type="monotone" dataKey="cpu" stroke="hsl(180 100% 50%)" fill="hsl(180 100% 50% / 0.1)" strokeWidth={2} name="CPU %" />
                <Area type="monotone" dataKey="memory" stroke="hsl(142 71% 45%)" fill="hsl(142 71% 45% / 0.1)" strokeWidth={2} name="Memory %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lottery Analysis Coverage */}
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <BarChart3 className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
            <h3 className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Concursos Analisados por Loteria" : "Contests Analyzed per Lottery"}
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lotteryAnalysis}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 10% 12%)" />
                <XAxis dataKey="name" tick={{ fontSize: 8, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <YAxis tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <Tooltip
                  contentStyle={{ background: "hsl(220 15% 8%)", border: "1px solid hsl(220 10% 16%)", borderRadius: 8, fontSize: 10, color: "hsl(200 20% 90%)" }}
                />
                <Bar dataKey="analyzed" name={locale === "pt-BR" ? "Analisados" : "Analyzed"} radius={[4, 4, 0, 0]}>
                  {lotteryAnalysis.map((entry, index) => (
                    <Cell key={index} fill={entry.color} fillOpacity={0.7} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Model Performance Radar */}
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Eye className="w-4 h-4" style={{ color: "hsl(280 80% 60%)" }} />
            <h3 className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Performance Geral do Ensemble" : "Overall Ensemble Performance"}
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="hsl(220 10% 14%)" />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 9, fill: "hsl(220 10% 50%)" }} />
                <PolarRadiusAxis tick={{ fontSize: 8, fill: "hsl(220 10% 35%)" }} domain={[0, 100]} />
                <Radar name="Ensemble" dataKey="value" stroke="hsl(180 100% 50%)" fill="hsl(180 100% 50%)" fillOpacity={0.15} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Request Volume */}
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
            <h3 className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Volume de Requisicoes e Latencia" : "Request Volume & Latency"}
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={systemMetrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 10% 12%)" />
                <XAxis dataKey="time" tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <YAxis yAxisId="left" tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 9, fill: "hsl(220 10% 40%)" }} stroke="hsl(220 10% 14%)" />
                <Tooltip
                  contentStyle={{ background: "hsl(220 15% 8%)", border: "1px solid hsl(220 10% 16%)", borderRadius: 8, fontSize: 10, color: "hsl(200 20% 90%)" }}
                />
                <Legend wrapperStyle={{ fontSize: 9 }} />
                <Bar yAxisId="left" dataKey="requests" fill="hsl(180 100% 50% / 0.5)" name={locale === "pt-BR" ? "Requisicoes" : "Requests"} radius={[4, 4, 0, 0]} />
                <Line yAxisId="right" type="monotone" dataKey="latency" stroke="hsl(45 100% 50%)" strokeWidth={2} dot={false} name="Latency (ms)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Dataset Distribution */}
        <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
          <div className="flex items-center gap-2 mb-4">
            <HardDrive className="w-4 h-4" style={{ color: "hsl(142 71% 45%)" }} />
            <h3 className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? "Distribuicao de Dataset por Modelo" : "Dataset Distribution per Model"}
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={modelDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={90}
                  innerRadius={50}
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  labelLine={{ stroke: "hsl(220 10% 30%)" }}
                >
                  {modelDistribution.map((entry, index) => (
                    <Cell key={index} fill={entry.color} fillOpacity={0.8} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: "hsl(220 15% 8%)", border: "1px solid hsl(220 10% 16%)", borderRadius: 8, fontSize: 10, color: "hsl(200 20% 90%)" }}
                  formatter={(value: number) => [value.toLocaleString() + " records"]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Source Health */}
      <div className="rounded-xl border p-5" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center gap-2 mb-4">
          <Lock className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {t("monitoring.source_health", locale)}
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <SourceCard
            name="apiloterias.com.br"
            status="healthy"
            latency={45}
            lastCheck="30s ago"
            locale={locale}
          />
          <SourceCard
            name="Supabase Database"
            status="healthy"
            latency={12}
            lastCheck="15s ago"
            locale={locale}
          />
          <SourceCard
            name="Cross-Validation"
            status="healthy"
            latency={0}
            lastCheck="2m ago"
            locale={locale}
          />
        </div>
      </div>
    </div>
  )
}

function StatusCard({ icon, label, value, color, detail }: {
  icon: React.ReactNode
  label: string
  value: string
  color: string
  detail: string
}) {
  return (
    <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
      <div className="flex items-center gap-2 mb-2" style={{ color }}>
        {icon}
        <span className="text-[10px] uppercase tracking-wider font-semibold" style={{ color: "hsl(220 10% 50%)" }}>{label}</span>
      </div>
      <p className="text-lg font-bold font-mono" style={{ color }}>{value}</p>
      <p className="text-[9px] font-mono mt-1" style={{ color: "hsl(220 10% 40%)" }}>{detail}</p>
    </div>
  )
}

function SourceCard({ name, status, latency, lastCheck, locale }: {
  name: string
  status: "healthy" | "degraded" | "down"
  latency: number
  lastCheck: string
  locale: "pt-BR" | "en"
}) {
  const icon = status === "healthy" ? <CheckCircle className="w-4 h-4" /> : status === "degraded" ? <AlertTriangle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />
  const color = status === "healthy" ? "hsl(142 71% 45%)" : status === "degraded" ? "hsl(45 100% 50%)" : "hsl(0 72% 51%)"
  const label = locale === "pt-BR"
    ? (status === "healthy" ? "Saudavel" : status === "degraded" ? "Degradado" : "Inativo")
    : (status === "healthy" ? "Healthy" : status === "degraded" ? "Degraded" : "Down")

  return (
    <div className="rounded-lg border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-mono font-bold" style={{ color: "hsl(200 20% 90%)" }}>{name}</span>
        <span style={{ color }}>{icon}</span>
      </div>
      <div className="space-y-1 text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>
        <div className="flex justify-between">
          <span>Status</span>
          <span className="font-semibold" style={{ color }}>{label}</span>
        </div>
        {latency > 0 && (
          <div className="flex justify-between">
            <span>{locale === "pt-BR" ? "Latencia" : "Latency"}</span>
            <span className="font-mono" style={{ color: "hsl(200 20% 90%)" }}>{latency}ms</span>
          </div>
        )}
        <div className="flex justify-between">
          <span>{locale === "pt-BR" ? "Ultima verificacao" : "Last check"}</span>
          <span className="font-mono" style={{ color: "hsl(220 10% 40%)" }}>{lastCheck}</span>
        </div>
      </div>
    </div>
  )
}
