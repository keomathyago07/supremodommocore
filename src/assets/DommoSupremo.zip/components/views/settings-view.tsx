"use client"

import { useState, useEffect } from "react"
import { useApp } from "@/lib/store"
import { t, localeNames, type Locale } from "@/lib/i18n"
import {
  Settings, Globe, Key, Wifi, WifiOff, Check, Database, RefreshCw, Shield,
  Download, HardDrive, Brain, Clock, Bell, Plus, Trash2, Dices,
  Smartphone, Monitor, Zap, Target, Activity, Cpu, Layers, Gauge, BarChart3,
} from "lucide-react"

interface SyncStatusItem { lottery_id: string; last_sync_at: string; last_contest_id: number; status: string }

interface CustomLottery { id: string; name: string; apiSlug: string; minNum: number; maxNum: number; pickCount: number; drawDays: number[]; prizeTiers: string[]; color: string }

function CustomLotteriesSection({ locale }: { locale: string }) {
  const [customs, setCustoms] = useState<CustomLottery[]>([])
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<CustomLottery>({ id: "", name: "", apiSlug: "", minNum: 1, maxNum: 60, pickCount: 6, drawDays: [], prizeTiers: [""], color: "#00E5FF" })
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    const s = localStorage.getItem("dommo_custom_lotteries")
    if (s) setCustoms(JSON.parse(s))
  }, [])

  const dayNames = locale === "pt-BR"
    ? ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sab"]
    : ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

  const toggleDay = (d: number) => {
    setForm(f => ({ ...f, drawDays: f.drawDays.includes(d) ? f.drawDays.filter(x => x !== d) : [...f.drawDays, d].sort() }))
  }

  const addTier = () => setForm(f => ({ ...f, prizeTiers: [...f.prizeTiers, ""] }))
  const removeTier = (i: number) => setForm(f => ({ ...f, prizeTiers: f.prizeTiers.filter((_, idx) => idx !== i) }))
  const updateTier = (i: number, v: string) => setForm(f => ({ ...f, prizeTiers: f.prizeTiers.map((t, idx) => idx === i ? v : t) }))

  const handleSave = () => {
    if (!form.name || !form.apiSlug || form.drawDays.length === 0 || form.prizeTiers.filter(Boolean).length === 0) return
    const newLottery = { ...form, id: form.apiSlug.toLowerCase().replace(/[^a-z0-9]/g, "") }
    const updated = [...customs.filter(c => c.id !== newLottery.id), newLottery]
    setCustoms(updated)
    localStorage.setItem("dommo_custom_lotteries", JSON.stringify(updated))
    setShowForm(false)
    setForm({ id: "", name: "", apiSlug: "", minNum: 1, maxNum: 60, pickCount: 6, drawDays: [], prizeTiers: [""], color: "#00E5FF" })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleDelete = (id: string) => {
    const updated = customs.filter(c => c.id !== id)
    setCustoms(updated)
    localStorage.setItem("dommo_custom_lotteries", JSON.stringify(updated))
  }

  const sectionStyle = { background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }
  const inputStyle = { background: "hsl(220 10% 10%)", borderColor: "hsl(220 10% 16%)", color: "hsl(200 20% 95%)" }

  return (
    <div className="rounded-xl border p-6" style={sectionStyle}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Dices className="w-4 h-4" style={{ color: "hsl(280 60% 55%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Loterias Personalizadas" : "Custom Lotteries"}
          </h2>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[10px] font-medium" style={{ background: "hsl(280 60% 55% / 0.1)", color: "hsl(280 60% 55%)", border: "1px solid hsl(280 60% 55% / 0.3)" }}>
          <Plus className="w-3 h-3" /> {locale === "pt-BR" ? "Adicionar Loteria" : "Add Lottery"}
        </button>
      </div>

      <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
        {locale === "pt-BR" ? "Adicione qualquer nova loteria que a Caixa criar. Defina os padroes de acerto e o programa sincroniza automaticamente." : "Add any new lottery Caixa creates. Define hit patterns and the program syncs automatically."}
      </p>

      {saved && <div className="flex items-center gap-1 px-3 py-2 mb-3 rounded-lg text-xs" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}><Check className="w-3 h-3" /> {locale === "pt-BR" ? "Loteria salva com sucesso!" : "Lottery saved!"}</div>}

      {/* Existing custom lotteries */}
      {customs.length > 0 && (
        <div className="space-y-2 mb-4">
          {customs.map(c => (
            <div key={c.id} className="flex items-center justify-between px-3 py-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ background: c.color }} />
                <span className="text-xs font-bold" style={{ color: "hsl(200 20% 95%)" }}>{c.name}</span>
                <span className="text-[9px] font-mono" style={{ color: "hsl(220 10% 45%)" }}>/{c.apiSlug}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[9px]" style={{ color: "hsl(220 10% 45%)" }}>{c.prizeTiers.filter(Boolean).length} {locale === "pt-BR" ? "faixas" : "tiers"}</span>
                <button onClick={() => handleDelete(c.id)} className="p-1 rounded hover:bg-white/5"><Trash2 className="w-3 h-3" style={{ color: "hsl(0 72% 60%)" }} /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add form */}
      {showForm && (
        <div className="space-y-4 p-4 rounded-lg" style={{ background: "hsl(220 10% 8%)" }}>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] block mb-1" style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Nome da Loteria" : "Lottery Name"}</label>
              <input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Ex: Nova Loteria" className="w-full px-3 py-2 rounded-lg text-xs border outline-none" style={inputStyle} />
            </div>
            <div>
              <label className="text-[10px] block mb-1" style={{ color: "hsl(220 10% 50%)" }}>API Slug</label>
              <input value={form.apiSlug} onChange={e => setForm(f => ({ ...f, apiSlug: e.target.value }))} placeholder="Ex: nova-loteria" className="w-full px-3 py-2 rounded-lg text-xs border outline-none font-mono" style={inputStyle} />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-[10px] block mb-1" style={{ color: "hsl(220 10% 50%)" }}>Min</label>
              <input type="number" value={form.minNum} onChange={e => setForm(f => ({ ...f, minNum: +e.target.value }))} className="w-full px-3 py-2 rounded-lg text-xs border outline-none font-mono" style={inputStyle} />
            </div>
            <div>
              <label className="text-[10px] block mb-1" style={{ color: "hsl(220 10% 50%)" }}>Max</label>
              <input type="number" value={form.maxNum} onChange={e => setForm(f => ({ ...f, maxNum: +e.target.value }))} className="w-full px-3 py-2 rounded-lg text-xs border outline-none font-mono" style={inputStyle} />
            </div>
            <div>
              <label className="text-[10px] block mb-1" style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Escolher" : "Pick"}</label>
              <input type="number" value={form.pickCount} onChange={e => setForm(f => ({ ...f, pickCount: +e.target.value }))} className="w-full px-3 py-2 rounded-lg text-xs border outline-none font-mono" style={inputStyle} />
            </div>
          </div>
          <div>
            <label className="text-[10px] block mb-1" style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Cor" : "Color"}</label>
            <input type="color" value={form.color} onChange={e => setForm(f => ({ ...f, color: e.target.value }))} className="w-10 h-8 rounded border-0 cursor-pointer" />
          </div>
          <div>
            <label className="text-[10px] block mb-2" style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Dias de Sorteio" : "Draw Days"}</label>
            <div className="flex gap-1.5">
              {dayNames.map((name, i) => (
                <button key={i} onClick={() => toggleDay(i)} className="px-2.5 py-1.5 rounded-lg text-[10px] font-medium transition-all" style={{ background: form.drawDays.includes(i) ? "hsl(180 100% 50% / 0.15)" : "hsl(220 10% 12%)", color: form.drawDays.includes(i) ? "hsl(180 100% 50%)" : "hsl(220 10% 40%)", border: `1px solid ${form.drawDays.includes(i) ? "hsl(180 100% 50% / 0.3)" : "hsl(220 10% 18%)"}` }}>
                  {name}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>{locale === "pt-BR" ? "Padroes de Acerto" : "Hit Patterns"}</label>
              <button onClick={addTier} className="text-[10px] px-2 py-1 rounded" style={{ color: "hsl(180 100% 50%)" }}><Plus className="w-3 h-3 inline" /> {locale === "pt-BR" ? "Adicionar" : "Add"}</button>
            </div>
            <div className="space-y-2">
              {form.prizeTiers.map((tier, i) => (
                <div key={i} className="flex items-center gap-2">
                  <input value={tier} onChange={e => updateTier(i, e.target.value)} placeholder={`Ex: ${6 - i} acertos`} className="flex-1 px-3 py-2 rounded-lg text-xs border outline-none" style={inputStyle} />
                  {form.prizeTiers.length > 1 && <button onClick={() => removeTier(i)} className="p-1"><Trash2 className="w-3 h-3" style={{ color: "hsl(0 72% 60%)" }} /></button>}
                </div>
              ))}
            </div>
          </div>
          <button onClick={handleSave} className="w-full px-4 py-2.5 rounded-lg text-xs font-bold" style={{ background: "hsl(280 60% 55% / 0.15)", color: "hsl(280 60% 55%)", border: "1px solid hsl(280 60% 55% / 0.3)" }}>
            {locale === "pt-BR" ? "Salvar Loteria e Sincronizar" : "Save Lottery & Sync"}
          </button>
        </div>
      )}
    </div>
  )
}

interface DeviceInfo { id: number; device_id: string; device_name: string; device_type: string; last_sync_at: string }
interface ConfidenceLog { id: number; lottery_id: string; lottery_name: string; contest_id: number; confidence: number; gate_status: string; model_name: string; numbers: number[]; triggered_at: string; year: number; month: number; day: number; hour: number; minute: number }

function AdvancedAISection({ locale }: { locale: string }) {
  const [aiModels, setAiModels] = useState({
    useBayesian: true, useMarkov: true, useNeural: true, useTemporal: true, useEnsemble: true,
    frequencyWeight: 35, patternWeight: 25, recencyWeight: 20, gapWeight: 20,
    autoRetrain: true, adaptiveThreshold: true, multiModelConsensus: true,
  })
  const [aiSaved, setAiSaved] = useState(false)

  useEffect(() => {
    const s = localStorage.getItem("dommo_ai_config")
    if (s) setAiModels(JSON.parse(s))
  }, [])

  const handleSaveAI = () => {
    localStorage.setItem("dommo_ai_config", JSON.stringify(aiModels))
    setAiSaved(true)
    setTimeout(() => setAiSaved(false), 2000)
    // Also push to DB
    fetch("/api/lottery/confidence-log", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ lottery_id: "system", lottery_name: "AI Config Update", confidence: 1, gate_status: "CONFIG", model_name: "system", notes: JSON.stringify(aiModels) }) }).catch(() => {})
  }

  const sectionStyle = { background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }

  return (
    <div className="rounded-xl border p-6" style={sectionStyle}>
      <div className="flex items-center gap-2 mb-2">
        <Cpu className="w-4 h-4" style={{ color: "hsl(280 60% 55%)" }} />
        <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
          {locale === "pt-BR" ? "Configuracao Avancada de IA" : "Advanced AI Configuration"}
        </h2>
        <span className="text-[9px] px-2 py-0.5 rounded-full animate-pulse" style={{ background: "hsl(280 60% 55% / 0.1)", color: "hsl(280 60% 55%)" }}>SUPER AI</span>
      </div>
      <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
        {locale === "pt-BR" ? "Configure os modelos de IA e pesos para maximizar a precisao das previsoes. Todos os modelos trabalham em conjunto para encontrar os melhores numeros." : "Configure AI models and weights to maximize prediction accuracy. All models work together to find the best numbers."}
      </p>

      {/* AI Models Toggle */}
      <div className="mb-4">
        <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: "hsl(220 10% 50%)" }}>
          {locale === "pt-BR" ? "Modelos Ativos" : "Active Models"}
        </p>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {[
            { key: "useBayesian", name: "BayesianNet", icon: BarChart3, desc: locale === "pt-BR" ? "Redes Bayesianas" : "Bayesian Networks" },
            { key: "useMarkov", name: "MarkovChain", icon: Layers, desc: locale === "pt-BR" ? "Cadeias de Markov" : "Markov Chains" },
            { key: "useNeural", name: "NeuralFreq", icon: Brain, desc: locale === "pt-BR" ? "Redes Neurais de Frequencia" : "Neural Frequency Networks" },
            { key: "useTemporal", name: "TemporalGAN", icon: Activity, desc: locale === "pt-BR" ? "GAN Temporal" : "Temporal GAN" },
            { key: "useEnsemble", name: "CertusV2", icon: Target, desc: locale === "pt-BR" ? "Ensemble Certus v2" : "Certus v2 Ensemble" },
          ].map(({ key, name, icon: Icon, desc }) => (
            <button key={key} onClick={() => setAiModels(p => ({ ...p, [key]: !p[key as keyof typeof p] }))} className="flex items-start gap-2 p-3 rounded-lg text-left transition-all" style={{ background: aiModels[key as keyof typeof aiModels] ? "hsl(280 60% 55% / 0.08)" : "hsl(220 10% 10%)", border: `1px solid ${aiModels[key as keyof typeof aiModels] ? "hsl(280 60% 55% / 0.3)" : "hsl(220 10% 16%)"}` }}>
              <Icon className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" style={{ color: aiModels[key as keyof typeof aiModels] ? "hsl(280 60% 55%)" : "hsl(220 10% 40%)" }} />
              <div>
                <span className="text-[10px] font-bold block" style={{ color: aiModels[key as keyof typeof aiModels] ? "hsl(280 60% 55%)" : "hsl(220 10% 50%)" }}>{name}</span>
                <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>{desc}</span>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Weights */}
      <div className="mb-4">
        <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: "hsl(220 10% 50%)" }}>
          {locale === "pt-BR" ? "Pesos de Analise (%)" : "Analysis Weights (%)"}
        </p>
        <div className="grid grid-cols-2 gap-3">
          {[
            { key: "frequencyWeight", label: locale === "pt-BR" ? "Frequencia" : "Frequency" },
            { key: "patternWeight", label: locale === "pt-BR" ? "Padroes" : "Patterns" },
            { key: "recencyWeight", label: locale === "pt-BR" ? "Recencia" : "Recency" },
            { key: "gapWeight", label: locale === "pt-BR" ? "Lacunas" : "Gaps" },
          ].map(({ key, label }) => (
            <div key={key} className="p-3 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>{label}</span>
                <span className="text-[10px] font-bold font-mono" style={{ color: "hsl(280 60% 55%)" }}>{aiModels[key as keyof typeof aiModels]}%</span>
              </div>
              <input type="range" min={0} max={100} value={Number(aiModels[key as keyof typeof aiModels])} onChange={e => setAiModels(p => ({ ...p, [key]: Number(e.target.value) }))} className="w-full h-1 rounded-full appearance-none cursor-pointer" style={{ background: "hsl(220 10% 16%)" }} />
            </div>
          ))}
        </div>
      </div>

      {/* Smart Features */}
      <div className="mb-4">
        <p className="text-[10px] font-bold uppercase tracking-wider mb-2" style={{ color: "hsl(220 10% 50%)" }}>
          {locale === "pt-BR" ? "Recursos Inteligentes" : "Smart Features"}
        </p>
        <div className="space-y-2">
          {[
            { key: "autoRetrain", label: locale === "pt-BR" ? "Re-treino automatico apos cada sorteio" : "Auto-retrain after each draw", desc: locale === "pt-BR" ? "IA aprende com cada resultado novo" : "AI learns from each new result" },
            { key: "adaptiveThreshold", label: locale === "pt-BR" ? "Threshold adaptativo de confianca" : "Adaptive confidence threshold", desc: locale === "pt-BR" ? "Ajusta automaticamente o criterio 0.999 baseado no historico" : "Automatically adjusts 0.999 criteria based on history" },
            { key: "multiModelConsensus", label: locale === "pt-BR" ? "Consenso multi-modelo" : "Multi-model consensus", desc: locale === "pt-BR" ? "Requer que multiplos modelos concordem antes de sugerir" : "Requires multiple models to agree before suggesting" },
          ].map(({ key, label, desc }) => (
            <button key={key} onClick={() => setAiModels(p => ({ ...p, [key]: !p[key as keyof typeof p] }))} className="w-full flex items-center justify-between p-3 rounded-lg transition-all" style={{ background: "hsl(220 10% 10%)", border: `1px solid ${aiModels[key as keyof typeof aiModels] ? "hsl(142 71% 45% / 0.3)" : "hsl(220 10% 16%)"}` }}>
              <div className="text-left">
                <span className="text-[10px] font-bold block" style={{ color: "hsl(200 20% 90%)" }}>{label}</span>
                <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>{desc}</span>
              </div>
              <div className="w-8 h-4 rounded-full flex-shrink-0" style={{ background: aiModels[key as keyof typeof aiModels] ? "hsl(142 71% 45%)" : "hsl(220 10% 20%)" }}>
                <div className="w-3.5 h-3.5 rounded-full transition-all" style={{ background: "hsl(200 20% 95%)", marginLeft: aiModels[key as keyof typeof aiModels] ? "16px" : "1px", marginTop: "0.5px" }} />
              </div>
            </button>
          ))}
        </div>
      </div>

      <button onClick={handleSaveAI} className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold" style={{ background: aiSaved ? "hsl(142 71% 45% / 0.15)" : "hsl(280 60% 55% / 0.15)", color: aiSaved ? "hsl(142 71% 45%)" : "hsl(280 60% 55%)", border: `1px solid ${aiSaved ? "hsl(142 71% 45% / 0.3)" : "hsl(280 60% 55% / 0.3)"}` }}>
        {aiSaved ? <><Check className="w-3 h-3" /> {locale === "pt-BR" ? "Configuracao Salva" : "Config Saved"}</> : <><Zap className="w-3 h-3" /> {locale === "pt-BR" ? "Salvar Configuracao de IA" : "Save AI Configuration"}</>}
      </button>
    </div>
  )
}

function DeviceSyncSection({ locale }: { locale: string }) {
  const [devices, setDevices] = useState<DeviceInfo[]>([])
  const [loading, setLoading] = useState(false)
  const [deviceId] = useState(() => typeof window !== "undefined" ? (localStorage.getItem("dommo_device_id") || (() => { const id = `device-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`; localStorage.setItem("dommo_device_id", id); return id })()) : "unknown")

  const loadDevices = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/lottery/device-sync")
      const data = await res.json()
      setDevices(data.devices || [])
    } catch { /* ignore */ }
    setLoading(false)
  }

  const syncNow = async () => {
    setLoading(true)
    try {
      await fetch("/api/lottery/device-sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          device_id: deviceId,
          device_name: typeof navigator !== "undefined" ? navigator.userAgent.slice(0, 60) : "unknown",
          device_type: typeof navigator !== "undefined" && /Mobi|Android/i.test(navigator.userAgent) ? "mobile" : "desktop",
          sync_data: { last_sync: new Date().toISOString(), locale: localStorage.getItem("dommo_locale") || "pt-BR", active_view: "settings" },
        }),
      })
      await loadDevices()
    } catch { /* ignore */ }
    setLoading(false)
  }

  useEffect(() => { loadDevices() }, [])

  const sectionStyle = { background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }
  const isMobile = typeof navigator !== "undefined" && /Mobi|Android/i.test(navigator.userAgent)

  return (
    <div className="rounded-xl border p-6" style={sectionStyle}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          {isMobile ? <Smartphone className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} /> : <Monitor className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />}
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Sincronizacao de Dispositivos" : "Device Synchronization"}
          </h2>
        </div>
        <button onClick={syncNow} disabled={loading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[10px]" style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)", border: "1px solid hsl(180 100% 50% / 0.3)" }}>
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} /> {locale === "pt-BR" ? "Sincronizar Agora" : "Sync Now"}
        </button>
      </div>
      <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
        {locale === "pt-BR" ? "Tudo que aparecer em um dispositivo estara sincronizado no outro. Sugestoes, apostas confirmadas e resultados sao compartilhados via banco de dados." : "Everything that appears on one device will be synced to the other. Suggestions, confirmed bets, and results are shared via database."}
      </p>

      <div className="p-3 rounded-lg mb-3 flex items-center gap-2" style={{ background: "hsl(180 100% 50% / 0.05)", border: "1px solid hsl(180 100% 50% / 0.12)" }}>
        <Gauge className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
        <div>
          <p className="text-[10px] font-bold" style={{ color: "hsl(180 100% 50%)" }}>
            {locale === "pt-BR" ? "Este dispositivo" : "This device"}: {isMobile ? "Mobile" : "Desktop"}
          </p>
          <p className="text-[9px] font-mono" style={{ color: "hsl(220 10% 40%)" }}>ID: {deviceId.slice(0, 20)}...</p>
        </div>
      </div>

      {devices.length > 0 && (
        <div className="space-y-2">
          <p className="text-[9px] font-bold uppercase tracking-wider" style={{ color: "hsl(220 10% 45%)" }}>
            {locale === "pt-BR" ? "Dispositivos Registrados" : "Registered Devices"} ({devices.length})
          </p>
          {devices.map((d) => (
            <div key={d.id} className="flex items-center justify-between px-3 py-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
              <div className="flex items-center gap-2">
                {d.device_type === "mobile" ? <Smartphone className="w-3 h-3" style={{ color: "hsl(180 100% 50%)" }} /> : <Monitor className="w-3 h-3" style={{ color: "hsl(142 71% 45%)" }} />}
                <div>
                  <span className="text-[10px] font-bold" style={{ color: "hsl(200 20% 90%)" }}>{d.device_type === "mobile" ? "Mobile" : "Desktop"}</span>
                  <span className="text-[9px] ml-2 font-mono" style={{ color: "hsl(220 10% 40%)" }}>{d.device_id.slice(0, 16)}...</span>
                </div>
              </div>
              <span className="text-[9px]" style={{ color: "hsl(220 10% 45%)" }}>
                {new Date(d.last_sync_at).toLocaleString("pt-BR")}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function ConfidenceLogsSection({ locale }: { locale: string }) {
  const [logs, setLogs] = useState<ConfidenceLog[]>([])
  const [loading, setLoading] = useState(false)
  const [expandedLottery, setExpandedLottery] = useState<string | null>(null)

  const loadLogs = async () => {
    setLoading(true)
    try {
      const res = await fetch("/api/lottery/confidence-log")
      const data = await res.json()
      setLogs((data.logs || []).filter((l: ConfidenceLog) => l.lottery_id !== "system"))
    } catch { /* ignore */ }
    setLoading(false)
  }

  useEffect(() => { loadLogs() }, [])

  const sectionStyle = { background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }

  // Group logs by lottery
  const grouped: Record<string, ConfidenceLog[]> = {}
  logs.forEach(log => {
    if (!grouped[log.lottery_id]) grouped[log.lottery_id] = []
    grouped[log.lottery_id].push(log)
  })

  const lotteryColors: Record<string, string> = {
    megasena: "#209869", lotofacil: "#930089", quina: "#260085", lotomania: "#F78100",
    timemania: "#00FF48", duplasena: "#A61324", diadesorte: "#CB7917", supersete: "#A8CF45", maismilionaria: "#002B5C",
  }

  return (
    <div className="rounded-xl border p-6" style={sectionStyle}>
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4" style={{ color: "hsl(142 71% 45%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Historico Gate de Confianca 0.999" : "Confidence Gate 0.999 History"}
          </h2>
          <span className="text-[9px] px-2 py-0.5 rounded-full" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}>
            {logs.filter(l => l.gate_status === "APPROVED").length} APPROVED
          </span>
        </div>
        <button onClick={loadLogs} disabled={loading} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[10px]" style={{ background: "hsl(220 10% 10%)", color: "hsl(220 10% 55%)", border: "1px solid hsl(220 10% 16%)" }}>
          <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} /> {locale === "pt-BR" ? "Atualizar" : "Refresh"}
        </button>
      </div>
      <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
        {locale === "pt-BR" ? "Registro permanente de todas as loterias que atingiram o gate de confianca 99.9%. Clique na loteria para ver os numeros, datas e horarios detalhados. Nunca e apagado." : "Permanent log of all lotteries that hit the 99.9% confidence gate. Click a lottery to see detailed numbers, dates, and times. Never deleted."}
      </p>

      {Object.keys(grouped).length === 0 ? (
        <div className="p-4 rounded-lg text-center text-[10px]" style={{ background: "hsl(220 10% 10%)", color: "hsl(220 10% 40%)" }}>
          {locale === "pt-BR" ? "Nenhuma loteria atingiu o gate 0.999 ainda" : "No lottery has hit the 0.999 gate yet"}
        </div>
      ) : (
        <div className="space-y-2 max-h-[500px] overflow-y-auto scrollbar-thin">
          {Object.entries(grouped).map(([lotteryId, lotteryLogs]) => {
            const color = lotteryColors[lotteryId] || "hsl(180 100% 50%)"
            const isExpanded = expandedLottery === lotteryId
            const approvedCount = lotteryLogs.filter(l => l.gate_status === "APPROVED").length
            const latest = lotteryLogs[0]

            return (
              <div key={lotteryId} className="rounded-lg overflow-hidden border" style={{ borderColor: isExpanded ? `${color}40` : "hsl(220 10% 14%)" }}>
                <button onClick={() => setExpandedLottery(isExpanded ? null : lotteryId)} className="w-full flex items-center justify-between p-3 transition-all" style={{ background: isExpanded ? `${color}08` : "hsl(220 10% 10%)" }}>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ background: color }} />
                    <span className="text-[11px] font-bold" style={{ color: "hsl(200 20% 90%)" }}>{latest.lottery_name}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full font-mono" style={{ background: `${color}15`, color }}>{lotteryLogs.length}</span>
                    {approvedCount > 0 && <span className="text-[8px] px-1.5 py-0.5 rounded-full" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}>{approvedCount} OK</span>}
                  </div>
                  <span className="text-[9px] font-mono" style={{ color: "hsl(220 10% 45%)" }}>
                    {String(latest.day).padStart(2, "0")}/{String(latest.month).padStart(2, "0")}/{latest.year}
                  </span>
                </button>

                {isExpanded && (
                  <div className="px-3 pb-3 space-y-2">
                    {lotteryLogs.map(log => (
                      <div key={log.id} className="rounded-lg p-3" style={{ background: "hsl(220 10% 8%)", border: `1px solid ${log.gate_status === "APPROVED" ? "hsl(142 71% 45% / 0.15)" : "hsl(220 10% 14%)"}` }}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 rounded-full" style={{ background: log.gate_status === "APPROVED" ? "hsl(142 71% 45%)" : "hsl(0 72% 51%)" }} />
                            <span className="text-[9px] font-bold" style={{ color: log.gate_status === "APPROVED" ? "hsl(142 71% 45%)" : "hsl(0 72% 60%)" }}>{log.gate_status}</span>
                            {log.contest_id > 0 && <span className="text-[9px] font-mono" style={{ color: "hsl(220 10% 45%)" }}>#{log.contest_id}</span>}
                          </div>
                          <span className="text-[9px] font-bold font-mono" style={{ color }}>{(Number(log.confidence) * 100).toFixed(2)}%</span>
                        </div>
                        {/* Numbers */}
                        {log.numbers && log.numbers.length > 0 && (
                          <div className="flex flex-wrap gap-1 mb-2">
                            {log.numbers.map((n, i) => (
                              <span key={i} className="w-7 h-7 rounded-md flex items-center justify-center text-[10px] font-bold font-mono" style={{ background: `${color}12`, color, border: `1px solid ${color}30` }}>
                                {String(n).padStart(2, "0")}
                              </span>
                            ))}
                          </div>
                        )}
                        <div className="flex items-center gap-3 text-[9px] font-mono" style={{ color: "hsl(220 10% 40%)" }}>
                          <span>{String(log.day).padStart(2, "0")}/{String(log.month).padStart(2, "0")}/{log.year}</span>
                          <span>{String(log.hour).padStart(2, "0")}:{String(log.minute).padStart(2, "0")}h</span>
                          <span>{log.model_name || "CertusV2"}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

function BackgroundSection({ locale }: { locale: string }) {
  const [bgEnabled, setBgEnabled] = useState(() => {
    if (typeof window === "undefined") return true
    return localStorage.getItem("dommo_background_enabled") !== "false"
  })
  const [swStatus, setSwStatus] = useState<"active" | "inactive" | "unsupported">("inactive")

  useEffect(() => {
    if (!("serviceWorker" in navigator)) { setSwStatus("unsupported"); return }
    navigator.serviceWorker.ready.then((reg) => {
      setSwStatus(reg.active ? "active" : "inactive")
    }).catch(() => setSwStatus("inactive"))
  }, [])

  const toggleBackground = () => {
    const newVal = !bgEnabled
    setBgEnabled(newVal)
    localStorage.setItem("dommo_background_enabled", String(newVal))
    if (newVal && "serviceWorker" in navigator) {
      navigator.serviceWorker.ready.then((reg) => {
        reg.active?.postMessage("START_SYNC")
      }).catch(() => {})
    }
  }

  const sectionStyle = { background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }

  return (
    <div className="rounded-xl border p-6" style={sectionStyle}>
      <div className="flex items-center gap-2 mb-2">
        <Cpu className="w-4 h-4" style={{ color: "hsl(280 60% 55%)" }} />
        <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
          {locale === "pt-BR" ? "Execucao em Segundo Plano" : "Background Execution"}
        </h2>
        <span className="text-[9px] px-2 py-0.5 rounded-full" style={{
          background: swStatus === "active" ? "hsl(142 71% 45% / 0.1)" : "hsl(0 72% 51% / 0.1)",
          color: swStatus === "active" ? "hsl(142 71% 45%)" : swStatus === "unsupported" ? "hsl(45 100% 50%)" : "hsl(0 72% 51%)"
        }}>
          {swStatus === "active" ? "ATIVO" : swStatus === "unsupported" ? "N/A" : "INATIVO"}
        </span>
      </div>
      <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
        {locale === "pt-BR"
          ? "O programa continua rodando em segundo plano via Service Worker, mesmo com o app minimizado ou fechado. Sincroniza dados, verifica resultados as 21:30h e envia notificacoes automaticamente."
          : "The program keeps running in the background via Service Worker, even with the app minimized or closed. Syncs data, checks results at 9:30 PM and sends notifications automatically."}
      </p>

      <button onClick={toggleBackground} className="w-full flex items-center justify-between p-4 rounded-lg transition-all mb-3" style={{ background: "hsl(220 10% 10%)", border: `1px solid ${bgEnabled ? "hsl(280 60% 55% / 0.3)" : "hsl(220 10% 16%)"}` }}>
        <div className="text-left">
          <span className="text-xs font-bold block" style={{ color: "hsl(200 20% 90%)" }}>
            {locale === "pt-BR" ? "Rodar em Segundo Plano" : "Run in Background"}
          </span>
          <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>
            {locale === "pt-BR" ? "Desktop e Mobile - Sincroniza, verifica e notifica automaticamente" : "Desktop & Mobile - Syncs, checks, and notifies automatically"}
          </span>
        </div>
        <div className="w-10 h-5 rounded-full flex-shrink-0" style={{ background: bgEnabled ? "hsl(280 60% 55%)" : "hsl(220 10% 20%)" }}>
          <div className="w-4 h-4 rounded-full transition-all" style={{ background: "hsl(200 20% 95%)", marginLeft: bgEnabled ? "22px" : "2px", marginTop: "2px" }} />
        </div>
      </button>

      <div className="grid grid-cols-2 gap-2 text-[9px]">
        <div className="p-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
          <span style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Sync automatico" : "Auto sync"}</span>
          <span className="block font-bold font-mono" style={{ color: "hsl(180 100% 50%)" }}>{locale === "pt-BR" ? "A cada 60s" : "Every 60s"}</span>
        </div>
        <div className="p-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
          <span style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Verificacao resultados" : "Results check"}</span>
          <span className="block font-bold font-mono" style={{ color: "hsl(45 100% 50%)" }}>21:30h + 22:00h</span>
        </div>
        <div className="p-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
          <span style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Notificacoes" : "Notifications"}</span>
          <span className="block font-bold font-mono" style={{ color: "hsl(142 71% 45%)" }}>{locale === "pt-BR" ? "Automaticas" : "Automatic"}</span>
        </div>
        <div className="p-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
          <span style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Config sincronizada" : "Synced config"}</span>
          <span className="block font-bold font-mono" style={{ color: "hsl(280 60% 55%)" }}>Cross-device</span>
        </div>
      </div>
    </div>
  )
}

export function SettingsView() {
  const { locale, setLocale, apiToken, setApiToken } = useApp()
  const [tokenInput, setTokenInput] = useState(apiToken)
  const [openaiKey, setOpenaiKey] = useState("")
  const [testStatus, setTestStatus] = useState<"idle" | "testing" | "success" | "error">("idle")
  const [saved, setSaved] = useState(false)
  const [openaiSaved, setOpenaiSaved] = useState(false)
  const [syncStatuses, setSyncStatuses] = useState<SyncStatusItem[]>([])
  const [recordCounts, setRecordCounts] = useState<Record<string, number>>({})
  const [totalRecords, setTotalRecords] = useState(0)
  const [loadingStatus, setLoadingStatus] = useState(false)
  const [notifHour, setNotifHour] = useState("10")
  const [notifMinute, setNotifMinute] = useState("00")
  const [notifSaved, setNotifSaved] = useState(false)

  useEffect(() => {
    setTokenInput(apiToken)
    const savedOAI = localStorage.getItem("dommo_openai_key")
    if (savedOAI) setOpenaiKey(savedOAI)
    const savedHour = localStorage.getItem("dommo_notif_hour")
    const savedMin = localStorage.getItem("dommo_notif_minute")
    if (savedHour) setNotifHour(savedHour)
    if (savedMin) setNotifMinute(savedMin)
  }, [apiToken])

  const handleSave = async () => {
    setApiToken(tokenInput)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
    // Auto-sync after saving token
    if (tokenInput) {
      try {
        await fetch(`/api/lottery/sync?token=${encodeURIComponent(tokenInput)}`)
      } catch { /* silent auto-sync */ }
    }
  }
  const handleOpenaiSave = () => { localStorage.setItem("dommo_openai_key", openaiKey); setOpenaiSaved(true); setTimeout(() => setOpenaiSaved(false), 2000) }
  const handleNotifSave = () => { localStorage.setItem("dommo_notif_hour", notifHour); localStorage.setItem("dommo_notif_minute", notifMinute); setNotifSaved(true); setTimeout(() => setNotifSaved(false), 2000); if ("Notification" in window) Notification.requestPermission() }

  const testConnection = async () => {
    if (!tokenInput) return
    setTestStatus("testing")
    try {
      const res = await fetch(`/api/lottery/megasena?token=${encodeURIComponent(tokenInput)}`)
      setTestStatus(res.ok ? "success" : "error")
    } catch { setTestStatus("error") }
    setTimeout(() => setTestStatus("idle"), 3000)
  }

  const loadDbStatus = async () => {
    setLoadingStatus(true)
    try {
      const res = await fetch("/api/lottery/status")
      const data = await res.json()
      setSyncStatuses(data.sync_status || []); setRecordCounts(data.record_counts || {}); setTotalRecords(data.total_records || 0)
    } catch { /* ignore */ }
    setLoadingStatus(false)
  }

  useEffect(() => { loadDbStatus() }, [])

  const sectionStyle = { background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }
  const inputStyle = { background: "hsl(220 10% 10%)", borderColor: "hsl(220 10% 16%)", color: "hsl(200 20% 95%)" }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>{t("settings.title", locale)}</h1>

      {/* Language */}
      <div className="rounded-xl border p-6" style={sectionStyle}>
        <div className="flex items-center gap-2 mb-4">
          <Globe className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{t("settings.language", locale)}</h2>
        </div>
        <div className="flex gap-3">
          {(Object.keys(localeNames) as Locale[]).map((loc) => (
            <button key={loc} onClick={() => setLocale(loc)} className="flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all" style={{ background: locale === loc ? "hsl(180 100% 50% / 0.1)" : "hsl(220 10% 10%)", color: locale === loc ? "hsl(180 100% 50%)" : "hsl(220 10% 55%)", border: `1px solid ${locale === loc ? "hsl(180 100% 50% / 0.3)" : "hsl(220 10% 16%)"}` }}>
              <span className="text-lg">{loc === "pt-BR" ? "BR" : "US"}</span><span>{localeNames[loc]}</span>{locale === loc && <Check className="w-4 h-4" />}
            </button>
          ))}
        </div>
      </div>

      {/* Notification Schedule */}
      <div className="rounded-xl border p-6" style={sectionStyle}>
        <div className="flex items-center gap-2 mb-2">
          <Bell className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Horario de Notificacoes" : "Notification Schedule"}
          </h2>
        </div>
        <p className="text-xs mb-4" style={{ color: "hsl(220 10% 50%)" }}>
          {locale === "pt-BR" ? "Defina a partir de que horario o programa enviara as sugestoes de loterias do dia" : "Set from which time the program will send today's lottery suggestions"}
        </p>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" style={{ color: "hsl(220 10% 50%)" }} />
            <select value={notifHour} onChange={(e) => setNotifHour(e.target.value)} className="px-3 py-2 rounded-lg text-sm border font-mono" style={inputStyle}>
              {Array.from({ length: 24 }, (_, i) => <option key={i} value={String(i).padStart(2, "0")}>{String(i).padStart(2, "0")}</option>)}
            </select>
            <span className="text-sm font-bold" style={{ color: "hsl(220 10% 50%)" }}>:</span>
            <select value={notifMinute} onChange={(e) => setNotifMinute(e.target.value)} className="px-3 py-2 rounded-lg text-sm border font-mono" style={inputStyle}>
              {["00", "15", "30", "45"].map((m) => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <button onClick={handleNotifSave} className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium" style={{ background: notifSaved ? "hsl(142 71% 45% / 0.15)" : "hsl(180 100% 50% / 0.1)", color: notifSaved ? "hsl(142 71% 45%)" : "hsl(180 100% 50%)", border: `1px solid ${notifSaved ? "hsl(142 71% 45% / 0.3)" : "hsl(180 100% 50% / 0.3)"}` }}>
            {notifSaved ? <Check className="w-3 h-3" /> : <Bell className="w-3 h-3" />}
            {notifSaved ? (locale === "pt-BR" ? "Salvo" : "Saved") : (locale === "pt-BR" ? "Salvar Horario" : "Save Time")}
          </button>
        </div>
        <p className="text-[10px] mt-3" style={{ color: "hsl(220 10% 35%)" }}>
          {locale === "pt-BR" ? `Notificacoes serao enviadas a partir das ${notifHour}:${notifMinute} nos dias de sorteio de cada loteria.` : `Notifications will be sent starting at ${notifHour}:${notifMinute} on draw days for each lottery.`}
        </p>
      </div>

      {/* API Token */}
      <div className="rounded-xl border p-6" style={sectionStyle}>
        <div className="flex items-center gap-2 mb-2">
          <Key className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{t("settings.api_section", locale)}</h2>
        </div>
        <p className="text-xs mb-4" style={{ color: "hsl(220 10% 50%)" }}>{t("settings.api_description", locale)}</p>
        <div className="flex flex-col gap-3">
          <input type="password" value={tokenInput} onChange={(e) => setTokenInput(e.target.value)} placeholder={t("settings.api_token_placeholder", locale)} className="flex-1 px-4 py-3 rounded-lg text-sm outline-none border font-mono" style={inputStyle} />
          <div className="flex gap-2">
            <button onClick={handleSave} className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-medium" style={{ background: saved ? "hsl(142 71% 45% / 0.15)" : "hsl(180 100% 50% / 0.1)", color: saved ? "hsl(142 71% 45%)" : "hsl(180 100% 50%)", border: `1px solid ${saved ? "hsl(142 71% 45% / 0.3)" : "hsl(180 100% 50% / 0.3)"}` }}>
              {saved ? <Check className="w-3 h-3" /> : <Download className="w-3 h-3" />} {saved ? t("settings.saved", locale) : t("settings.save", locale)}
            </button>
            <button onClick={testConnection} disabled={!tokenInput || testStatus === "testing"} className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-medium disabled:opacity-50" style={{ background: testStatus === "success" ? "hsl(142 71% 45% / 0.1)" : testStatus === "error" ? "hsl(0 72% 51% / 0.1)" : "hsl(220 10% 10%)", color: testStatus === "success" ? "hsl(142 71% 45%)" : testStatus === "error" ? "hsl(0 72% 60%)" : "hsl(220 10% 55%)", border: `1px solid ${testStatus === "success" ? "hsl(142 71% 45% / 0.3)" : testStatus === "error" ? "hsl(0 72% 51% / 0.3)" : "hsl(220 10% 16%)"}` }}>
              {testStatus === "testing" ? <RefreshCw className="w-3 h-3 animate-spin" /> : testStatus === "success" ? <Wifi className="w-3 h-3" /> : testStatus === "error" ? <WifiOff className="w-3 h-3" /> : <Wifi className="w-3 h-3" />}
              {testStatus === "testing" ? "..." : testStatus === "success" ? t("settings.connected", locale) : testStatus === "error" ? t("settings.disconnected", locale) : t("settings.test_connection", locale)}
            </button>
          </div>
        </div>
        <div className="mt-4 p-3 rounded-lg text-[10px] font-mono leading-relaxed" style={{ background: "hsl(220 10% 8%)", color: "hsl(220 10% 40%)" }}>
          <p>API URL: https://apiloterias.com.br/app/v2/resultado</p>
          <p>{locale === "pt-BR" ? "Cole o token, salve, e o sistema sincroniza automaticamente." : "Paste the token, save, and the system syncs automatically."}</p>
        </div>
      </div>

      {/* OpenAI API Key */}
      <div className="rounded-xl border p-6" style={sectionStyle}>
        <div className="flex items-center gap-2 mb-2">
          <Brain className="w-4 h-4" style={{ color: "hsl(260 60% 55%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Chave OpenAI - Super Inteligencia do Chat" : "OpenAI Key - Chat Super Intelligence"}
          </h2>
        </div>
        <p className="text-xs mb-4" style={{ color: "hsl(220 10% 50%)" }}>
          {locale === "pt-BR" ? "Insira sua chave da OpenAI para ativar a super inteligencia do DOMMO Chat. O chat passara a responder com IA real." : "Enter your OpenAI key to activate DOMMO Chat super intelligence. The chat will respond with real AI."}
        </p>
        <div className="flex flex-col gap-3">
          <input type="password" value={openaiKey} onChange={(e) => setOpenaiKey(e.target.value)} placeholder="sk-..." className="flex-1 px-4 py-3 rounded-lg text-sm outline-none border font-mono" style={inputStyle} />
          <button onClick={handleOpenaiSave} className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-medium w-fit" style={{ background: openaiSaved ? "hsl(142 71% 45% / 0.15)" : "hsl(260 60% 55% / 0.1)", color: openaiSaved ? "hsl(142 71% 45%)" : "hsl(260 60% 55%)", border: `1px solid ${openaiSaved ? "hsl(142 71% 45% / 0.3)" : "hsl(260 60% 55% / 0.3)"}` }}>
            {openaiSaved ? <Check className="w-3 h-3" /> : <Brain className="w-3 h-3" />}
            {openaiSaved ? (locale === "pt-BR" ? "Salvo" : "Saved") : (locale === "pt-BR" ? "Salvar Chave" : "Save Key")}
          </button>
        </div>
        <div className="mt-4 p-3 rounded-lg text-[10px] leading-relaxed" style={{ background: "hsl(220 10% 8%)", color: "hsl(220 10% 40%)" }}>
          {locale === "pt-BR" ? "A chave e armazenada localmente no navegador. Quando configurada, o DOMMO Chat usara GPT para responder suas perguntas e avaliar suas ideias em tempo real." : "The key is stored locally in the browser. When configured, DOMMO Chat will use GPT to answer your questions and evaluate your ideas in real time."}
        </div>
      </div>

      {/* Supabase Database */}
      <div className="rounded-xl border p-6" style={sectionStyle}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4" style={{ color: "hsl(142 71% 45%)" }} />
            <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{locale === "pt-BR" ? "Banco de Dados Supabase" : "Supabase Database"}</h2>
          </div>
          <button onClick={loadDbStatus} disabled={loadingStatus} className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-[10px]" style={{ background: "hsl(220 10% 10%)", color: "hsl(220 10% 55%)", border: "1px solid hsl(220 10% 16%)" }}>
            <RefreshCw className={`w-3 h-3 ${loadingStatus ? "animate-spin" : ""}`} /> {locale === "pt-BR" ? "Atualizar" : "Refresh"}
          </button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
          <div className="p-3 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
            <HardDrive className="w-4 h-4 mb-1" style={{ color: "hsl(180 100% 50%)" }} />
            <p className="text-lg font-bold font-mono" style={{ color: "hsl(200 20% 95%)" }}>{totalRecords}</p>
            <p className="text-[9px] uppercase tracking-wider" style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Total de Registros" : "Total Records"}</p>
          </div>
          <div className="p-3 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
            <Database className="w-4 h-4 mb-1" style={{ color: "hsl(142 71% 45%)" }} />
            <p className="text-lg font-bold font-mono" style={{ color: "hsl(200 20% 95%)" }}>9</p>
            <p className="text-[9px] uppercase tracking-wider" style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Tabelas Separadas" : "Separate Tables"}</p>
          </div>
          <div className="p-3 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
            <Shield className="w-4 h-4 mb-1" style={{ color: "hsl(45 100% 50%)" }} />
            <p className="text-lg font-bold font-mono" style={{ color: "hsl(200 20% 95%)" }}>RLS</p>
            <p className="text-[9px] uppercase tracking-wider" style={{ color: "hsl(220 10% 45%)" }}>{locale === "pt-BR" ? "Seguranca Ativa" : "Security Active"}</p>
          </div>
        </div>
        <div className="space-y-2">
          {Object.entries(recordCounts).map(([table, count]) => {
            const syncItem = syncStatuses.find((s) => s.lottery_id === table)
            return (
              <div key={table} className="flex items-center justify-between px-3 py-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: syncItem?.status === "success" ? "hsl(142 71% 45%)" : syncItem?.status === "error" ? "hsl(0 72% 51%)" : "hsl(220 10% 30%)" }} />
                  <span className="text-xs font-mono" style={{ color: "hsl(200 20% 90%)" }}>{table}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="text-[10px] font-mono" style={{ color: "hsl(180 100% 50%)" }}>{count} {locale === "pt-BR" ? "registros" : "records"}</span>
                  {syncItem?.last_contest_id ? <span className="text-[9px] font-mono" style={{ color: "hsl(220 10% 45%)" }}>#{syncItem.last_contest_id}</span> : null}
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Custom Lotteries */}
      <CustomLotteriesSection locale={locale} />

      {/* Advanced AI Configuration */}
      <AdvancedAISection locale={locale} />

      {/* Background Running */}
      <BackgroundSection locale={locale} />

      {/* Device Sync */}
      <DeviceSyncSection locale={locale} />

      {/* Confidence Gate Logs */}
      <ConfidenceLogsSection locale={locale} />

      {/* System Info */}
      <div className="rounded-xl border p-6" style={sectionStyle}>
        <div className="flex items-center gap-2 mb-4">
          <Settings className="w-4 h-4" style={{ color: "hsl(180 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{locale === "pt-BR" ? "Informacoes do Sistema" : "System Information"}</h2>
        </div>
        <div className="space-y-2 text-xs" style={{ color: "hsl(220 10% 55%)" }}>
          {[
            [locale === "pt-BR" ? "Versao" : "Version", "4.0.0 | 185 IAs | Neural Evolution 24/7", "hsl(180 100% 50%)"],
            [locale === "pt-BR" ? "Criterio de Confianca" : "Confidence Criteria", "0.999 (99.9%)", "hsl(45 100% 50%)"],
            ["API", "apiloterias.com.br", "hsl(142 71% 45%)"],
            ["Database", "Supabase PostgreSQL", "hsl(142 71% 45%)"],
            [locale === "pt-BR" ? "Plataformas" : "Platforms", "Desktop, Mobile (PWA + Background)", "hsl(180 100% 50%)"],
            [locale === "pt-BR" ? "Segundo Plano" : "Background", "Service Worker v3 (60s sync)", "hsl(280 60% 55%)"],
            [locale === "pt-BR" ? "Sorteios" : "Draws", "21:00h Brasilia (auto-check 21:30h)", "hsl(45 100% 50%)"],
            [locale === "pt-BR" ? "Config Sync" : "Config Sync", "Cross-device via localStorage + DB", "hsl(142 71% 45%)"],
            ["PIN", "834589", "hsl(0 72% 60%)"],
          ].map(([label, value, color]) => (
            <div key={String(label)} className="flex justify-between px-3 py-2 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
              <span>{label}</span><span className="font-mono" style={{ color: String(color) }}>{value}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
