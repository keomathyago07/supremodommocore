"use client"

import { useState } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { ClipboardList, Filter, Search, Shield, Database, RefreshCw, AlertTriangle, CheckCircle, Info } from "lucide-react"

interface AuditLog {
  id: string
  action: string
  entity: string
  entity_id: string
  details: string
  severity: "info" | "warning" | "critical" | "success"
  timestamp: Date
}

const MOCK_LOGS: AuditLog[] = [
  { id: "1", action: "AUTH_ALLOWED", entity: "auth.users", entity_id: "admin", details: "Admin login via PIN", severity: "success", timestamp: new Date(Date.now() - 60000) },
  { id: "2", action: "SYNC_STARTED", entity: "atlas_ingest", entity_id: "all", details: "Full sync initiated for 9 lotteries", severity: "info", timestamp: new Date(Date.now() - 120000) },
  { id: "3", action: "DRAW_CONSOLIDATED", entity: "draws", entity_id: "megasena:3200", details: "CONSENSUS: numbers match from both sources", severity: "success", timestamp: new Date(Date.now() - 180000) },
  { id: "4", action: "DRAW_CONSOLIDATED", entity: "draws", entity_id: "lotofacil:3150", details: "CONSENSUS: cross-check approved", severity: "success", timestamp: new Date(Date.now() - 240000) },
  { id: "5", action: "SENTINEL_GATE_CHECK", entity: "sentinel", entity_id: "megasena", details: "P(model>baseline)=0.912 < 0.998. BLOCKED.", severity: "warning", timestamp: new Date(Date.now() - 300000) },
  { id: "6", action: "SOURCE_HEALTH_UPDATE", entity: "source_health", entity_id: "CAIXA_OFFICIAL", details: "Score updated: 85/100. Success rate: 92%", severity: "info", timestamp: new Date(Date.now() - 360000) },
  { id: "7", action: "SOURCE_HEALTH_UPDATE", entity: "source_health", entity_id: "APILOTERIAS_V2", details: "Score updated: 91/100. Success rate: 97%", severity: "info", timestamp: new Date(Date.now() - 420000) },
  { id: "8", action: "INGEST_PENDING", entity: "ingest_jobs", entity_id: "diadesorte", details: "Only secondary source responded. Retry scheduled.", severity: "warning", timestamp: new Date(Date.now() - 480000) },
  { id: "9", action: "PRIZE_CHECK", entity: "prizes", entity_id: "megasena:3200", details: "0 prizes detected for registered bets", severity: "info", timestamp: new Date(Date.now() - 540000) },
  { id: "10", action: "MODEL_REGISTRY", entity: "axiom_registry", entity_id: "CertusV2.1", details: "Model retrained. Walk-forward: 20 windows. Bootstrap: 10K", severity: "info", timestamp: new Date(Date.now() - 600000) },
  { id: "11", action: "SYSTEM_HEALTH", entity: "ops", entity_id: "cluster", details: "2/2 instances healthy. Uptime: 99.97%. No alerts.", severity: "success", timestamp: new Date(Date.now() - 660000) },
  { id: "12", action: "AUTH_BLOCKED", entity: "auth.users", entity_id: "unknown", details: "Invalid PIN attempt. 1/5 attempts.", severity: "critical", timestamp: new Date(Date.now() - 720000) },
]

export function AuditView() {
  const { locale } = useApp()
  const [filter, setFilter] = useState<string>("all")
  const [search, setSearch] = useState("")

  const filtered = MOCK_LOGS.filter((log) => {
    if (filter !== "all" && log.severity !== filter) return false
    if (search && !log.action.toLowerCase().includes(search.toLowerCase()) && !log.details.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const SeverityIcon = ({ severity }: { severity: string }) => {
    if (severity === "success") return <CheckCircle className="w-3.5 h-3.5" style={{ color: "hsl(142 71% 45%)" }} />
    if (severity === "warning") return <AlertTriangle className="w-3.5 h-3.5" style={{ color: "hsl(45 100% 50%)" }} />
    if (severity === "critical") return <Shield className="w-3.5 h-3.5" style={{ color: "hsl(0 72% 51%)" }} />
    return <Info className="w-3.5 h-3.5" style={{ color: "hsl(180 100% 50%)" }} />
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
          {t("audit.title", locale)}
        </h1>
        <p className="text-xs mt-1" style={{ color: "hsl(220 10% 50%)" }}>
          {t("audit.subtitle", locale)}
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: "hsl(220 10% 40%)" }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={locale === "pt-BR" ? "Buscar nos logs..." : "Search logs..."}
            className="w-full pl-10 pr-4 py-2.5 rounded-lg text-xs outline-none border"
            style={{ background: "hsl(220 15% 8%)", borderColor: "hsl(220 10% 16%)", color: "hsl(200 20% 95%)" }}
          />
        </div>
        <div className="flex gap-1.5">
          {[
            { id: "all", label: locale === "pt-BR" ? "Todos" : "All" },
            { id: "success", label: "Success" },
            { id: "info", label: "Info" },
            { id: "warning", label: "Warning" },
            { id: "critical", label: "Critical" },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className="px-3 py-2 rounded-lg text-[10px] font-medium transition-all"
              style={{
                background: filter === f.id ? "hsl(180 100% 50% / 0.1)" : "hsl(220 15% 8%)",
                color: filter === f.id ? "hsl(180 100% 50%)" : "hsl(220 10% 50%)",
                border: `1px solid ${filter === f.id ? "hsl(180 100% 50% / 0.3)" : "hsl(220 10% 16%)"}`,
              }}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-xl border overflow-hidden" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="hidden md:grid grid-cols-12 gap-2 px-4 py-2.5 border-b text-[9px] uppercase tracking-wider font-semibold" style={{ borderColor: "hsl(220 10% 12%)", color: "hsl(220 10% 40%)" }}>
          <div className="col-span-1"></div>
          <div className="col-span-2">{t("audit.timestamp", locale)}</div>
          <div className="col-span-2">{t("audit.action", locale)}</div>
          <div className="col-span-2">{t("audit.entity", locale)}</div>
          <div className="col-span-5">{t("audit.details", locale)}</div>
        </div>

        {filtered.map((log) => (
          <div
            key={log.id}
            className="grid grid-cols-1 md:grid-cols-12 gap-2 px-4 py-3 border-b hover:bg-white/[0.02] transition-colors"
            style={{ borderColor: "hsl(220 10% 10%)" }}
          >
            <div className="md:col-span-1 flex items-center">
              <SeverityIcon severity={log.severity} />
            </div>
            <div className="md:col-span-2 flex items-center">
              <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 50%)" }}>
                {log.timestamp.toLocaleTimeString()}
              </span>
            </div>
            <div className="md:col-span-2 flex items-center">
              <span className="text-[10px] font-mono font-medium" style={{ color: "hsl(180 100% 50%)" }}>
                {log.action}
              </span>
            </div>
            <div className="md:col-span-2 flex items-center">
              <span className="text-[10px] font-mono" style={{ color: "hsl(220 10% 55%)" }}>
                {log.entity_id}
              </span>
            </div>
            <div className="md:col-span-5 flex items-center">
              <span className="text-[10px]" style={{ color: "hsl(220 10% 60%)" }}>
                {log.details}
              </span>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="p-8 text-center">
            <ClipboardList className="w-6 h-6 mx-auto mb-2" style={{ color: "hsl(220 10% 25%)" }} />
            <p className="text-xs" style={{ color: "hsl(220 10% 40%)" }}>
              {locale === "pt-BR" ? "Nenhum log encontrado" : "No logs found"}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
