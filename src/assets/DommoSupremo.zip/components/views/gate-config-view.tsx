"use client"

import { useState } from "react"
import { useApp } from "@/lib/store"
import { AI_ENGINE_CATEGORIES, type AICategory } from "@/lib/ai-engines"
import { LOTTERIES } from "@/lib/lottery-config"
import {
  SlidersHorizontal, Brain, Cpu, Target, Check, Shield,
  Zap, TrendingUp, ChevronDown, ChevronUp, ToggleLeft, ToggleRight,
} from "lucide-react"

export function GateConfigView() {
  const { locale, gateConfig, setGateConfig, aiEngines, setAiEngines } = useApp()
  const [saved, setSaved] = useState(false)
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null)
  const [showLotteryGates, setShowLotteryGates] = useState(false)

  const enabledCount = aiEngines.filter(e => e.enabled).length
  const totalCount = aiEngines.length

  const handleSaveGate = () => {
    setSaved(true)
    // Log to DB
    fetch("/api/lottery/confidence-log", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        lottery_id: "system",
        lottery_name: "Gate Config Update",
        confidence: gateConfig.defaultThreshold,
        gate_status: "CONFIG",
        model_name: "system",
        notes: JSON.stringify({ gateConfig, enabledEngines: enabledCount }),
      }),
    }).catch(() => {})
    setTimeout(() => setSaved(false), 2000)
  }

  const toggleEngine = (engineId: string) => {
    setAiEngines(aiEngines.map(e => e.id === engineId ? { ...e, enabled: !e.enabled } : e))
  }

  const toggleAllInCategory = (category: string) => {
    const catEngines = aiEngines.filter(e => e.category === category)
    const allEnabled = catEngines.every(e => e.enabled)
    setAiEngines(aiEngines.map(e => e.category === category ? { ...e, enabled: !allEnabled } : e))
  }

  const setLotteryThreshold = (lotteryId: string, threshold: number) => {
    setGateConfig({
      ...gateConfig,
      lotteryThresholds: { ...gateConfig.lotteryThresholds, [lotteryId]: threshold },
    })
  }

  const groupedEngines: Record<string, typeof aiEngines> = {}
  aiEngines.forEach(e => {
    if (!groupedEngines[e.category]) groupedEngines[e.category] = []
    groupedEngines[e.category].push(e)
  })

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>
            {locale === "pt-BR" ? "Configuracao de Gate & IAs" : "Gate & AI Configuration"}
          </h1>
          <p className="text-xs mt-1" style={{ color: "hsl(220 10% 50%)" }}>
            {locale === "pt-BR"
              ? "Altere os criterios de confianca e gerencie os 185 motores de IA especializados por loteria. O programa evolui continuamente e nunca retrocede."
              : "Change confidence criteria and manage 185 AI engines specialized per lottery. The program evolves continuously and never regresses."}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ background: "hsl(280 60% 55% / 0.08)", border: "1px solid hsl(280 60% 55% / 0.2)" }}>
            <Cpu className="w-3 h-3" style={{ color: "hsl(280 60% 55%)" }} />
            <span className="text-[10px] font-bold" style={{ color: "hsl(280 60% 55%)" }}>{enabledCount}/{totalCount} IAs</span>
          </div>
        </div>
      </div>

      {/* Gate Threshold Configuration */}
      <div className="rounded-xl border p-6" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
          <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
            {locale === "pt-BR" ? "Gate de Confianca Global" : "Global Confidence Gate"}
          </h2>
        </div>

        <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
          {locale === "pt-BR"
            ? "Defina o nivel minimo de confianca para que uma sugestao seja APPROVED. O programa trabalha, estuda e se aperfeiçoa a todo momento para atingir este gate."
            : "Set the minimum confidence level for a suggestion to be APPROVED. The program works, studies and perfects itself at all times to reach this gate."}
        </p>

        <div className="p-4 rounded-lg mb-4" style={{ background: "hsl(220 10% 10%)" }}>
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold" style={{ color: "hsl(200 20% 90%)" }}>
              {locale === "pt-BR" ? "Threshold Global" : "Global Threshold"}
            </span>
            <span className="text-lg font-bold font-mono" style={{ color: "hsl(45 100% 50%)" }}>
              {(gateConfig.defaultThreshold * 100).toFixed(1)}%
            </span>
          </div>
          <input
            type="range"
            min={0.9}
            max={1}
            step={0.001}
            value={gateConfig.defaultThreshold}
            onChange={(e) => setGateConfig({ ...gateConfig, defaultThreshold: parseFloat(e.target.value) })}
            className="w-full h-2 rounded-full appearance-none cursor-pointer"
            style={{ background: `linear-gradient(to right, hsl(142 71% 45%) 0%, hsl(45 100% 50%) 50%, hsl(0 72% 51%) 100%)` }}
          />
          <div className="flex justify-between mt-1 text-[9px] font-mono" style={{ color: "hsl(220 10% 40%)" }}>
            <span>90.0%</span>
            <span>95.0%</span>
            <span>99.9%</span>
            <span>100%</span>
          </div>
        </div>

        {/* Smart Features */}
        <div className="space-y-2 mb-4">
          {[
            { key: "autoEscalate", label: locale === "pt-BR" ? "Auto-escalada de confianca" : "Auto-escalate confidence", desc: locale === "pt-BR" ? "Aumenta o gate automaticamente quando o modelo melhora" : "Increases gate automatically when model improves" },
            { key: "neverRegress", label: locale === "pt-BR" ? "Nunca retroceder na inteligencia" : "Never regress in intelligence", desc: locale === "pt-BR" ? "O programa SEMPRE evolui, nunca perde o que aprendeu" : "Program ALWAYS evolves, never loses what it learned" },
            { key: "adaptiveMode", label: locale === "pt-BR" ? "Modo adaptativo por loteria" : "Adaptive mode per lottery", desc: locale === "pt-BR" ? "Ajusta o gate individualmente para cada loteria" : "Adjusts gate individually for each lottery" },
          ].map(({ key, label, desc }) => (
            <button
              key={key}
              onClick={() => setGateConfig({ ...gateConfig, [key]: !gateConfig[key as keyof typeof gateConfig] })}
              className="w-full flex items-center justify-between p-3 rounded-lg transition-all"
              style={{
                background: "hsl(220 10% 10%)",
                border: `1px solid ${gateConfig[key as keyof typeof gateConfig] ? "hsl(142 71% 45% / 0.3)" : "hsl(220 10% 16%)"}`,
              }}
            >
              <div className="text-left">
                <span className="text-[10px] font-bold block" style={{ color: "hsl(200 20% 90%)" }}>{label}</span>
                <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>{desc}</span>
              </div>
              {gateConfig[key as keyof typeof gateConfig] ? (
                <ToggleRight className="w-6 h-6 flex-shrink-0" style={{ color: "hsl(142 71% 45%)" }} />
              ) : (
                <ToggleLeft className="w-6 h-6 flex-shrink-0" style={{ color: "hsl(220 10% 30%)" }} />
              )}
            </button>
          ))}
        </div>

        {/* Per-lottery gates */}
        <button
          onClick={() => setShowLotteryGates(!showLotteryGates)}
          className="w-full flex items-center justify-between p-3 rounded-lg mb-4"
          style={{ background: "hsl(220 10% 10%)", border: "1px solid hsl(220 10% 16%)" }}
        >
          <div className="flex items-center gap-2">
            <Target className="w-3 h-3" style={{ color: "hsl(180 100% 50%)" }} />
            <span className="text-[10px] font-bold" style={{ color: "hsl(200 20% 90%)" }}>
              {locale === "pt-BR" ? "Gates por Loteria" : "Per-Lottery Gates"}
            </span>
          </div>
          {showLotteryGates ? <ChevronUp className="w-3 h-3" style={{ color: "hsl(220 10% 50%)" }} /> : <ChevronDown className="w-3 h-3" style={{ color: "hsl(220 10% 50%)" }} />}
        </button>

        {showLotteryGates && (
          <div className="space-y-2 mb-4">
            {LOTTERIES.map(l => {
              const threshold = gateConfig.lotteryThresholds[l.id] ?? gateConfig.defaultThreshold
              return (
                <div key={l.id} className="p-3 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ background: l.color }} />
                      <span className="text-[10px] font-bold" style={{ color: "hsl(200 20% 90%)" }}>{l.displayName}</span>
                    </div>
                    <span className="text-[10px] font-bold font-mono" style={{ color: l.color }}>{(threshold * 100).toFixed(1)}%</span>
                  </div>
                  <input
                    type="range"
                    min={0.9}
                    max={1}
                    step={0.001}
                    value={threshold}
                    onChange={(e) => setLotteryThreshold(l.id, parseFloat(e.target.value))}
                    className="w-full h-1 rounded-full appearance-none cursor-pointer"
                    style={{ background: "hsl(220 10% 16%)" }}
                  />
                </div>
              )
            })}
          </div>
        )}

        <button
          onClick={handleSaveGate}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold"
          style={{
            background: saved ? "hsl(142 71% 45% / 0.15)" : "hsl(45 100% 50% / 0.15)",
            color: saved ? "hsl(142 71% 45%)" : "hsl(45 100% 50%)",
            border: `1px solid ${saved ? "hsl(142 71% 45% / 0.3)" : "hsl(45 100% 50% / 0.3)"}`,
          }}
        >
          {saved ? <><Check className="w-3 h-3" /> {locale === "pt-BR" ? "Salvo" : "Saved"}</> : <><Zap className="w-3 h-3" /> {locale === "pt-BR" ? "Salvar Configuracao de Gate" : "Save Gate Config"}</>}
        </button>
      </div>

      {/* AI Engines - All 55 */}
      <div className="rounded-xl border p-6" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Brain className="w-4 h-4" style={{ color: "hsl(280 60% 55%)" }} />
            <h2 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>
              {locale === "pt-BR" ? `Motores de IA (${enabledCount}/${totalCount} ativos)` : `AI Engines (${enabledCount}/${totalCount} active)`}
            </h2>
          </div>
          <div className="flex items-center gap-1 text-[9px] px-2 py-1 rounded-full animate-pulse" style={{ background: "hsl(280 60% 55% / 0.1)", color: "hsl(280 60% 55%)" }}>
            <TrendingUp className="w-3 h-3" /> EVOLVING
          </div>
        </div>

        <p className="text-[10px] mb-4" style={{ color: "hsl(220 10% 45%)" }}>
          {locale === "pt-BR"
            ? "Todos os motores trabalham, estudam e se aperfeicoam a todo momento. Clique na categoria para expandir. O programa nunca retrocede na inteligencia - sempre evolui."
            : "All engines work, study and perfect themselves at all times. Click category to expand. The program never regresses in intelligence - always evolves."}
        </p>

        <div className="space-y-3">
          {Object.entries(groupedEngines).map(([category, engines]) => {
            const catInfo = AI_ENGINE_CATEGORIES[category as AICategory]
            const isExpanded = expandedCategory === category
            const enabledInCat = engines.filter(e => e.enabled).length

            return (
              <div key={category} className="rounded-lg overflow-hidden border" style={{ borderColor: isExpanded ? `${catInfo.color}30` : "hsl(220 10% 14%)" }}>
                <button
                  onClick={() => setExpandedCategory(isExpanded ? null : category)}
                  className="w-full flex items-center justify-between p-3 transition-all"
                  style={{ background: isExpanded ? "hsl(220 10% 9%)" : "hsl(220 10% 10%)" }}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: catInfo.color }} />
                    <span className="text-[11px] font-bold" style={{ color: "hsl(200 20% 90%)" }}>
                      {locale === "pt-BR" ? catInfo.label : catInfo.labelEn}
                    </span>
                    <span className="text-[9px] font-mono px-1.5 py-0.5 rounded-full" style={{ background: `${catInfo.color}15`, color: catInfo.color }}>
                      {enabledInCat}/{engines.length}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => { e.stopPropagation(); toggleAllInCategory(category) }}
                      className="text-[8px] px-2 py-0.5 rounded-full"
                      style={{ background: "hsl(220 10% 14%)", color: "hsl(220 10% 55%)" }}
                    >
                      {enabledInCat === engines.length ? (locale === "pt-BR" ? "Desativar" : "Disable") : (locale === "pt-BR" ? "Ativar Todos" : "Enable All")}
                    </button>
                    {isExpanded ? <ChevronUp className="w-3 h-3" style={{ color: "hsl(220 10% 50%)" }} /> : <ChevronDown className="w-3 h-3" style={{ color: "hsl(220 10% 50%)" }} />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-3 pb-3 grid grid-cols-1 md:grid-cols-2 gap-2">
                    {engines.map(engine => (
                      <button
                        key={engine.id}
                        onClick={() => toggleEngine(engine.id)}
                        className="flex items-start gap-2 p-3 rounded-lg text-left transition-all"
                        style={{
                          background: engine.enabled ? `${catInfo.color}08` : "hsl(220 10% 8%)",
                          border: `1px solid ${engine.enabled ? `${catInfo.color}25` : "hsl(220 10% 14%)"}`,
                        }}
                      >
                        <div className="w-2 h-2 rounded-full flex-shrink-0 mt-1" style={{ background: engine.enabled ? catInfo.color : "hsl(220 10% 25%)" }} />
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] font-bold block" style={{ color: engine.enabled ? catInfo.color : "hsl(220 10% 40%)" }}>
                            {engine.name}
                          </span>
                          <span className="text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>
                            {locale === "pt-BR" ? engine.description : engine.descriptionEn}
                          </span>
                        </div>
                        <span className="text-[8px] font-mono flex-shrink-0 mt-0.5" style={{ color: "hsl(220 10% 35%)" }}>
                          w:{engine.weight}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
