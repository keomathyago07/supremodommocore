"use client"

import { useState, useEffect, useCallback } from "react"
import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
import { LOTTERIES } from "@/lib/lottery-config"
import { Trophy, Check, X, AlertCircle, ArrowRight, RefreshCw, Database, Clock, Hash, Calendar } from "lucide-react"

interface PrizeCheck {
  lottery_id: string
  lottery_name: string
  contest_id: number
  date: string
  your_numbers: number[]
  drawn_numbers: number[]
  hits: number
  hit_numbers: number[]
  tier: string
  prize_value: string
  status: "WIN" | "PARTIAL" | "LOSS"
  extras?: {
    your_trevos?: number[]
    drawn_trevos?: number[]
    trevo_hits?: number
    your_month?: string
    drawn_month?: string
    month_match?: boolean
  }
  color: string
  confirmed_at?: string
  result_checked_at?: string
  from_db?: boolean
}

interface SavedBetFromDb {
  id: number
  lottery_id: string
  lottery_name: string
  numbers: number[]
  confidence: number
  confirmed: boolean
  confirmed_at: string
  contest_number: number
  result_checked: boolean
  result_checked_at: string | null
  result_numbers: number[]
  matches_count: number
  is_winner: boolean
  prize_tier: string
  prize_amount: number
  extras: Record<string, unknown>
  created_at: string
}

export function PrizesView() {
  const { locale, apiToken } = useApp()
  const [checks, setChecks] = useState<PrizeCheck[]>([])
  const [dbBets, setDbBets] = useState<SavedBetFromDb[]>([])
  const [loading, setLoading] = useState(false)
  const [autoChecking, setAutoChecking] = useState(false)
  const [lastAutoCheck, setLastAutoCheck] = useState<string | null>(null)

  const loadDbBets = useCallback(async () => {
    try {
      const res = await fetch("/api/lottery/check-results")
      const data = await res.json()
      if (data.bets) setDbBets(data.bets)
    } catch { /* ignore */ }
  }, [])

  const autoCheckResults = useCallback(async () => {
    if (!apiToken) return
    setAutoChecking(true)
    try {
      const res = await fetch("/api/lottery/check-results", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: apiToken }),
      })
      const data = await res.json()
      if (data.checked_at) setLastAutoCheck(data.checked_at)
      await loadDbBets()
    } catch { /* ignore */ }
    setAutoChecking(false)
  }, [apiToken, loadDbBets])

  const verifyPrizes = useCallback(async () => {
    if (!apiToken) return
    setLoading(true)

    // First auto-check from DB
    await autoCheckResults()

    const newChecks: PrizeCheck[] = []

    // Build checks from DB confirmed bets
    for (const bet of dbBets.filter(b => b.result_checked)) {
      const lottery = LOTTERIES.find(l => l.id === bet.lottery_id)
      if (!lottery) continue

      const drawnSet = new Set(bet.result_numbers)
      const hitNumbers = bet.numbers.filter(n => drawnSet.has(n))

      newChecks.push({
        lottery_id: bet.lottery_id,
        lottery_name: bet.lottery_name,
        contest_id: bet.contest_number,
        date: bet.confirmed_at ? new Date(bet.confirmed_at).toLocaleDateString("pt-BR") : "",
        your_numbers: bet.numbers,
        drawn_numbers: bet.result_numbers,
        hits: bet.matches_count,
        hit_numbers: hitNumbers,
        tier: bet.prize_tier || "NONE",
        prize_value: bet.prize_amount ? new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(bet.prize_amount) : "R$ 0,00",
        status: bet.is_winner ? (bet.matches_count >= (lottery.prizeRanges[0]?.hits || 999) ? "WIN" : "PARTIAL") : "LOSS",
        color: lottery.color,
        confirmed_at: bet.confirmed_at,
        result_checked_at: bet.result_checked_at || undefined,
        from_db: true,
      })
    }

    // Also check from localStorage for backwards compatibility
    const storedBets = typeof window !== "undefined" ? localStorage.getItem("dommo_bets") : null
    const localBets: Record<string, { numbers: number[]; trevos?: number[]; month?: string }> = storedBets ? JSON.parse(storedBets) : {}

    for (const lottery of LOTTERIES) {
      if (newChecks.some(c => c.lottery_id === lottery.id)) continue // Skip if already from DB

      try {
        const res = await fetch(`/api/lottery/${lottery.id}?token=${encodeURIComponent(apiToken)}`)
        const data = await res.json()
        if (!data.numbers || data.numbers.length === 0) continue

        const bet = localBets[lottery.id]
        if (!bet) continue

        const drawnSet = new Set(data.numbers.map(Number))
        const hitNumbers = bet.numbers.filter(n => drawnSet.has(n))
        const hits = hitNumbers.length

        let tier = "NONE"
        let prizeValue = "R$ 0,00"
        let status: "WIN" | "PARTIAL" | "LOSS" = "LOSS"

        const prizeRanges = lottery.prizeRanges
        const matchedRange = prizeRanges.find(r => r.hits === hits)
        if (matchedRange) {
          tier = matchedRange.label
          status = hits === prizeRanges[0].hits ? "WIN" : "PARTIAL"

          if (data.prizes && Array.isArray(data.prizes)) {
            const prizeData = data.prizes.find((p: Record<string, unknown>) => {
              const desc = String(p.descricaoFaixa || p.quantidade_acertos || p.descricao || "").toLowerCase()
              return desc.includes(`${hits} acertos`)
            })
            if (prizeData) {
              const val = Number(prizeData.valorPremio || prizeData.valor_premio || 0)
              prizeValue = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(val)
            }
          }
        }

        const extras: PrizeCheck["extras"] = {}
        if (lottery.extraField === "trevos" && bet.trevos && data.extras?.trevos) {
          extras.your_trevos = bet.trevos
          extras.drawn_trevos = data.extras.trevos.map(Number)
          extras.trevo_hits = bet.trevos.filter(tv => data.extras.trevos.map(Number).includes(tv)).length
        }
        if (lottery.extraField === "mes_sorte" && bet.month && data.extras?.month) {
          extras.your_month = bet.month
          extras.drawn_month = data.extras.month
          extras.month_match = bet.month.toLowerCase() === data.extras.month.toLowerCase()
        }

        newChecks.push({
          lottery_id: lottery.id, lottery_name: lottery.displayName, contest_id: data.contest_id,
          date: data.date, your_numbers: bet.numbers, drawn_numbers: data.numbers.map(Number),
          hits, hit_numbers: hitNumbers, tier, prize_value: prizeValue, status, extras, color: lottery.color,
        })
      } catch { /* skip */ }
    }

    setChecks(newChecks)
    setLoading(false)
  }, [apiToken, autoCheckResults, dbBets])

  useEffect(() => { loadDbBets() }, [loadDbBets])
  useEffect(() => { if (apiToken) verifyPrizes() }, [apiToken, verifyPrizes])

  // Auto-check every 5 minutes
  useEffect(() => {
    if (!apiToken) return
    const interval = setInterval(() => autoCheckResults(), 300000)
    return () => clearInterval(interval)
  }, [apiToken, autoCheckResults])

  const wins = checks.filter(c => c.status === "WIN")
  const partials = checks.filter(c => c.status === "PARTIAL")
  const pendingFromDb = dbBets.filter(b => b.confirmed && !b.result_checked)

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-wider" style={{ color: "hsl(180 100% 50%)" }}>{t("prizes.title", locale)}</h1>
          <p className="text-xs mt-1" style={{ color: "hsl(220 10% 50%)" }}>{t("prizes.subtitle", locale)}</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={autoCheckResults} disabled={autoChecking || !apiToken} className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-all disabled:opacity-50" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)", border: "1px solid hsl(142 71% 45% / 0.3)" }}>
            <Database className={`w-3 h-3 ${autoChecking ? "animate-spin" : ""}`} />
            {locale === "pt-BR" ? "Auto-Verificar DB" : "Auto-Check DB"}
          </button>
          <button onClick={verifyPrizes} disabled={loading || !apiToken} className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-medium transition-all disabled:opacity-50" style={{ background: "hsl(180 100% 50% / 0.1)", color: "hsl(180 100% 50%)", border: "1px solid hsl(180 100% 50% / 0.3)" }}>
            <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
            {locale === "pt-BR" ? "Verificar Agora" : "Verify Now"}
          </button>
        </div>
      </div>

      {/* Status Bar */}
      <div className="flex flex-wrap items-center gap-4 text-[10px]" style={{ color: "hsl(220 10% 40%)" }}>
        {lastAutoCheck && (
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" /> {locale === "pt-BR" ? "Ultima verificacao" : "Last check"}: {new Date(lastAutoCheck).toLocaleString("pt-BR")}
          </span>
        )}
        <span className="flex items-center gap-1" style={{ color: "hsl(142 71% 45% / 0.7)" }}>
          <Database className="w-3 h-3" /> {dbBets.length} {locale === "pt-BR" ? "apostas no banco" : "bets in DB"}
        </span>
        {pendingFromDb.length > 0 && (
          <span className="flex items-center gap-1" style={{ color: "hsl(45 100% 50%)" }}>
            <Clock className="w-3 h-3" /> {pendingFromDb.length} {locale === "pt-BR" ? "aguardando resultado" : "awaiting results"}
          </span>
        )}
      </div>

      {/* Pending Bets from DB */}
      {pendingFromDb.length > 0 && (
        <div className="rounded-xl border p-4" style={{ background: "hsl(220 15% 6%)", borderColor: "hsl(45 100% 50% / 0.15)" }}>
          <div className="flex items-center gap-2 mb-3">
            <Clock className="w-4 h-4" style={{ color: "hsl(45 100% 50%)" }} />
            <h2 className="text-xs font-bold uppercase tracking-wider" style={{ color: "hsl(45 100% 50%)" }}>
              {locale === "pt-BR" ? `Apostas Aguardando Resultado (${pendingFromDb.length})` : `Bets Awaiting Results (${pendingFromDb.length})`}
            </h2>
          </div>
          <div className="space-y-2">
            {pendingFromDb.map((bet) => {
              const lottery = LOTTERIES.find(l => l.id === bet.lottery_id)
              return (
                <div key={bet.id} className="flex items-center justify-between px-3 py-2.5 rounded-lg" style={{ background: "hsl(220 10% 10%)" }}>
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: lottery?.color || "hsl(45 100% 50%)" }} />
                    <span className="text-xs font-bold" style={{ color: "hsl(200 20% 90%)" }}>{bet.lottery_name}</span>
                    <span className="text-[9px] font-mono flex items-center gap-1" style={{ color: "hsl(220 10% 45%)" }}>
                      <Hash className="w-3 h-3" />{bet.contest_number}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[9px] font-mono flex items-center gap-1" style={{ color: "hsl(220 10% 40%)" }}>
                      <Calendar className="w-3 h-3" />{new Date(bet.confirmed_at).toLocaleDateString("pt-BR")} {new Date(bet.confirmed_at).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                    </span>
                    <span className="text-[9px] px-2 py-0.5 rounded-full animate-pulse" style={{ background: "hsl(45 100% 50% / 0.1)", color: "hsl(45 100% 50%)" }}>
                      {locale === "pt-BR" ? "Pendente" : "Pending"}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {(wins.length > 0 || partials.length > 0) && (
        <div className="p-4 rounded-xl border glow-gold" style={{ background: "hsl(45 100% 50% / 0.05)", borderColor: "hsl(45 100% 50% / 0.3)" }}>
          <div className="flex items-center gap-2 mb-2">
            <Trophy className="w-5 h-5" style={{ color: "hsl(45 100% 50%)" }} />
            <span className="text-sm font-bold" style={{ color: "hsl(45 100% 50%)" }}>{t("prizes.detected", locale)}</span>
          </div>
          <p className="text-xs" style={{ color: "hsl(45 100% 50% / 0.7)" }}>
            {wins.length} {locale === "pt-BR" ? "premio(s) principal(is)" : "main prize(s)"}, {partials.length} {locale === "pt-BR" ? "premio(s) secundario(s)" : "secondary prize(s)"}
          </p>
        </div>
      )}

      {!apiToken && (
        <div className="p-4 rounded-xl border text-center" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
          <AlertCircle className="w-6 h-6 mx-auto mb-2" style={{ color: "hsl(220 10% 40%)" }} />
          <p className="text-xs" style={{ color: "hsl(220 10% 45%)" }}>
            {locale === "pt-BR" ? "Configure o token da API e registre apostas para verificar premios" : "Configure API token and register bets to verify prizes"}
          </p>
        </div>
      )}

      {checks.length === 0 && apiToken && !loading && (
        <div className="p-8 rounded-xl border text-center" style={{ background: "hsl(220 15% 7%)", borderColor: "hsl(220 10% 14%)" }}>
          <Trophy className="w-8 h-8 mx-auto mb-3" style={{ color: "hsl(220 10% 25%)" }} />
          <p className="text-sm" style={{ color: "hsl(220 10% 45%)" }}>{t("prizes.no_prizes", locale)}</p>
          <p className="text-[10px] mt-1" style={{ color: "hsl(220 10% 35%)" }}>
            {locale === "pt-BR" ? "Registre apostas na secao de Apostas Sugeridas para conferir automaticamente" : "Register bets in the Suggested Bets section for automatic verification"}
          </p>
        </div>
      )}

      <div className="space-y-4">
        {checks.map((check, idx) => (
          <div key={`${check.lottery_id}-${idx}`} className="rounded-xl border p-4" style={{ background: "hsl(220 15% 7%)", borderColor: check.status === "WIN" ? "hsl(45 100% 50% / 0.4)" : check.status === "PARTIAL" ? "hsl(142 71% 45% / 0.3)" : "hsl(220 10% 14%)" }}>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ background: check.color }} />
                <h3 className="text-sm font-bold" style={{ color: "hsl(200 20% 95%)" }}>{check.lottery_name}</h3>
                <span className="text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>#{check.contest_id} | {check.date}</span>
                {check.from_db && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: "hsl(142 71% 45% / 0.1)", color: "hsl(142 71% 45%)" }}>DB</span>
                )}
              </div>
              <span className="text-[9px] px-2 py-1 rounded-full font-bold" style={{
                background: check.status === "WIN" ? "hsl(45 100% 50% / 0.15)" : check.status === "PARTIAL" ? "hsl(142 71% 45% / 0.15)" : "hsl(220 10% 10%)",
                color: check.status === "WIN" ? "hsl(45 100% 50%)" : check.status === "PARTIAL" ? "hsl(142 71% 45%)" : "hsl(220 10% 40%)",
              }}>
                {check.hits} {locale === "pt-BR" ? "acertos" : "hits"}
              </span>
            </div>

            {check.confirmed_at && (
              <div className="flex items-center gap-3 mb-2 text-[9px]" style={{ color: "hsl(220 10% 40%)" }}>
                <span>{locale === "pt-BR" ? "Confirmada em" : "Confirmed at"}: {new Date(check.confirmed_at).toLocaleString("pt-BR")}</span>
                {check.result_checked_at && <span>{locale === "pt-BR" ? "Verificada em" : "Checked at"}: {new Date(check.result_checked_at).toLocaleString("pt-BR")}</span>}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
              <div>
                <p className="text-[9px] uppercase tracking-wider mb-1.5" style={{ color: "hsl(220 10% 40%)" }}>{t("prizes.your_numbers", locale)}</p>
                <div className="flex flex-wrap gap-1">
                  {check.your_numbers.map((n, i) => (
                    <span key={i} className="w-7 h-7 flex items-center justify-center rounded text-[10px] font-mono font-bold" style={{
                      background: check.hit_numbers.includes(n) ? "hsl(142 71% 45% / 0.2)" : "hsl(220 10% 10%)",
                      color: check.hit_numbers.includes(n) ? "hsl(142 71% 45%)" : "hsl(220 10% 45%)",
                      border: `1px solid ${check.hit_numbers.includes(n) ? "hsl(142 71% 45% / 0.4)" : "hsl(220 10% 16%)"}`,
                    }}>
                      {String(n).padStart(2, "0")}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-center">
                <ArrowRight className="w-4 h-4" style={{ color: "hsl(220 10% 30%)" }} />
              </div>
              <div>
                <p className="text-[9px] uppercase tracking-wider mb-1.5" style={{ color: "hsl(220 10% 40%)" }}>{t("prizes.drawn_numbers", locale)}</p>
                <div className="flex flex-wrap gap-1">
                  {check.drawn_numbers.map((n, i) => (
                    <span key={i} className="w-7 h-7 flex items-center justify-center rounded text-[10px] font-mono font-bold" style={{ background: check.color + "22", color: check.color, border: `1px solid ${check.color}44` }}>
                      {String(n).padStart(2, "0")}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {check.extras?.your_trevos && (
              <div className="flex items-center gap-4 mb-2 text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>
                <span>{locale === "pt-BR" ? "Seus Trevos:" : "Your Clovers:"} {check.extras.your_trevos.join(", ")}</span>
                <span>{locale === "pt-BR" ? "Sorteados:" : "Drawn:"} {check.extras.drawn_trevos?.join(", ")}</span>
                <span className="font-bold" style={{ color: check.extras.trevo_hits && check.extras.trevo_hits > 0 ? "hsl(142 71% 45%)" : "hsl(220 10% 40%)" }}>
                  {check.extras.trevo_hits} {locale === "pt-BR" ? "trevo(s)" : "clover(s)"}
                </span>
              </div>
            )}
            {check.extras?.your_month && (
              <div className="flex items-center gap-2 mb-2 text-[10px]" style={{ color: "hsl(220 10% 45%)" }}>
                {locale === "pt-BR" ? "Seu Mes:" : "Your Month:"} {check.extras.your_month}
                <ArrowRight className="w-3 h-3" />
                {locale === "pt-BR" ? "Sorteado:" : "Drawn:"} {check.extras.drawn_month}
                {check.extras.month_match ? <Check className="w-3 h-3" style={{ color: "hsl(142 71% 45%)" }} /> : <X className="w-3 h-3" style={{ color: "hsl(0 72% 51%)" }} />}
              </div>
            )}

            <div className="flex items-center justify-between pt-2 border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
              <span className="text-xs" style={{ color: "hsl(220 10% 50%)" }}>{check.tier}</span>
              <span className="text-sm font-bold font-mono" style={{ color: check.status !== "LOSS" ? "hsl(45 100% 50%)" : "hsl(220 10% 35%)" }}>
                {check.prize_value}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
