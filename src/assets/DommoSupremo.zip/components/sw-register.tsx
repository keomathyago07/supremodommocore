"use client"

import { useEffect, useState } from "react"
import { Download, X, RefreshCw } from "lucide-react"

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>
}

export function ServiceWorkerRegister() {
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null)
  const [showBanner, setShowBanner] = useState(false)
  const [updateAvailable, setUpdateAvailable] = useState(false)
  const [waitingWorker, setWaitingWorker] = useState<ServiceWorker | null>(null)

  useEffect(() => {
    if (!("serviceWorker" in navigator)) return

    navigator.serviceWorker
      .register("/sw.js", { scope: "/", updateViaCache: "none" })
      .then((reg) => {
        // Check for updates every 30 minutes
        setInterval(() => reg.update(), 1800000)

        // Handle waiting worker (new version ready)
        if (reg.waiting) {
          setWaitingWorker(reg.waiting)
          setUpdateAvailable(true)
        }

        reg.addEventListener("updatefound", () => {
          const newWorker = reg.installing
          if (!newWorker) return
          newWorker.addEventListener("statechange", () => {
            if (newWorker.state === "installed" && navigator.serviceWorker.controller) {
              setWaitingWorker(newWorker)
              setUpdateAvailable(true)
            }
          })
        })

        // Request periodic background sync (Chrome 80+)
        if ("periodicSync" in reg) {
          ;(
            reg as unknown as {
              periodicSync: {
                register: (tag: string, opts: { minInterval: number }) => Promise<void>
              }
            }
          ).periodicSync
            .register("dommo-background-sync", { minInterval: 60 * 60 * 1000 })
            .catch(() => {})
        }

        // Listen for messages from SW
        navigator.serviceWorker.addEventListener("message", (event) => {
          if (event.data?.type === "draw_time") {
            window.dispatchEvent(new CustomEvent("dommo-draw-time", { detail: event.data }))
          }
          if (event.data?.type === "results_checked") {
            window.dispatchEvent(new CustomEvent("dommo-results-checked", { detail: event.data }))
          }
          if (event.data?.type === "notification") {
            window.dispatchEvent(new CustomEvent("dommo-notification", { detail: event.data }))
          }
        })
      })
      .catch(() => {})

    // Request notification permission
    if ("Notification" in window && Notification.permission === "default") {
      setTimeout(() => Notification.requestPermission(), 5000)
    }

    // Skip if already installed as standalone
    if (window.matchMedia("(display-mode: standalone)").matches) return
    if ((window.navigator as unknown as Record<string, boolean>).standalone === true) return

    const handler = (e: Event) => {
      e.preventDefault()
      setInstallPrompt(e as BeforeInstallPromptEvent)
      setShowBanner(true)
    }
    window.addEventListener("beforeinstallprompt", handler)
    window.addEventListener("appinstalled", () => {
      setShowBanner(false)
      setInstallPrompt(null)
    })

    return () => {
      window.removeEventListener("beforeinstallprompt", handler)
    }
  }, [])

  const handleInstall = async () => {
    if (!installPrompt) return
    await installPrompt.prompt()
    const choice = await installPrompt.userChoice
    if (choice.outcome === "accepted") setShowBanner(false)
    setInstallPrompt(null)
  }

  const handleUpdate = () => {
    if (waitingWorker) {
      waitingWorker.postMessage("SKIP_WAITING")
      setUpdateAvailable(false)
      window.location.reload()
    }
  }

  const bannerStyle = {
    background: "hsl(220 15% 7%)",
    borderColor: "hsl(180 100% 50% / 0.3)",
    boxShadow: "0 0 60px hsl(180 100% 50% / 0.12)",
  }

  return (
    <>
      {/* Update banner */}
      {updateAvailable && (
        <div className="fixed top-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-[9999]">
          <div className="flex items-center gap-3 p-4 rounded-xl border shadow-2xl" style={bannerStyle}>
            <div
              className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0"
              style={{ background: "hsl(45 100% 50% / 0.1)" }}
            >
              <RefreshCw className="w-5 h-5" style={{ color: "hsl(45 100% 50%)" }} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate" style={{ color: "hsl(200 20% 95%)" }}>
                Atualizacao disponivel
              </p>
              <p className="text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>
                Nova versao do DOMMO CORE pronta para instalar
              </p>
            </div>
            <button
              onClick={handleUpdate}
              className="flex-shrink-0 px-4 py-2 rounded-lg text-xs font-bold transition-all hover:opacity-90"
              style={{ background: "hsl(45 100% 50%)", color: "hsl(220 15% 5%)" }}
            >
              Atualizar
            </button>
            <button
              onClick={() => setUpdateAvailable(false)}
              className="flex-shrink-0 p-1 rounded-lg hover:bg-white/5"
              aria-label="Fechar"
            >
              <X className="w-4 h-4" style={{ color: "hsl(220 10% 40%)" }} />
            </button>
          </div>
        </div>
      )}

      {/* Install banner */}
      {showBanner && installPrompt && !updateAvailable && (
        <div className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-[9999]">
          <div className="flex items-center gap-3 p-4 rounded-xl border shadow-2xl" style={bannerStyle}>
            <div
              className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0"
              style={{ background: "hsl(180 100% 50% / 0.1)" }}
            >
              <Download className="w-5 h-5" style={{ color: "hsl(180 100% 50%)" }} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold truncate" style={{ color: "hsl(200 20% 95%)" }}>
                DOMMO CORE v3.1
              </p>
              <p className="text-[10px]" style={{ color: "hsl(220 10% 50%)" }}>
                Instalar para rodar em segundo plano
              </p>
            </div>
            <button
              onClick={handleInstall}
              className="flex-shrink-0 px-4 py-2 rounded-lg text-xs font-bold transition-all hover:opacity-90"
              style={{ background: "hsl(180 100% 50%)", color: "hsl(220 15% 5%)" }}
            >
              Instalar
            </button>
            <button
              onClick={() => setShowBanner(false)}
              className="flex-shrink-0 p-1 rounded-lg hover:bg-white/5"
              aria-label="Fechar"
            >
              <X className="w-4 h-4" style={{ color: "hsl(220 10% 40%)" }} />
            </button>
          </div>
        </div>
      )}
    </>
  )
}
