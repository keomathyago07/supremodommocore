"use client"

import { useApp } from "@/lib/store"
import { t } from "@/lib/i18n"
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import _Image from "next/image"
import {
  LayoutDashboard,
  Dices,
  Target,
  Trophy,
  MessageSquare,
  Activity,
  Settings,
  ClipboardList,
  DollarSign,
  X,
  Menu,
  ShieldCheck,
  SlidersHorizontal,
  Cpu,
  Clock,
  Brain,
} from "lucide-react"
import { useState, useEffect } from "react"

const navItems = [
  { id: "dashboard", icon: LayoutDashboard, labelKey: "nav.dashboard" },
  { id: "evolution", icon: Brain, labelKey: "nav.evolution" },
  { id: "lotteries", icon: Dices, labelKey: "nav.lotteries" },
  { id: "bets", icon: Target, labelKey: "nav.bets" },
  { id: "prizes", icon: Trophy, labelKey: "nav.prizes" },
  { id: "confidence-history", icon: ShieldCheck, labelKey: "nav.confidence_history" },
  { id: "gate-config", icon: SlidersHorizontal, labelKey: "nav.gate_config" },
  { id: "finances", icon: DollarSign, labelKey: "nav.finances" },
  { id: "chat", icon: MessageSquare, labelKey: "nav.chat" },
  { id: "monitoring", icon: Activity, labelKey: "nav.monitoring" },
  { id: "audit", icon: ClipboardList, labelKey: "nav.audit" },
  { id: "settings", icon: Settings, labelKey: "nav.settings" },
]

function BrasiliaClockWidget() {
  const [time, setTime] = useState("")

  useEffect(() => {
    const update = () => {
      setTime(new Date().toLocaleString("pt-BR", {
        timeZone: "America/Sao_Paulo",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      }))
    }
    update()
    const interval = setInterval(update, 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-lg mx-3 mb-2" style={{ background: "hsl(220 10% 8%)", border: "1px solid hsl(220 10% 14%)" }}>
      <Clock className="w-3 h-3" style={{ color: "hsl(180 100% 50% / 0.6)" }} />
      <div className="flex-1">
        <span className="text-[10px] font-mono font-bold" style={{ color: "hsl(180 100% 50%)" }}>{time}</span>
        <span className="text-[8px] ml-1 tracking-wider" style={{ color: "hsl(220 10% 40%)" }}>BRT</span>
      </div>
    </div>
  )
}

export function SidebarNav() {
  const { locale, activeView, setActiveView, sidebarOpen, setSidebarOpen, aiEngines } = useApp()
  const enabledCount = aiEngines.filter(e => e.enabled).length

  return (
    <>
      {/* Mobile menu button - higher z-index and more visible */}
      <button
        onClick={() => setSidebarOpen(true)}
        className="fixed top-3 left-3 z-[60] p-2.5 rounded-xl md:hidden border-2 shadow-lg"
        style={{
          background: "hsl(220 15% 7%)",
          borderColor: "hsl(180 100% 50% / 0.3)",
          boxShadow: "0 0 20px hsl(180 100% 50% / 0.15)",
        }}
        aria-label="Open menu"
      >
        <Menu className="w-5 h-5" style={{ color: "hsl(180 100% 50%)" }} />
      </button>

      {/* Backdrop */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-[65] md:hidden"
          style={{ background: "rgba(0,0,0,0.7)", backdropFilter: "blur(4px)" }}
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed top-0 left-0 h-full z-[70] w-64 flex flex-col border-r transition-transform duration-300 md:translate-x-0 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
        style={{ background: "hsl(220 15% 5%)", borderColor: "hsl(220 10% 12%)" }}
      >
        {/* Header */}
        <div className="flex items-center gap-3 p-4 border-b" style={{ borderColor: "hsl(220 10% 12%)" }}>
          <div className="relative w-10 h-10 rounded-full overflow-hidden border-2 flex-shrink-0" style={{ borderColor: "hsl(180 100% 50% / 0.5)", boxShadow: "0 0 15px hsl(180 100% 50% / 0.2)" }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/dommo-robot.jpg" alt="DOMMO" className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-sm font-bold tracking-[0.2em]" style={{ color: "hsl(180 100% 50%)" }}>DOMMO CORE</h2>
            <p className="text-[9px] tracking-[0.15em] uppercase truncate" style={{ color: "hsl(45 100% 50%)" }}>
              {t("app.slogan", locale)}
            </p>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="md:hidden p-1.5 rounded-lg transition-all"
            style={{ background: "hsl(220 10% 10%)" }}
            aria-label="Close menu"
          >
            <X className="w-4 h-4" style={{ color: "hsl(220 10% 55%)" }} />
          </button>
        </div>

        {/* Brasilia Clock */}
        <div className="pt-3">
          <BrasiliaClockWidget />
        </div>

        {/* AI Engines indicator */}
        <div className="flex items-center gap-2 px-3 pb-2 mx-3 mb-1">
          <Cpu className="w-3 h-3" style={{ color: "hsl(280 60% 55%)" }} />
          <span className="text-[9px] font-bold" style={{ color: "hsl(280 60% 55%)" }}>{enabledCount} AI Engines</span>
          <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "hsl(142 71% 45%)" }} />
        </div>

        {/* Navigation */}
        <nav className="flex-1 py-1 overflow-y-auto scrollbar-thin">
          {navItems.map((item) => {
            const Icon = item.icon
            const isActive = activeView === item.id
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id)
                  setSidebarOpen(false)
                }}
                className="w-full flex items-center gap-3 px-4 py-3 text-sm transition-all relative"
                style={{
                  color: isActive ? "hsl(180 100% 50%)" : "hsl(220 10% 55%)",
                  background: isActive ? "hsl(180 100% 50% / 0.08)" : "transparent",
                }}
              >
                {isActive && (
                  <div
                    className="absolute left-0 top-1 bottom-1 w-0.5 rounded-r"
                    style={{ background: "hsl(180 100% 50%)" }}
                  />
                )}
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span className="truncate">{t(item.labelKey, locale)}</span>
              </button>
            )
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t" style={{ borderColor: "hsl(220 10% 12%)" }}>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: "hsl(142 71% 45%)" }} />
            <span className="text-[10px] tracking-wider uppercase" style={{ color: "hsl(220 10% 40%)" }}>
              System Online 24/7
            </span>
          </div>
          <p className="text-[8px] font-mono" style={{ color: "hsl(220 10% 30%)" }}>
            Sorteios: 21:00h BRT
          </p>
        </div>
      </aside>
    </>
  )
}
