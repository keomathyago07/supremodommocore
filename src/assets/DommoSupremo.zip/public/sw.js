// DOMMO CORE - Service Worker v4.0
// Compativel com Android 14+ / Play Protect / Chrome 120+
// Roda em segundo plano (desktop + mobile)
// Mantem sincronizacao mesmo com app fechado

const CACHE_VERSION = "dommo-core-v4";
const RUNTIME_CACHE = "dommo-runtime-v4";
const SYNC_INTERVAL = 60000;
const DRAW_CHECK_HOUR = 21;

// Precache only essential assets (small footprint)
const PRECACHE_URLS = ["/"];

// ----- INSTALL -----
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_VERSION)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

// ----- ACTIVATE -----
self.addEventListener("activate", (event) => {
  const allowedCaches = new Set([CACHE_VERSION, RUNTIME_CACHE]);
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => !allowedCaches.has(k))
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
      .then(() => startBackgroundSync())
  );
});

// ----- FETCH (Network-first with cache fallback, privacy-safe) -----
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Skip cross-origin requests for privacy compliance
  if (url.origin !== self.location.origin) return;

  // API calls: network only, no caching (fresh data always)
  if (url.pathname.startsWith("/api/")) {
    event.respondWith(fetch(event.request));
    return;
  }

  // Static assets: stale-while-revalidate
  event.respondWith(
    caches.match(event.request).then((cached) => {
      const fetchPromise = fetch(event.request)
        .then((response) => {
          if (response && response.status === 200 && response.type === "basic") {
            const clone = response.clone();
            caches.open(RUNTIME_CACHE).then((cache) => {
              cache.put(event.request, clone);
            });
          }
          return response;
        })
        .catch(() => cached);
      return cached || fetchPromise;
    })
  );
});

// ----- BACKGROUND SYNC ENGINE -----
let syncTimer = null;

function startBackgroundSync() {
  if (syncTimer) clearInterval(syncTimer);
  syncTimer = setInterval(() => performBackgroundTasks(), SYNC_INTERVAL);
  performBackgroundTasks();
}

async function performBackgroundTasks() {
  try {
    // 1. Heartbeat sync
    await fetch("/api/lottery/device-sync", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        device_id: "sw-background-v4",
        device_name: "Service Worker v4",
        device_type: "background",
        sync_data: {
          last_sync: new Date().toISOString(),
          running_in_background: true,
          sw_version: "4.0",
          privacy_compliant: true,
        },
      }),
    }).catch(() => {});

    // 2. Time-based result checks (Brasilia timezone)
    const now = new Date();
    const brasiliaOffset = -3 * 60;
    const utcMinutes = now.getUTCHours() * 60 + now.getUTCMinutes();
    const brasiliaMinutes = utcMinutes + brasiliaOffset;
    const bHour = Math.floor(((brasiliaMinutes % 1440) + 1440) % 1440 / 60);
    const bMin = ((brasiliaMinutes % 1440) + 1440) % 1440 % 60;

    // 21:00 - draw happening notification
    if (bHour === DRAW_CHECK_HOUR && bMin <= 2) {
      await notifyClients({
        type: "draw_time",
        title: "DOMMO CORE - Sorteio Agora!",
        body: "Os sorteios das loterias da Caixa estao acontecendo agora (21:00h Brasilia).",
      });
    }

    // 21:30 and 22:00 - auto check results
    if (
      (bHour === 21 && bMin >= 28 && bMin <= 35) ||
      (bHour === 22 && bMin <= 5)
    ) {
      await checkResultsInBackground();
    }
  } catch (e) {
    // Must never crash
  }
}

async function checkResultsInBackground() {
  try {
    const res = await fetch("/api/lottery/check-results", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ token: "auto-sw-v4" }),
    });
    if (!res.ok) return;
    const data = await res.json();

    if (data.results && data.results.length > 0) {
      // Notify winners
      const winners = data.results.filter((r) => r.is_winner);
      for (const w of winners) {
        await showNotificationSafe(
          `PREMIACAO! ${w.lottery_name}`,
          {
            body: `Concurso #${w.contest_number} | ${w.matches} acertos | ${w.prize_tier}\nNumeros: ${w.bet_numbers.join(", ")}`,
            icon: "/api/pwa-icon?size=192",
            badge: "/api/pwa-icon?size=96",
            tag: `prize-${w.contest_number}`,
            vibrate: [300, 100, 300, 100, 300],
            requireInteraction: true,
            data: { url: "/?view=bets", type: "prize" },
          }
        );
      }

      // Summary
      const details = data.results
        .map((r) => `${r.lottery_name}: ${r.matches} acerto(s)`)
        .join(" | ");
      await showNotificationSafe("Resultados Verificados", {
        body: `${data.results.length} aposta(s) conferida(s). ${
          winners.length > 0 ? winners.length + " PREMIACAO(OES)!" : "Sem premiacao."
        }\n${details}`,
        icon: "/api/pwa-icon?size=192",
        badge: "/api/pwa-icon?size=96",
        tag: "results-summary",
        data: { url: "/?view=bets", type: "results" },
      });
    }
  } catch (e) {
    // Silent
  }
}

async function showNotificationSafe(title, options) {
  try {
    if (self.registration && Notification.permission === "granted") {
      await self.registration.showNotification("DOMMO CORE - " + title, options);
    }
  } catch (e) {
    // Fallback: message clients
    await notifyClients({ type: "notification", title, body: options.body });
  }
}

async function notifyClients(data) {
  try {
    const clients = await self.clients.matchAll({
      type: "window",
      includeUncontrolled: true,
    });
    clients.forEach((client) => client.postMessage(data));
  } catch (e) {
    // Silent
  }
}

// ----- NOTIFICATION CLICK -----
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || "/";
  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then((clients) => {
        for (const client of clients) {
          if (client.url.includes(self.location.origin) && "focus" in client) {
            return client.focus();
          }
        }
        return self.clients.openWindow(targetUrl);
      })
  );
});

// ----- MESSAGE HANDLER -----
self.addEventListener("message", (event) => {
  if (event.data === "START_SYNC") startBackgroundSync();
  if (event.data === "FORCE_CHECK") checkResultsInBackground();
  if (event.data === "SKIP_WAITING") self.skipWaiting();
});

// ----- PERIODIC BACKGROUND SYNC (Chrome 80+) -----
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "dommo-background-sync") {
    event.waitUntil(performBackgroundTasks());
  }
});

// ----- PUSH -----
self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    data = { title: "DOMMO CORE", body: event.data?.text() || "Atualizacao" };
  }
  event.waitUntil(
    showNotificationSafe(data.title || "Atualizacao", {
      body: data.body || "Nova informacao disponivel",
      icon: "/api/pwa-icon?size=192",
      badge: "/api/pwa-icon?size=96",
      data: { url: "/" },
    })
  );
});
