"use client"

import { useApp, AppProvider } from "@/lib/store"
import { AuthScreen } from "@/components/auth-screen"
import { SidebarNav } from "@/components/sidebar-nav"
import { DashboardView } from "@/components/views/dashboard-view"
import { LotteriesView } from "@/components/views/lotteries-view"
import { BetsView } from "@/components/views/bets-view"
import { PrizesView } from "@/components/views/prizes-view"
import { ChatView } from "@/components/views/chat-view"
import { MonitoringView } from "@/components/views/monitoring-view"
import { AuditView } from "@/components/views/audit-view"
import { SettingsView } from "@/components/views/settings-view"
import { FinancesView } from "@/components/views/finances-view"
import { ConfidenceHistoryView } from "@/components/views/confidence-history-view"
import { GateConfigView } from "@/components/views/gate-config-view"
import { EvolutionView } from "@/components/views/evolution-view"
import { AutoSyncEngine } from "@/components/auto-sync-engine"
import { NeuralEvolutionEngine } from "@/components/neural-evolution-engine"

function ActiveView() {
  const { activeView } = useApp()

  const views: Record<string, React.ReactNode> = {
    dashboard: <DashboardView />,
    lotteries: <LotteriesView />,
    bets: <BetsView />,
    prizes: <PrizesView />,
    finances: <FinancesView />,
    "confidence-history": <ConfidenceHistoryView />,
    "gate-config": <GateConfigView />,
    evolution: <EvolutionView />,
    chat: <ChatView />,
    monitoring: <MonitoringView />,
    audit: <AuditView />,
    settings: <SettingsView />,
  }

  return <>{views[activeView] || <DashboardView />}</>
}

function AppContent() {
  const { isAuthenticated } = useApp()

  if (!isAuthenticated) {
    return <AuthScreen />
  }

  return (
    <div className="min-h-screen flex" style={{ background: "hsl(220 15% 4%)" }}>
      <AutoSyncEngine />
      <NeuralEvolutionEngine />
      <SidebarNav />
      <main className="flex-1 md:ml-64 pt-16 md:pt-6 px-4 pb-4 md:px-6 md:pb-6 overflow-y-auto min-h-screen">
        <ActiveView />
      </main>
    </div>
  )
}

export default function Page() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  )
}
