import type { Metadata, Viewport } from "next"
import { JetBrains_Mono, Inter } from "next/font/google"
import "./globals.css"
import { ServiceWorkerRegister } from "@/components/sw-register"

const _inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const _jetbrains = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jetbrains" })

export const metadata: Metadata = {
  title: "DOMMO CORE - O Terror das Loterias",
  description:
    "Sistema de Inteligencia Estatistica para Loterias Brasileiras. 185 motores de IA especializados com analise avancada em tempo real.",
  generator: "DommoCore v3.1",
  applicationName: "DOMMO CORE",
  authors: [{ name: "DommoCore Team" }],
  keywords: [
    "loteria",
    "mega-sena",
    "lotofacil",
    "quina",
    "timemania",
    "lotomania",
    "dupla-sena",
    "dia-de-sorte",
    "super-sete",
    "mais-milionaria",
    "inteligencia-artificial",
    "estatistica",
  ],
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "DOMMO CORE",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    title: "DOMMO CORE - O Terror das Loterias",
    description: "Sistema de Inteligencia Estatistica com 185 IAs especializadas para Loterias Brasileiras",
    type: "website",
    siteName: "DOMMO CORE",
    locale: "pt_BR",
  },
  robots: {
    index: false,
    follow: false,
  },
  other: {
    "mobile-web-app-capable": "yes",
    "apple-mobile-web-app-capable": "yes",
    "apple-mobile-web-app-status-bar-style": "black-translucent",
    "msapplication-TileColor": "#0B0E14",
    "msapplication-config": "none",
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: dark)", color: "#0B0E14" },
    { media: "(prefers-color-scheme: light)", color: "#0B0E14" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
  viewportFit: "cover",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR" className="dark" dir="ltr">
      <head>
        <link rel="manifest" href="/manifest.webmanifest" crossOrigin="use-credentials" />
        <meta name="theme-color" content="#0B0E14" />
        <meta name="color-scheme" content="dark" />
      </head>
      <body className={`${_inter.variable} ${_jetbrains.variable} font-sans antialiased`}>
        <ServiceWorkerRegister />
        {children}
      </body>
    </html>
  )
}
