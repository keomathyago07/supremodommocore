import { ImageResponse } from "next/og"

export const runtime = "edge"
export const size = { width: 180, height: 180 }
export const contentType = "image/png"

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 180,
          height: 180,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: "linear-gradient(160deg, #0a0d12 0%, #0f1822 50%, #0a1628 100%)",
          borderRadius: 36,
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Glow */}
        <div style={{ position: "absolute", top: 10, left: 40, width: 100, height: 100, borderRadius: "50%", background: "radial-gradient(circle, rgba(0,229,255,0.15) 0%, transparent 70%)", display: "flex" }} />
        <svg width="100" height="100" viewBox="0 0 26 26" fill="none">
          <line x1="13" y1="2" x2="13" y2="5" stroke="#00E5FF" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="13" cy="1.5" r="1.5" fill="#FFD700" />
          <rect x="5" y="5" width="16" height="12" rx="3" fill="#141e2e" stroke="#00E5FF" strokeWidth="0.8" />
          <circle cx="9.5" cy="11" r="2.5" fill="#00E5FF" opacity="0.9" />
          <circle cx="16.5" cy="11" r="2.5" fill="#00E5FF" opacity="0.9" />
          <circle cx="9.5" cy="11" r="1" fill="#ffffff" />
          <circle cx="16.5" cy="11" r="1" fill="#ffffff" />
          <line x1="7" y1="8" x2="19" y2="8" stroke="#FFD700" strokeWidth="0.5" opacity="0.6" />
          <rect x="8" y="17" width="10" height="4" rx="2" fill="#1a2a3e" stroke="#00E5FF" strokeWidth="0.5" />
          <line x1="10" y1="19" x2="16" y2="19" stroke="#00E5FF" strokeWidth="0.8" strokeLinecap="round" opacity="0.7" />
          <rect x="3" y="9" width="2" height="4" rx="1" fill="#FFD700" opacity="0.6" />
          <rect x="21" y="9" width="2" height="4" rx="1" fill="#FFD700" opacity="0.6" />
        </svg>
        <div style={{ display: "flex", marginTop: 2, fontSize: 14, fontWeight: 900, color: "#00E5FF", letterSpacing: "0.2em" }}>
          DOMMO
        </div>
      </div>
    ),
    { ...size }
  )
}
