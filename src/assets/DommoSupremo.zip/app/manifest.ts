import type { MetadataRoute } from "next"

export default function manifest(): MetadataRoute.Manifest {
  return {
    id: "com.dommocore.app",
    name: "DOMMO CORE - O Terror das Loterias",
    short_name: "DOMMO CORE",
    description:
      "Sistema de Inteligencia Estatistica para Loterias Brasileiras com 185 motores de IA especializados.",
    start_url: "/?source=pwa",
    scope: "/",
    display: "standalone",
    display_override: ["standalone", "window-controls-overlay"],
    background_color: "#0B0E14",
    theme_color: "#0B0E14",
    orientation: "any",
    dir: "ltr",
    lang: "pt-BR",
    prefer_related_applications: false,
    categories: ["utilities", "finance", "productivity"],
    launch_handler: {
      client_mode: "focus-existing",
    },
    icons: [
      {
        src: "/api/pwa-icon?size=48",
        sizes: "48x48",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=72",
        sizes: "72x72",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=96",
        sizes: "96x96",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=128",
        sizes: "128x128",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=144",
        sizes: "144x144",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=192",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=256",
        sizes: "256x256",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=384",
        sizes: "384x384",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=512",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/api/pwa-icon?size=512&maskable=1",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
    screenshots: [
      {
        src: "/api/pwa-icon?size=512",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  }
}
