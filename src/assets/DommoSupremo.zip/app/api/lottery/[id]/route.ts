import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const APILOTERIAS_BASE = "https://apiloterias.com.br/app/v2/resultado"

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}

function canonicalLotteryId(id: string): string {
  const s = (id || "").trim().toLowerCase().replace(/_/g, "-").replace(/ /g, "-")
  const alias: Record<string, string> = {
    "mega-sena": "megasena",
    "+milionaria": "maismilionaria",
    "mais-milionaria": "maismilionaria",
    "dia-de-sorte": "diadesorte",
    "dupla-sena": "duplasena",
    "super-sete": "supersete",
    "loto-facil": "lotofacil",
    "loto-mania": "lotomania",
    "time-mania": "timemania",
  }
  return alias[s] || s.replace(/-/g, "")
}

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const { searchParams } = new URL(request.url)
  const token = searchParams.get("token") || process.env.APILOTERIAS_TOKEN || ""
  const contest = searchParams.get("contest")
  const source = searchParams.get("source") || "api"

  const lotteryId = canonicalLotteryId(id)

  if (source === "db") {
    const supabase = getSupabase()
    let query = supabase.from(lotteryId).select("*").order("contest_id", { ascending: false })
    if (contest) {
      query = supabase.from(lotteryId).select("*").eq("contest_id", Number(contest))
    } else {
      query = query.limit(1)
    }
    const { data, error } = await query
    if (error) {
      return NextResponse.json({ error: error.message, code: "DB_ERROR" }, { status: 500 })
    }
    if (data && data.length > 0) {
      const row = data[0]
      return NextResponse.json({
        lottery_id: lotteryId,
        contest_id: row.contest_id,
        date: row.draw_date,
        numbers: row.numbers,
        accumulated: row.accumulated,
        next_prize_estimate: row.prize_estimate,
        accumulated_value: row.accumulated_value,
        prizes: row.prizes,
        extras: {
          trevos: row.trevos || [],
          month: row.lucky_month || "",
          team: row.team || "",
        },
        source: "database",
      })
    }
    return NextResponse.json({ error: "No data in database", code: "NO_DATA" }, { status: 404 })
  }

  if (!token) {
    return NextResponse.json({ error: "API token not configured", code: "NO_TOKEN" }, { status: 400 })
  }

  try {
    const apiUrl = new URL(APILOTERIAS_BASE)
    apiUrl.searchParams.set("loteria", lotteryId)
    apiUrl.searchParams.set("token", token)
    if (contest) apiUrl.searchParams.set("concurso", contest)

    const res = await fetch(apiUrl.toString(), {
      next: { revalidate: 300 },
      headers: { "User-Agent": "DommoCore/1.0" },
    })

    if (!res.ok) {
      return NextResponse.json({ error: `API returned ${res.status}`, code: "API_ERROR" }, { status: res.status })
    }

    const data = await res.json()

    const concurso = data.concurso || data.numero_concurso || data.numero || 0
    const dataConcurso = data.data_concurso || data.dataApuracao || data.data || ""
    const dezenas = data.dezenas || data.listaDezenas || data.numeros || []
    const acumulado = data.acumulou !== undefined ? data.acumulou : data.acumulado
    const valorEstimado = data.valor_estimado_proximo_concurso || data.valorEstimadoProximoConcurso || 0
    const valorAcumulado = data.valor_acumulado || data.valorAcumuladoProximoConcurso || 0
    const premiacao = data.premiacao || data.listaRateioPremio || []
    const trevos = data.trevosSorteados || data.trevos || []
    const mesSorte = data.nomeTimeCoracaoMesSorte || data.mesSorte || data.mes_da_sorte || ""
    const timeCoracao = data.timeCoracao || data.time_coracao || ""

    const normalized = {
      lottery_id: lotteryId,
      contest_id: concurso,
      date: dataConcurso,
      numbers: dezenas.map((n: string | number) => Number(n)),
      accumulated: acumulado,
      next_prize_estimate: valorEstimado,
      accumulated_value: valorAcumulado,
      prizes: premiacao,
      extras: {
        trevos: trevos.map((n: string | number) => Number(n)),
        month: mesSorte,
        team: timeCoracao,
      },
      raw: data,
      source: "api",
    }

    try {
      const supabase = getSupabase()
      const baseRow = {
        contest_id: concurso,
        draw_date: dataConcurso,
        numbers: normalized.numbers,
        accumulated: Boolean(acumulado),
        prize_estimate: Number(valorEstimado) || 0,
        accumulated_value: Number(valorAcumulado) || 0,
        prizes: premiacao,
        raw_data: data,
        synced_at: new Date().toISOString(),
      }

      const extraFields: Record<string, Record<string, unknown>> = {
        timemania: { team: timeCoracao },
        duplasena: { numbers_2: (data.dezenas_2 || []).map((n: string | number) => Number(n)) },
        diadesorte: { lucky_month: mesSorte },
        supersete: { columns: normalized.numbers },
        maismilionaria: { trevos: normalized.extras.trevos },
      }

      const row = { ...baseRow, ...(extraFields[lotteryId] || {}) }

      await supabase.from(lotteryId).upsert(row, { onConflict: "contest_id" })
      
      await supabase.from("draws").upsert({
        lottery_id: lotteryId,
        contest_id: concurso,
        draw_date: dataConcurso,
        numbers: normalized.numbers,
        accumulated: Boolean(acumulado),
        prize_estimate: Number(valorEstimado) || 0,
        accumulated_value: Number(valorAcumulado) || 0,
        prizes: premiacao,
        extras: normalized.extras,
        raw_data: data,
        synced_at: new Date().toISOString(),
      }, { onConflict: "lottery_id,contest_id" })
    } catch (dbErr) {
      console.error(`[v0] DB save error for ${lotteryId}:`, dbErr)
    }

    return NextResponse.json(normalized)
  } catch (err) {
    return NextResponse.json(
      { error: "Failed to fetch lottery data", code: "FETCH_ERROR", details: String(err) },
      { status: 500 }
    )
  }
}
