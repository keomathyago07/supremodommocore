import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

function getSupabase() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { lottery_id, lottery_name, contest_id, confidence, threshold, gate_status, model_name, numbers, extras, analysis_window, notes } = body

    if (!lottery_id || confidence === undefined) {
      return NextResponse.json({ error: "Missing lottery_id or confidence" }, { status: 400 })
    }

    const supabase = getSupabase()
    const now = new Date()

    const { data, error } = await supabase.from("confidence_gate_logs").insert({
      lottery_id,
      lottery_name: lottery_name || lottery_id,
      contest_id: Number(contest_id) || 0,
      confidence: Number(confidence),
      threshold: Number(threshold) || 0.999,
      gate_status: gate_status || (Number(confidence) >= 0.999 ? "APPROVED" : "BLOCKED"),
      model_name: model_name || "",
      numbers: numbers || [],
      extras: extras || {},
      analysis_window: Number(analysis_window) || 0,
      triggered_at: now.toISOString(),
      year: now.getFullYear(),
      month: now.getMonth() + 1,
      day: now.getDate(),
      hour: now.getHours(),
      minute: now.getMinutes(),
      notes: notes || "",
    }).select()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ success: true, log: data?.[0] })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from("confidence_gate_logs")
      .select("*")
      .order("triggered_at", { ascending: false })
      .limit(200)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ logs: data || [], total: data?.length || 0 })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
