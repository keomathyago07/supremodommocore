import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

function getSupabase() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

const PRIZE_TIERS: Record<string, Record<number, string>> = {
  megasena: { 6: "Sena (6 acertos)", 5: "Quina (5 acertos)", 4: "Quadra (4 acertos)" },
  lotofacil: { 15: "15 acertos", 14: "14 acertos", 13: "13 acertos", 12: "12 acertos", 11: "11 acertos" },
  quina: { 5: "Quina (5 acertos)", 4: "Quadra (4 acertos)", 3: "Terno (3 acertos)", 2: "Duque (2 acertos)" },
  lotomania: { 20: "20 acertos", 19: "19 acertos", 18: "18 acertos", 17: "17 acertos", 16: "16 acertos", 15: "15 acertos", 0: "0 acertos" },
  timemania: { 7: "7 acertos", 6: "6 acertos", 5: "5 acertos", 4: "4 acertos", 3: "3 acertos" },
  duplasena: { 6: "Sena (6 acertos)", 5: "Quina (5 acertos)", 4: "Quadra (4 acertos)", 3: "Terno (3 acertos)" },
  diadesorte: { 7: "7 acertos", 6: "6 acertos", 5: "5 acertos", 4: "4 acertos" },
  supersete: { 7: "7 acertos", 6: "6 acertos", 5: "5 acertos", 4: "4 acertos", 3: "3 acertos" },
  maismilionaria: { 6: "6+2 acertos", 5: "5+2 acertos", 4: "4+2 acertos" },
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { token } = body

    if (!token) {
      return NextResponse.json({ error: "Missing API token" }, { status: 400 })
    }

    const supabase = getSupabase()

    // Get all confirmed but unchecked bets
    const { data: pendingBets, error: fetchError } = await supabase
      .from("saved_bets")
      .select("*")
      .eq("confirmed", true)
      .eq("result_checked", false)

    if (fetchError) {
      return NextResponse.json({ error: fetchError.message }, { status: 500 })
    }

    if (!pendingBets || pendingBets.length === 0) {
      return NextResponse.json({ message: "No pending bets to check", checked: 0, results: [] })
    }

    const results: Array<Record<string, unknown>> = []

    for (const bet of pendingBets) {
      try {
        const url = `https://apiloterias.com.br/app/v2/resultado?loteria=${bet.lottery_id}&token=${token}`
        const res = await fetch(url, { headers: { "User-Agent": "DommoCore/2.0" } })
        if (!res.ok) continue
        const data = await res.json()

        const concurso = data.concurso || data.numero_concurso || 0
        const dezenas = (data.dezenas || data.listaDezenas || data.numeros || []).map((n: string | number) => Number(n))

        if (dezenas.length === 0) continue

        const betNumbers: number[] = bet.numbers || []
        const drawnSet = new Set(dezenas)
        const matchCount = betNumbers.filter((n: number) => drawnSet.has(n)).length
        const matchedNumbers = betNumbers.filter((n: number) => drawnSet.has(n))
        const missedNumbers = betNumbers.filter((n: number) => !drawnSet.has(n))

        // Determine prize tier from our tier map
        const lotteryTiers = PRIZE_TIERS[bet.lottery_id] || {}
        let prizeTier = lotteryTiers[matchCount] || `${matchCount} acertos`
        let isWinner = false

        // Determine if it's a prize-winning match count
        if (lotteryTiers[matchCount]) {
          isWinner = true
        }

        // Special case for lotomania: 0 matches also wins
        if (bet.lottery_id === "lotomania" && matchCount === 0) {
          isWinner = true
          prizeTier = "0 acertos (premio especial)"
        }

        const dataConcurso = data.data_concurso || data.dataApuracao || data.data || ""

        // Get prize amounts if available
        const premiacoes = data.premiacoes || data.lista_premiacoes || []
        let prizeAmount = 0
        if (premiacoes.length > 0) {
          const matchingPrize = premiacoes.find((p: { acertos: string | number; descricao: string }) => {
            return Number(p.acertos) === matchCount || p.descricao?.includes(`${matchCount}`)
          })
          if (matchingPrize) {
            prizeAmount = Number(matchingPrize.valor_total || matchingPrize.premio || 0)
          }
        }

        // Update the bet in DB with comprehensive details
        await supabase.from("saved_bets").update({
          result_numbers: dezenas,
          result_checked: true,
          result_checked_at: new Date().toISOString(),
          matches_count: matchCount,
          prize_tier: prizeTier,
          prize_amount: prizeAmount,
          is_winner: isWinner,
          draw_date: dataConcurso || null,
          contest_number: concurso,
        }).eq("id", bet.id)

        const resultEntry = {
          bet_id: bet.id,
          lottery_id: bet.lottery_id,
          lottery_name: bet.lottery_name,
          contest_number: concurso,
          bet_numbers: betNumbers,
          drawn_numbers: dezenas,
          matched_numbers: matchedNumbers,
          missed_numbers: missedNumbers,
          matches: matchCount,
          total_numbers: betNumbers.length,
          is_winner: isWinner,
          prize_tier: prizeTier,
          prize_amount: prizeAmount,
          draw_date: dataConcurso,
          confidence: bet.confidence,
          model_name: bet.model_name || "unknown",
          checked_at: new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" }),
        }

        results.push(resultEntry)

        // Detailed audit log
        const auditDetails = isWinner
          ? `PREMIACAO! ${bet.lottery_name} Concurso #${concurso}: ${matchCount}/${betNumbers.length} acertos (${prizeTier}). Numeros apostados: [${betNumbers.join(",")}]. Sorteados: [${dezenas.join(",")}]. Acertados: [${matchedNumbers.join(",")}]. Confianca: ${(bet.confidence * 100).toFixed(3)}%. Modelo: ${bet.model_name || "N/A"}.`
          : `${bet.lottery_name} Concurso #${concurso}: ${matchCount}/${betNumbers.length} acertos. Numeros apostados: [${betNumbers.join(",")}]. Sorteados: [${dezenas.join(",")}]. Acertados: [${matchedNumbers.join(",")}]. Errados: [${missedNumbers.join(",")}]. Confianca: ${(bet.confidence * 100).toFixed(3)}%.`

        await supabase.from("audit_logs").insert({
          action: isWinner ? "PRIZE_WON" : "RESULT_CHECKED",
          entity: bet.lottery_id,
          entity_id: `${bet.lottery_id}:${concurso}`,
          details: auditDetails,
          severity: isWinner ? "warning" : "info",
        })
      } catch { /* skip individual bet errors */ }
    }

    const winners = results.filter(r => r.is_winner)
    const totalMatches = results.reduce((sum, r) => sum + (r.matches as number), 0)

    return NextResponse.json({
      success: true,
      checked: results.length,
      total_pending: pendingBets.length,
      winners_count: winners.length,
      total_matches: totalMatches,
      results,
      winners,
      checked_at: new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" }),
      summary: {
        total_bets_checked: results.length,
        total_winners: winners.length,
        total_matches: totalMatches,
        average_matches: results.length > 0 ? (totalMatches / results.length).toFixed(1) : "0",
        best_result: results.length > 0 ? results.reduce((best, r) => (r.matches as number) > (best.matches as number) ? r : best, results[0]) : null,
      },
    })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = getSupabase()

    const { data: confirmedBets, error } = await supabase
      .from("saved_bets")
      .select("*")
      .eq("confirmed", true)
      .order("created_at", { ascending: false })
      .limit(100)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    const checked = confirmedBets?.filter(b => b.result_checked) || []
    const pending = confirmedBets?.filter(b => !b.result_checked) || []
    const winners = checked.filter(b => b.is_winner)

    return NextResponse.json({
      total: confirmedBets?.length || 0,
      checked: checked.length,
      pending: pending.length,
      winners: winners.length,
      bets: confirmedBets || [],
      detailed_results: checked.map(b => ({
        id: b.id,
        lottery_name: b.lottery_name,
        contest_number: b.contest_number,
        bet_numbers: b.numbers,
        result_numbers: b.result_numbers,
        matches_count: b.matches_count,
        is_winner: b.is_winner,
        prize_tier: b.prize_tier,
        prize_amount: b.prize_amount,
        confidence: b.confidence,
        checked_at: b.result_checked_at,
      })),
    })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
