import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

const LOTTERIES = [
  "megasena", "lotofacil", "quina", "lotomania",
  "timemania", "duplasena", "diadesorte", "supersete", "maismilionaria",
]

const APILOTERIAS_BASE = "https://apiloterias.com.br/app/v2/resultado"

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}

async function saveLotteryDraw(lotteryId: string, data: Record<string, unknown>) {
  const supabase = getSupabase()
  const concurso = Number(data.contest_id) || 0
  if (concurso === 0) return

  const baseRow = {
    contest_id: concurso,
    draw_date: String(data.date || ""),
    numbers: data.numbers as number[],
    accumulated: Boolean(data.accumulated),
    prize_estimate: Number(data.next_prize_estimate) || 0,
    accumulated_value: Number(data.accumulated_value) || 0,
    prizes: data.prizes || [],
    raw_data: data.raw || data,
    synced_at: new Date().toISOString(),
  }

  const lotterySpecific: Record<string, Record<string, unknown>> = {
    megasena: baseRow,
    lotofacil: baseRow,
    quina: baseRow,
    lotomania: baseRow,
    timemania: { ...baseRow, team: (data.extras as Record<string, unknown>)?.team || "" },
    duplasena: { ...baseRow, numbers_2: (data.raw as Record<string, unknown>)?.dezenas_2 || [] },
    diadesorte: { ...baseRow, lucky_month: (data.extras as Record<string, unknown>)?.month || "" },
    supersete: { ...baseRow, columns: data.numbers || [] },
    maismilionaria: { ...baseRow, trevos: (data.extras as Record<string, unknown>)?.trevos || [] },
  }

  const row = lotterySpecific[lotteryId] || baseRow

  await supabase
    .from(lotteryId)
    .upsert(row, { onConflict: "contest_id" })

  await supabase
    .from("draws")
    .upsert({
      lottery_id: lotteryId,
      contest_id: concurso,
      draw_date: String(data.date || ""),
      numbers: data.numbers as number[],
      accumulated: Boolean(data.accumulated),
      prize_estimate: Number(data.next_prize_estimate) || 0,
      accumulated_value: Number(data.accumulated_value) || 0,
      prizes: data.prizes || [],
      extras: data.extras || {},
      raw_data: data.raw || data,
      synced_at: new Date().toISOString(),
    }, { onConflict: "lottery_id,contest_id" })

  await supabase
    .from("sync_status")
    .upsert({
      lottery_id: lotteryId,
      last_sync_at: new Date().toISOString(),
      last_contest_id: concurso,
      status: "success",
      error_message: null,
    }, { onConflict: "lottery_id" })

  await supabase.from("audit_logs").insert({
    action: "DRAW_SYNCED",
    entity: lotteryId,
    entity_id: `${lotteryId}:${concurso}`,
    details: `Contest #${concurso} synced and stored in database`,
    severity: "info",
  })
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const token = searchParams.get("token") || process.env.APILOTERIAS_TOKEN || ""

  if (!token) {
    return NextResponse.json({ error: "Token required" }, { status: 400 })
  }

  const results: Record<string, unknown> = {}
  const errors: Record<string, string> = {}

  await Promise.allSettled(
    LOTTERIES.map(async (lotteryId) => {
      try {
        const url = `${APILOTERIAS_BASE}?loteria=${lotteryId}&token=${token}`
        const res = await fetch(url, {
          next: { revalidate: 300 },
          headers: { "User-Agent": "DommoCore/1.0" },
        })
        if (!res.ok) {
          errors[lotteryId] = `HTTP ${res.status}`
          return
        }
        const data = await res.json()
        const concurso = data.concurso || data.numero_concurso || data.numero || 0
        const dataConcurso = data.data_concurso || data.dataApuracao || data.data || ""
        const dezenas = data.dezenas || data.listaDezenas || data.numeros || []
        const acumulado = data.acumulou !== undefined ? data.acumulou : data.acumulado
        const valorEstimado = data.valor_estimado_proximo_concurso || data.valorEstimadoProximoConcurso || 0
        const valorAcumulado = data.valor_acumulado || data.valorAcumuladoProximoConcurso || 0
        const premiacao = data.premiacao || data.listaRateioPremio || []
        const trevos = data.trevosSorteados || data.trevos || []
        const mesSorte = data.nomeTimeCoracaoMesSorte || data.mesSorte || data.mes_da_sorte || ""
        const timeCoracao = data.timeCoracao || data.time_coracao || ""
        const dezenas2 = data.dezenas_2 || []

        const normalized = {
          lottery_id: lotteryId,
          contest_id: concurso,
          date: dataConcurso,
          numbers: dezenas.map((n: string | number) => Number(n)),
          accumulated: acumulado,
          next_prize_estimate: valorEstimado,
          accumulated_value: valorAcumulado,
          prizes: premiacao,
          extras: {
            trevos: trevos.map((n: string | number) => Number(n)),
            month: mesSorte,
            team: timeCoracao,
          },
          raw: { ...data, dezenas_2: dezenas2 },
        }

        results[lotteryId] = normalized

        try {
          await saveLotteryDraw(lotteryId, normalized)
        } catch (dbErr) {
          console.error(`[v0] DB save error for ${lotteryId}:`, dbErr)
        }
      } catch (e) {
        errors[lotteryId] = String(e)
        try {
          const supabase = getSupabase()
          await supabase.from("sync_status").upsert({
            lottery_id: lotteryId,
            last_sync_at: new Date().toISOString(),
            status: "error",
            error_message: String(e),
          }, { onConflict: "lottery_id" })
        } catch { /* ignore */ }
      }
    })
  )

  return NextResponse.json({
    synced_at: new Date().toISOString(),
    total: LOTTERIES.length,
    success: Object.keys(results).length,
    failed: Object.keys(errors).length,
    stored_in_supabase: true,
    results,
    errors,
  })
}
