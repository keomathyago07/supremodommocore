import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

function getSupabase() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  )
}

export async function GET() {
  const supabase = getSupabase()

  const { data: syncData } = await supabase
    .from("sync_status")
    .select("*")
    .order("lottery_id")

  const counts: Record<string, number> = {}
  const tables = [
    "megasena", "lotofacil", "quina", "lotomania",
    "timemania", "duplasena", "diadesorte", "supersete", "maismilionaria",
  ]

  for (const table of tables) {
    const { count } = await supabase
      .from(table)
      .select("*", { count: "exact", head: true })
    counts[table] = count || 0
  }

  return NextResponse.json({
    sync_status: syncData || [],
    record_counts: counts,
    total_records: Object.values(counts).reduce((a, b) => a + b, 0),
  })
}
