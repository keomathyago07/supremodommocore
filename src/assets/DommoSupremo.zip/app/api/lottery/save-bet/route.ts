import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

function getSupabase() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { lottery_id, lottery_name, contest_id, numbers, extras, confidence, date, device_origin, sync_id } = body

    if (!lottery_id || !numbers) {
      return NextResponse.json({ error: "Missing lottery_id or numbers" }, { status: 400 })
    }

    const supabase = getSupabase()
    const now = new Date()

    const { data, error } = await supabase.from("saved_bets").insert({
      lottery_id,
      lottery_name: lottery_name || lottery_id,
      numbers,
      confidence: Number(confidence) || 0,
      gate_status: Number(confidence) >= 0.85 ? "APPROVED" : "BLOCKED",
      model_name: body.model_name || "",
      extras: extras || {},
      confirmed: true,
      confirmed_at: now.toISOString(),
      contest_number: Number(contest_id) || 0,
      draw_date: date || null,
      result_numbers: [],
      result_checked: false,
      matches_count: 0,
      prize_tier: "",
      prize_amount: 0,
      is_winner: false,
      year: now.getFullYear(),
      sync_id: sync_id || `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      device_origin: device_origin || "web",
      created_at: now.toISOString(),
    }).select()

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    // Log confidence gate event if approved
    if (Number(confidence) >= 0.85) {
      await supabase.from("confidence_gate_logs").insert({
        lottery_id,
        lottery_name: lottery_name || lottery_id,
        contest_id: Number(contest_id) || 0,
        confidence: Number(confidence),
        threshold: Number(confidence),
        gate_status: "APPROVED",
        model_name: body.model_name || "",
        numbers,
        extras: extras || {},
        analysis_window: Number(body.analysis_window) || 0,
        triggered_at: now.toISOString(),
        year: now.getFullYear(),
        month: now.getMonth() + 1,
        day: now.getDate(),
        hour: now.getHours(),
        minute: now.getMinutes(),
        notes: "Auto-logged on bet confirmation",
      })
    }

    await supabase.from("audit_logs").insert({
      action: "BET_CONFIRMED",
      entity: lottery_id,
      entity_id: `${lottery_id}:${contest_id}`,
      details: `Bet confirmed for ${lottery_name || lottery_id} contest #${contest_id} with ${numbers.length} numbers. Confidence: ${(Number(confidence) * 100).toFixed(2)}%. Saved to DB with full tracking.`,
      severity: "info",
    })

    return NextResponse.json({ success: true, bet: data?.[0], message: "Bet confirmed and saved to Supabase with full tracking" })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}

export async function GET() {
  try {
    const supabase = getSupabase()
    const { data, error } = await supabase
      .from("saved_bets")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(100)

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ bets: data || [], total: data?.length || 0 })
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 })
  }
}
