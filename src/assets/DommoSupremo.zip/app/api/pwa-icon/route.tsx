import { ImageResponse } from "next/og"
import { type NextRequest } from "next/server"

export const runtime = "edge"

function DommoIcon({ s, maskable }: { s: number; maskable: boolean }) {
  const r = maskable ? 0 : s * 0.18
  const padding = maskable ? s * 0.1 : 0
  const inner = s - padding * 2
  const svgS = inner * 0.45
  const headW = svgS * 0.6
  const headH = svgS * 0.4
  const headX = (svgS - headW) / 2
  const eyeW = headW * 0.25
  const eyeH = headH * 0.25
  const eyeY = headH * 0.35
  const bodyW = svgS * 0.7
  const bodyH = svgS * 0.4
  const bodyX = (svgS - bodyW) / 2
  const bodyY = headH + svgS * 0.02
  const lineH = svgS * 0.035

  return (
    <div
      style={{
        width: s,
        height: s,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "linear-gradient(160deg, #0B0E14, #131720, #0d1117)",
        borderRadius: r,
      }}
    >
      <svg width={svgS} height={svgS} viewBox={`0 0 ${svgS} ${svgS}`} fill="none">
        {/* Head */}
        <rect x={headX} y={0} width={headW} height={headH} rx={svgS * 0.1} fill="#00E5FF" opacity="0.9" />
        {/* Antenna */}
        <line
          x1={svgS / 2}
          y1={0}
          x2={svgS / 2}
          y2={-svgS * 0.08}
          stroke="#FFD700"
          strokeWidth={svgS * 0.02}
          strokeLinecap="round"
        />
        <circle cx={svgS / 2} cy={-svgS * 0.1} r={svgS * 0.025} fill="#FFD700" />
        {/* Eyes */}
        <rect
          x={headX + headW * 0.15}
          y={eyeY}
          width={eyeW}
          height={eyeH}
          rx={svgS * 0.025}
          fill="#0B0E14"
        />
        <rect
          x={headX + headW * 0.6}
          y={eyeY}
          width={eyeW}
          height={eyeH}
          rx={svgS * 0.025}
          fill="#0B0E14"
        />
        {/* Eye glow */}
        <rect
          x={headX + headW * 0.17}
          y={eyeY + eyeH * 0.15}
          width={eyeW * 0.4}
          height={eyeH * 0.35}
          rx={svgS * 0.01}
          fill="#00E5FF"
          opacity="0.6"
        />
        <rect
          x={headX + headW * 0.62}
          y={eyeY + eyeH * 0.15}
          width={eyeW * 0.4}
          height={eyeH * 0.35}
          rx={svgS * 0.01}
          fill="#00E5FF"
          opacity="0.6"
        />
        {/* Body */}
        <rect x={bodyX} y={bodyY} width={bodyW} height={bodyH} rx={svgS * 0.1} fill="#1a2030" />
        {/* Body glow border */}
        <rect
          x={bodyX}
          y={bodyY}
          width={bodyW}
          height={bodyH}
          rx={svgS * 0.1}
          fill="none"
          stroke="#00E5FF"
          strokeWidth={svgS * 0.008}
          opacity="0.3"
        />
        {/* Data lines */}
        <rect
          x={bodyX + bodyW * 0.12}
          y={bodyY + bodyH * 0.25}
          width={bodyW * 0.7}
          height={lineH}
          rx={lineH / 2}
          fill="#00E5FF"
          opacity="0.4"
        />
        <rect
          x={bodyX + bodyW * 0.12}
          y={bodyY + bodyH * 0.42}
          width={bodyW * 0.5}
          height={lineH}
          rx={lineH / 2}
          fill="#00E5FF"
          opacity="0.3"
        />
        <rect
          x={bodyX + bodyW * 0.12}
          y={bodyY + bodyH * 0.59}
          width={bodyW * 0.3}
          height={lineH}
          rx={lineH / 2}
          fill="#FFD700"
          opacity="0.5"
        />
        {/* Shield icon at center of body */}
        <path
          d={`M${svgS / 2 - svgS * 0.04},${bodyY + bodyH * 0.73} L${svgS / 2},${bodyY + bodyH * 0.65} L${svgS / 2 + svgS * 0.04},${bodyY + bodyH * 0.73} L${svgS / 2},${bodyY + bodyH * 0.85} Z`}
          fill="#00E5FF"
          opacity="0.25"
        />
      </svg>
      {s >= 128 && (
        <div
          style={{
            display: "flex",
            marginTop: s * 0.02,
            fontSize: s * 0.07,
            fontWeight: 900,
            color: "#00E5FF",
            letterSpacing: "0.12em",
            textShadow: "0 0 10px rgba(0,229,255,0.3)",
          }}
        >
          DOMMO CORE
        </div>
      )}
    </div>
  )
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const sizeParam = searchParams.get("size") || "512"
  const maskable = searchParams.get("maskable") === "1"
  const s = parseInt(sizeParam, 10)
  const validSizes = [48, 72, 96, 128, 144, 192, 256, 384, 512]
  const validSize = validSizes.includes(s) ? s : 512

  const image = new ImageResponse(<DommoIcon s={validSize} maskable={maskable} />, {
    width: validSize,
    height: validSize,
  })

  return new Response(image.body, {
    headers: {
      "Content-Type": "image/png",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  })
}
