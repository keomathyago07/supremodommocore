import { ImageResponse } from "next/og"

export const runtime = "edge"
export const size = { width: 32, height: 32 }
export const contentType = "image/png"

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: 32,
          height: 32,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          background: "linear-gradient(135deg, #0a0d12 0%, #0f1822 50%, #0a1628 100%)",
          borderRadius: 8,
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Glow background */}
        <div
          style={{
            position: "absolute",
            top: -4,
            left: 6,
            width: 20,
            height: 20,
            borderRadius: "50%",
            background: "radial-gradient(circle, rgba(0,229,255,0.3) 0%, transparent 70%)",
            display: "flex",
          }}
        />
        {/* Robot head - sleek design */}
        <svg width="26" height="26" viewBox="0 0 26 26" fill="none">
          {/* Antenna */}
          <line x1="13" y1="2" x2="13" y2="5" stroke="#00E5FF" strokeWidth="1.5" strokeLinecap="round" />
          <circle cx="13" cy="1.5" r="1.5" fill="#FFD700" />
          {/* Head */}
          <rect x="5" y="5" width="16" height="12" rx="3" fill="#141e2e" stroke="#00E5FF" strokeWidth="0.8" />
          {/* Eyes */}
          <circle cx="9.5" cy="11" r="2.5" fill="#00E5FF" opacity="0.9" />
          <circle cx="16.5" cy="11" r="2.5" fill="#00E5FF" opacity="0.9" />
          <circle cx="9.5" cy="11" r="1" fill="#ffffff" />
          <circle cx="16.5" cy="11" r="1" fill="#ffffff" />
          {/* Visor line */}
          <line x1="7" y1="8" x2="19" y2="8" stroke="#FFD700" strokeWidth="0.5" opacity="0.6" />
          {/* Chin / jaw */}
          <rect x="8" y="17" width="10" height="4" rx="2" fill="#1a2a3e" stroke="#00E5FF" strokeWidth="0.5" />
          {/* Mouth line */}
          <line x1="10" y1="19" x2="16" y2="19" stroke="#00E5FF" strokeWidth="0.8" strokeLinecap="round" opacity="0.7" />
          {/* Side accents */}
          <rect x="3" y="9" width="2" height="4" rx="1" fill="#FFD700" opacity="0.6" />
          <rect x="21" y="9" width="2" height="4" rx="1" fill="#FFD700" opacity="0.6" />
        </svg>
      </div>
    ),
    { ...size }
  )
}
