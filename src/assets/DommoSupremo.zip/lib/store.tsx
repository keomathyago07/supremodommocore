"use client"

import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react"
import type { Locale } from "./i18n"
import { DEFAULT_AI_ENGINES, DEFAULT_GATE_CONFIG, type AIEngine, type GateConfig } from "./ai-engines"

// Keys for cross-device sync
const STORAGE_KEYS = {
  locale: "dommo_locale",
  apiToken: "dommo_api_token",
  gateConfig: "dommo_gate_config",
  aiEngines: "dommo_ai_engines",
  deviceId: "dommo_device_id",
  dailySuggestions: "dommo_daily_suggestions",
  confirmedBets: "dommo_confirmed_bets",
  lastView: "dommo_last_view",
  backgroundEnabled: "dommo_background_enabled",
  notifHour: "dommo_notif_hour",
  notifMinute: "dommo_notif_minute",
  aiConfig: "dommo_ai_config",
  customLotteries: "dommo_custom_lotteries",
  openaiKey: "dommo_openai_key",
} as const

export interface SyncedSuggestion {
  lotteryId: string
  lotteryName: string
  numbers: number[]
  extras?: { trevos?: number[]; month?: string }
  confidence: number
  gateStatus: "APPROVED" | "BLOCKED"
  model: string
  contestId: number
  generatedAt: string
  brasiliaTime: string
  analysisWindow: number
}

interface AppState {
  locale: Locale
  setLocale: (l: Locale) => void
  apiToken: string
  setApiToken: (t: string) => void
  isAuthenticated: boolean
  setIsAuthenticated: (v: boolean) => void
  activeView: string
  setActiveView: (v: string) => void
  sidebarOpen: boolean
  setSidebarOpen: (v: boolean) => void
  gateConfig: GateConfig
  setGateConfig: (c: GateConfig) => void
  aiEngines: AIEngine[]
  setAiEngines: (e: AIEngine[]) => void
  backgroundEnabled: boolean
  setBackgroundEnabled: (v: boolean) => void
  syncedSuggestions: SyncedSuggestion[]
  setSyncedSuggestions: (s: SyncedSuggestion[]) => void
}

const AppContext = createContext<AppState | null>(null)

export function AppProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("pt-BR")
  const [apiToken, setApiTokenState] = useState("")
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [activeView, setActiveViewState] = useState("dashboard")
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [gateConfig, setGateConfigState] = useState<GateConfig>(DEFAULT_GATE_CONFIG)
  const [aiEngines, setAiEnginesState] = useState<AIEngine[]>(DEFAULT_AI_ENGINES)
  const [backgroundEnabled, setBackgroundEnabledState] = useState(true)
  const [syncedSuggestions, setSyncedSuggestionsState] = useState<SyncedSuggestion[]>([])

  // Load all saved state on mount
  useEffect(() => {
    const savedLocale = localStorage.getItem(STORAGE_KEYS.locale) as Locale | null
    if (savedLocale === "pt-BR" || savedLocale === "en") setLocaleState(savedLocale)

    const savedToken = localStorage.getItem(STORAGE_KEYS.apiToken)
    if (savedToken) setApiTokenState(savedToken)

    const savedGate = localStorage.getItem(STORAGE_KEYS.gateConfig)
    if (savedGate) { try { setGateConfigState(JSON.parse(savedGate)) } catch { /* ignore */ } }

    const savedEngines = localStorage.getItem(STORAGE_KEYS.aiEngines)
    if (savedEngines) { try { setAiEnginesState(JSON.parse(savedEngines)) } catch { /* ignore */ } }

    const savedBg = localStorage.getItem(STORAGE_KEYS.backgroundEnabled)
    if (savedBg !== null) setBackgroundEnabledState(savedBg === "true")

    const savedSuggestions = localStorage.getItem(STORAGE_KEYS.dailySuggestions)
    if (savedSuggestions) { try { setSyncedSuggestionsState(JSON.parse(savedSuggestions)) } catch { /* ignore */ } }

    const savedView = localStorage.getItem(STORAGE_KEYS.lastView)
    if (savedView) setActiveViewState(savedView)

    // Listen for storage events from other tabs/windows for cross-device sync
    const handleStorage = (e: StorageEvent) => {
      if (e.key === STORAGE_KEYS.dailySuggestions && e.newValue) {
        try { setSyncedSuggestionsState(JSON.parse(e.newValue)) } catch { /* ignore */ }
      }
      if (e.key === STORAGE_KEYS.gateConfig && e.newValue) {
        try { setGateConfigState(JSON.parse(e.newValue)) } catch { /* ignore */ }
      }
      if (e.key === STORAGE_KEYS.aiEngines && e.newValue) {
        try { setAiEnginesState(JSON.parse(e.newValue)) } catch { /* ignore */ }
      }
      if (e.key === STORAGE_KEYS.locale && e.newValue) {
        if (e.newValue === "pt-BR" || e.newValue === "en") setLocaleState(e.newValue)
      }
      if (e.key === STORAGE_KEYS.apiToken && e.newValue) {
        setApiTokenState(e.newValue)
      }
      if (e.key === STORAGE_KEYS.backgroundEnabled && e.newValue) {
        setBackgroundEnabledState(e.newValue === "true")
      }
    }
    window.addEventListener("storage", handleStorage)
    return () => window.removeEventListener("storage", handleStorage)
  }, [])

  // Register periodic background sync
  useEffect(() => {
    if (backgroundEnabled && "serviceWorker" in navigator) {
      navigator.serviceWorker.ready.then((reg) => {
        // Try to register periodic sync (Chrome)
        if ("periodicSync" in reg) {
          (reg as unknown as { periodicSync: { register: (tag: string, opts: { minInterval: number }) => Promise<void> } }).periodicSync
            .register("dommo-background-sync", { minInterval: 60000 })
            .catch(() => { /* not supported */ })
        }
        // Tell SW to start sync
        reg.active?.postMessage("START_SYNC")
      }).catch(() => { /* ignore */ })
    }
  }, [backgroundEnabled])

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l)
    localStorage.setItem(STORAGE_KEYS.locale, l)
  }, [])

  const setApiToken = useCallback((t: string) => {
    setApiTokenState(t)
    localStorage.setItem(STORAGE_KEYS.apiToken, t)
  }, [])

  const setActiveView = useCallback((v: string) => {
    setActiveViewState(v)
    localStorage.setItem(STORAGE_KEYS.lastView, v)
  }, [])

  const setGateConfig = useCallback((c: GateConfig) => {
    setGateConfigState(c)
    localStorage.setItem(STORAGE_KEYS.gateConfig, JSON.stringify(c))
  }, [])

  const setAiEngines = useCallback((e: AIEngine[]) => {
    setAiEnginesState(e)
    localStorage.setItem(STORAGE_KEYS.aiEngines, JSON.stringify(e))
  }, [])

  const setBackgroundEnabled = useCallback((v: boolean) => {
    setBackgroundEnabledState(v)
    localStorage.setItem(STORAGE_KEYS.backgroundEnabled, String(v))
  }, [])

  const setSyncedSuggestions = useCallback((s: SyncedSuggestion[]) => {
    setSyncedSuggestionsState(s)
    localStorage.setItem(STORAGE_KEYS.dailySuggestions, JSON.stringify(s))
  }, [])

  return (
    <AppContext.Provider
      value={{
        locale, setLocale,
        apiToken, setApiToken,
        isAuthenticated, setIsAuthenticated,
        activeView, setActiveView,
        sidebarOpen, setSidebarOpen,
        gateConfig, setGateConfig,
        aiEngines, setAiEngines,
        backgroundEnabled, setBackgroundEnabled,
        syncedSuggestions, setSyncedSuggestions,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error("useApp must be used within AppProvider")
  return ctx
}
