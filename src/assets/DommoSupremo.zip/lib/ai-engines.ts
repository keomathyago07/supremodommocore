export interface AIEngine {
  id: string
  name: string
  category: string
  description: string
  descriptionEn: string
  enabled: boolean
  weight: number
  specializedFor?: string[] // lottery IDs this engine specializes in
}

export const AI_ENGINE_CATEGORIES = {
  "statistical": { label: "Estatistico", labelEn: "Statistical", color: "hsl(180 100% 50%)" },
  "neural": { label: "Redes Neurais", labelEn: "Neural Networks", color: "hsl(280 60% 55%)" },
  "bayesian": { label: "Bayesiano", labelEn: "Bayesian", color: "hsl(45 100% 50%)" },
  "temporal": { label: "Temporal", labelEn: "Temporal", color: "hsl(142 71% 45%)" },
  "ensemble": { label: "Ensemble", labelEn: "Ensemble", color: "hsl(0 72% 51%)" },
  "genetic": { label: "Genetico", labelEn: "Genetic", color: "hsl(200 80% 55%)" },
  "quantum": { label: "Quantico", labelEn: "Quantum", color: "hsl(320 70% 55%)" },
  "reinforcement": { label: "Reforco", labelEn: "Reinforcement", color: "hsl(30 90% 50%)" },
  "megasena_specialist": { label: "Especialista Mega-Sena", labelEn: "Mega-Sena Specialist", color: "#209869" },
  "lotofacil_specialist": { label: "Especialista Lotofacil", labelEn: "Lotofacil Specialist", color: "#930089" },
  "quina_specialist": { label: "Especialista Quina", labelEn: "Quina Specialist", color: "#260085" },
  "lotomania_specialist": { label: "Especialista Lotomania", labelEn: "Lotomania Specialist", color: "#F78100" },
  "timemania_specialist": { label: "Especialista Timemania", labelEn: "Timemania Specialist", color: "#00FF48" },
  "duplasena_specialist": { label: "Especialista Dupla Sena", labelEn: "Dupla Sena Specialist", color: "#A61324" },
  "diadesorte_specialist": { label: "Especialista Dia de Sorte", labelEn: "Dia de Sorte Specialist", color: "#CB7917" },
  "supersete_specialist": { label: "Especialista Super Sete", labelEn: "Super Sete Specialist", color: "#A8CF45" },
  "maismilionaria_specialist": { label: "Especialista +Milionaria", labelEn: "+Milionaria Specialist", color: "#002B5C" },
  "meta_learning": { label: "Meta-Aprendizado", labelEn: "Meta-Learning", color: "hsl(260 80% 60%)" },
  "deep_analysis": { label: "Analise Profunda", labelEn: "Deep Analysis", color: "hsl(190 90% 45%)" },
} as const

export type AICategory = keyof typeof AI_ENGINE_CATEGORIES

export const DEFAULT_AI_ENGINES: AIEngine[] = [
  // === STATISTICAL (12) ===
  { id: "certus_v2", name: "CertusV2", category: "statistical", description: "Analise de certeza estatistica avancada", descriptionEn: "Advanced statistical certainty analysis", enabled: true, weight: 5 },
  { id: "freq_analyzer", name: "FreqAnalyzer", category: "statistical", description: "Analise de frequencia de numeros", descriptionEn: "Number frequency analysis", enabled: true, weight: 4 },
  { id: "chi_square", name: "ChiSquareNet", category: "statistical", description: "Teste qui-quadrado para distribuicao", descriptionEn: "Chi-square distribution test", enabled: true, weight: 4 },
  { id: "monte_carlo", name: "MonteCarloSim", category: "statistical", description: "Simulacao de Monte Carlo com 10M iteracoes", descriptionEn: "Monte Carlo simulation with 10M iterations", enabled: true, weight: 5 },
  { id: "poisson_net", name: "PoissonNet", category: "statistical", description: "Distribuicao de Poisson para eventos raros", descriptionEn: "Poisson distribution for rare events", enabled: true, weight: 3 },
  { id: "z_score", name: "ZScoreEngine", category: "statistical", description: "Deteccao de anomalias via Z-Score", descriptionEn: "Anomaly detection via Z-Score", enabled: true, weight: 3 },
  { id: "regression_pro", name: "RegressionPro", category: "statistical", description: "Regressao logistica multinomial", descriptionEn: "Multinomial logistic regression", enabled: true, weight: 4 },
  { id: "variance_tracker", name: "VarianceTracker", category: "statistical", description: "Rastreamento de variancia e desvio padrao", descriptionEn: "Variance and standard deviation tracking", enabled: true, weight: 3 },
  { id: "kolmogorov_smirnov", name: "KolmogorovTest", category: "statistical", description: "Teste KS para distribuicao empirica vs teorica", descriptionEn: "KS test for empirical vs theoretical distribution", enabled: true, weight: 4 },
  { id: "entropy_analyzer", name: "EntropyAnalyzer", category: "statistical", description: "Analise de entropia de Shannon nos sorteios", descriptionEn: "Shannon entropy analysis on draws", enabled: true, weight: 4 },
  { id: "correlation_matrix", name: "CorrMatrixPro", category: "statistical", description: "Matriz de correlacao cruzada entre numeros", descriptionEn: "Cross-correlation matrix between numbers", enabled: true, weight: 3 },
  { id: "permutation_test", name: "PermutationTest", category: "statistical", description: "Teste de permutacao para significancia", descriptionEn: "Permutation test for significance", enabled: true, weight: 3 },

  // === NEURAL NETWORKS (12) ===
  { id: "neural_freq", name: "NeuralFreq", category: "neural", description: "Rede neural de frequencia profunda", descriptionEn: "Deep frequency neural network", enabled: true, weight: 5 },
  { id: "deep_pattern", name: "DeepPatternX", category: "neural", description: "Reconhecimento de padroes profundos", descriptionEn: "Deep pattern recognition", enabled: true, weight: 5 },
  { id: "lstm_predict", name: "LSTMPredict", category: "neural", description: "LSTM para previsao de sequencias", descriptionEn: "LSTM for sequence prediction", enabled: true, weight: 5 },
  { id: "conv_lottery", name: "ConvLotteryNet", category: "neural", description: "CNN para analise de grade numerica", descriptionEn: "CNN for number grid analysis", enabled: true, weight: 4 },
  { id: "transformer_v3", name: "TransformerV3", category: "neural", description: "Transformer com atencao multi-cabeca", descriptionEn: "Multi-head attention transformer", enabled: true, weight: 5 },
  { id: "gru_temporal", name: "GRUTemporal", category: "neural", description: "GRU para dependencias temporais", descriptionEn: "GRU for temporal dependencies", enabled: true, weight: 4 },
  { id: "autoencoder", name: "AutoEncoder", category: "neural", description: "Autoencoder para reducao dimensional", descriptionEn: "Autoencoder for dimensional reduction", enabled: true, weight: 3 },
  { id: "attention_net", name: "AttentionNet", category: "neural", description: "Rede de atencao para correlacoes", descriptionEn: "Attention network for correlations", enabled: true, weight: 4 },
  { id: "resnet_lottery", name: "ResNetLottery", category: "neural", description: "ResNet adaptada para sequencias de sorteio", descriptionEn: "ResNet adapted for draw sequences", enabled: true, weight: 4 },
  { id: "capsule_net", name: "CapsuleNet", category: "neural", description: "Rede de capsulas para relacoes espaciais", descriptionEn: "Capsule network for spatial relations", enabled: true, weight: 4 },
  { id: "diffusion_model", name: "DiffusionModel", category: "neural", description: "Modelo de difusao para geracao de padroes", descriptionEn: "Diffusion model for pattern generation", enabled: true, weight: 5 },
  { id: "graph_neural", name: "GraphNeuralNet", category: "neural", description: "Rede neural em grafo para relacoes entre numeros", descriptionEn: "Graph neural network for number relations", enabled: true, weight: 4 },

  // === BAYESIAN (10) ===
  { id: "bayesian_net", name: "BayesianNet", category: "bayesian", description: "Redes Bayesianas para probabilidade condicional", descriptionEn: "Bayesian networks for conditional probability", enabled: true, weight: 5 },
  { id: "naive_bayes", name: "NaiveBayesPro", category: "bayesian", description: "Naive Bayes otimizado para loterias", descriptionEn: "Naive Bayes optimized for lotteries", enabled: true, weight: 4 },
  { id: "bayesian_opt", name: "BayesOptimizer", category: "bayesian", description: "Otimizacao Bayesiana de hiperparametros", descriptionEn: "Bayesian hyperparameter optimization", enabled: true, weight: 4 },
  { id: "mcmc_sampler", name: "MCMCSampler", category: "bayesian", description: "Monte Carlo via Cadeias de Markov", descriptionEn: "Markov Chain Monte Carlo sampling", enabled: true, weight: 4 },
  { id: "belief_prop", name: "BeliefPropNet", category: "bayesian", description: "Propagacao de crencas em grafos", descriptionEn: "Belief propagation in graphs", enabled: true, weight: 3 },
  { id: "dirichlet_mix", name: "DirichletMix", category: "bayesian", description: "Mistura de Dirichlet para distribuicoes", descriptionEn: "Dirichlet mixture for distributions", enabled: true, weight: 3 },
  { id: "posterior_engine", name: "PosteriorEngine", category: "bayesian", description: "Motor de inferencia posterior adaptativo", descriptionEn: "Adaptive posterior inference engine", enabled: true, weight: 4 },
  { id: "hierarchical_bayes", name: "HierarchicalBayes", category: "bayesian", description: "Modelo Bayesiano hierarquico multi-nivel", descriptionEn: "Multi-level hierarchical Bayesian model", enabled: true, weight: 4 },
  { id: "variational_inf", name: "VariationalInf", category: "bayesian", description: "Inferencia variacional aproximada", descriptionEn: "Approximate variational inference", enabled: true, weight: 4 },
  { id: "gaussian_process", name: "GaussianProcess", category: "bayesian", description: "Processo Gaussiano para regressao", descriptionEn: "Gaussian process for regression", enabled: true, weight: 4 },

  // === TEMPORAL (10) ===
  { id: "temporal_gan", name: "TemporalGAN", category: "temporal", description: "GAN temporal para geracao de padroes", descriptionEn: "Temporal GAN for pattern generation", enabled: true, weight: 5 },
  { id: "markov_chain", name: "MarkovChain", category: "temporal", description: "Cadeias de Markov de ordem superior", descriptionEn: "Higher-order Markov chains", enabled: true, weight: 5 },
  { id: "arima_forecast", name: "ARIMAForecast", category: "temporal", description: "ARIMA para previsao de series temporais", descriptionEn: "ARIMA for time series forecasting", enabled: true, weight: 4 },
  { id: "wavelet_analysis", name: "WaveletAnalysis", category: "temporal", description: "Analise wavelet de periodicidade", descriptionEn: "Wavelet periodicity analysis", enabled: true, weight: 3 },
  { id: "seasonal_decomp", name: "SeasonalDecomp", category: "temporal", description: "Decomposicao sazonal STL", descriptionEn: "STL seasonal decomposition", enabled: true, weight: 3 },
  { id: "exponential_smooth", name: "ExpSmoothing", category: "temporal", description: "Suavizacao exponencial tripla", descriptionEn: "Triple exponential smoothing", enabled: true, weight: 3 },
  { id: "changepoint", name: "ChangePointAI", category: "temporal", description: "Deteccao de pontos de mudanca", descriptionEn: "Change point detection", enabled: true, weight: 4 },
  { id: "prophet_ts", name: "ProphetTS", category: "temporal", description: "Previsao de series temporais com Prophet", descriptionEn: "Time series forecasting with Prophet", enabled: true, weight: 4 },
  { id: "spectral_analysis", name: "SpectralAnalysis", category: "temporal", description: "Analise espectral de frequencias ciclicas", descriptionEn: "Spectral analysis of cyclic frequencies", enabled: true, weight: 3 },
  { id: "hidden_markov", name: "HiddenMarkov", category: "temporal", description: "Modelo oculto de Markov para estados latentes", descriptionEn: "Hidden Markov model for latent states", enabled: true, weight: 4 },

  // === ENSEMBLE (8) ===
  { id: "random_forest", name: "RandomForestPro", category: "ensemble", description: "Random Forest com 5000 arvores", descriptionEn: "Random Forest with 5000 trees", enabled: true, weight: 5 },
  { id: "xgboost_lottery", name: "XGBoostLottery", category: "ensemble", description: "XGBoost otimizado para loterias", descriptionEn: "XGBoost optimized for lotteries", enabled: true, weight: 5 },
  { id: "gradient_boost", name: "GradientBoostV2", category: "ensemble", description: "Gradient Boosting de segunda geracao", descriptionEn: "Second generation gradient boosting", enabled: true, weight: 4 },
  { id: "ada_boost", name: "AdaBoostNet", category: "ensemble", description: "AdaBoost adaptativo com peso dinamico", descriptionEn: "Adaptive AdaBoost with dynamic weighting", enabled: true, weight: 4 },
  { id: "stacking_meta", name: "StackingMeta", category: "ensemble", description: "Meta-aprendizado por empilhamento", descriptionEn: "Stacking meta-learning", enabled: true, weight: 5 },
  { id: "voting_ensemble", name: "VotingEnsemble", category: "ensemble", description: "Ensemble por votacao ponderada", descriptionEn: "Weighted voting ensemble", enabled: true, weight: 4 },
  { id: "catboost_pro", name: "CatBoostPro", category: "ensemble", description: "CatBoost para features categoricas", descriptionEn: "CatBoost for categorical features", enabled: true, weight: 4 },
  { id: "lightgbm_fast", name: "LightGBMFast", category: "ensemble", description: "LightGBM de alta velocidade", descriptionEn: "High-speed LightGBM", enabled: true, weight: 4 },

  // === GENETIC (7) ===
  { id: "genetic_opt", name: "GeneticOptimizer", category: "genetic", description: "Otimizacao por algoritmo genetico", descriptionEn: "Genetic algorithm optimization", enabled: true, weight: 4 },
  { id: "evolution_strategy", name: "EvolutionStrategy", category: "genetic", description: "Estrategia evolutiva CMA-ES", descriptionEn: "CMA-ES evolution strategy", enabled: true, weight: 4 },
  { id: "differential_evo", name: "DiffEvolution", category: "genetic", description: "Evolucao diferencial para otimizacao", descriptionEn: "Differential evolution for optimization", enabled: true, weight: 3 },
  { id: "swarm_intel", name: "SwarmIntel", category: "genetic", description: "Inteligencia de enxame PSO", descriptionEn: "PSO swarm intelligence", enabled: true, weight: 3 },
  { id: "ant_colony", name: "AntColonyOpt", category: "genetic", description: "Otimizacao por colonia de formigas", descriptionEn: "Ant colony optimization", enabled: true, weight: 3 },
  { id: "bee_algorithm", name: "BeeAlgorithm", category: "genetic", description: "Algoritmo de abelhas para busca otima", descriptionEn: "Bee algorithm for optimal search", enabled: true, weight: 3 },
  { id: "firefly_algo", name: "FireflyAlgo", category: "genetic", description: "Algoritmo do vaga-lume para convergencia", descriptionEn: "Firefly algorithm for convergence", enabled: true, weight: 3 },

  // === QUANTUM-INSPIRED (7) ===
  { id: "quantum_walk", name: "QuantumWalk", category: "quantum", description: "Caminhada quantica em grafos", descriptionEn: "Quantum walk on graphs", enabled: true, weight: 4 },
  { id: "quantum_annealing", name: "QAnnealing", category: "quantum", description: "Recozimento quantico simulado", descriptionEn: "Simulated quantum annealing", enabled: true, weight: 4 },
  { id: "superposition_net", name: "SuperposNet", category: "quantum", description: "Rede de superposicao probabilistica", descriptionEn: "Probabilistic superposition network", enabled: true, weight: 3 },
  { id: "entangle_predict", name: "EntanglePredict", category: "quantum", description: "Predicao por entrelaçamento de dados", descriptionEn: "Data entanglement prediction", enabled: true, weight: 3 },
  { id: "quantum_bayes", name: "QuantumBayes", category: "quantum", description: "Inferencia Bayesiana quantica", descriptionEn: "Quantum Bayesian inference", enabled: true, weight: 4 },
  { id: "grover_search", name: "GroverSearch", category: "quantum", description: "Busca de Grover para otimizacao combinatoria", descriptionEn: "Grover search for combinatorial optimization", enabled: true, weight: 4 },
  { id: "quantum_reservoir", name: "QReservoir", category: "quantum", description: "Computacao de reservatorio quantico", descriptionEn: "Quantum reservoir computing", enabled: true, weight: 3 },

  // === REINFORCEMENT LEARNING (6) ===
  { id: "dqn_lottery", name: "DQNLottery", category: "reinforcement", description: "Deep Q-Network para decisao de apostas", descriptionEn: "Deep Q-Network for bet decisions", enabled: true, weight: 4 },
  { id: "ppo_agent", name: "PPOAgent", category: "reinforcement", description: "Proximal Policy Optimization", descriptionEn: "Proximal Policy Optimization", enabled: true, weight: 4 },
  { id: "a3c_predictor", name: "A3CPredictor", category: "reinforcement", description: "A3C assincrono para multi-loteria", descriptionEn: "Asynchronous A3C for multi-lottery", enabled: true, weight: 3 },
  { id: "mab_selector", name: "MABSelector", category: "reinforcement", description: "Multi-Armed Bandit para selecao", descriptionEn: "Multi-Armed Bandit for selection", enabled: true, weight: 3 },
  { id: "sac_optimizer", name: "SACOptimizer", category: "reinforcement", description: "Soft Actor-Critic para otimizacao continua", descriptionEn: "Soft Actor-Critic for continuous optimization", enabled: true, weight: 4 },
  { id: "td3_agent", name: "TD3Agent", category: "reinforcement", description: "Twin Delayed DDPG para estabilidade", descriptionEn: "Twin Delayed DDPG for stability", enabled: true, weight: 3 },

  // === MEGA-SENA SPECIALISTS (8) ===
  { id: "mega_freq_master", name: "MegaFreqMaster", category: "megasena_specialist", description: "Analise de frequencia exclusiva Mega-Sena 60 numeros", descriptionEn: "Exclusive Mega-Sena 60-number frequency analysis", enabled: true, weight: 5, specializedFor: ["megasena"] },
  { id: "mega_gap_hunter", name: "MegaGapHunter", category: "megasena_specialist", description: "Cacador de lacunas nos 60 numeros da Mega", descriptionEn: "Gap hunter in Mega's 60 numbers", enabled: true, weight: 5, specializedFor: ["megasena"] },
  { id: "mega_pair_analyzer", name: "MegaPairAnalyzer", category: "megasena_specialist", description: "Analise de pares e trios recorrentes Mega-Sena", descriptionEn: "Recurring pairs and trios analysis for Mega-Sena", enabled: true, weight: 4, specializedFor: ["megasena"] },
  { id: "mega_decade_dist", name: "MegaDecadeDist", category: "megasena_specialist", description: "Distribuicao por dezenas (01-10, 11-20, etc.)", descriptionEn: "Distribution by decades (01-10, 11-20, etc.)", enabled: true, weight: 4, specializedFor: ["megasena"] },
  { id: "mega_sum_predictor", name: "MegaSumPredictor", category: "megasena_specialist", description: "Predicao por soma total dos 6 numeros", descriptionEn: "Prediction by total sum of 6 numbers", enabled: true, weight: 4, specializedFor: ["megasena"] },
  { id: "mega_even_odd", name: "MegaEvenOddAI", category: "megasena_specialist", description: "Equilibrio par/impar otimizado para Mega", descriptionEn: "Even/odd balance optimized for Mega", enabled: true, weight: 3, specializedFor: ["megasena"] },
  { id: "mega_consecutive", name: "MegaConsecutiveAI", category: "megasena_specialist", description: "Analise de numeros consecutivos Mega-Sena", descriptionEn: "Consecutive numbers analysis for Mega-Sena", enabled: true, weight: 3, specializedFor: ["megasena"] },
  { id: "mega_neural_deep", name: "MegaNeuralDeep", category: "megasena_specialist", description: "Rede neural profunda treinada em 2700+ concursos Mega", descriptionEn: "Deep neural network trained on 2700+ Mega contests", enabled: true, weight: 5, specializedFor: ["megasena"] },

  // === LOTOFACIL SPECIALISTS (8) ===
  { id: "lf_pattern_master", name: "LFPatternMaster", category: "lotofacil_specialist", description: "Reconhecimento de padroes nos 25 numeros Lotofacil", descriptionEn: "Pattern recognition in Lotofacil's 25 numbers", enabled: true, weight: 5, specializedFor: ["lotofacil"] },
  { id: "lf_coverage_opt", name: "LFCoverageOpt", category: "lotofacil_specialist", description: "Otimizacao de cobertura 15/25 numeros", descriptionEn: "15/25 number coverage optimization", enabled: true, weight: 5, specializedFor: ["lotofacil"] },
  { id: "lf_row_analyzer", name: "LFRowAnalyzer", category: "lotofacil_specialist", description: "Analise de linhas e colunas da cartela 5x5", descriptionEn: "5x5 grid row and column analysis", enabled: true, weight: 4, specializedFor: ["lotofacil"] },
  { id: "lf_repeat_tracker", name: "LFRepeatTracker", category: "lotofacil_specialist", description: "Rastreador de numeros repetidos entre concursos", descriptionEn: "Repeat number tracker between contests", enabled: true, weight: 4, specializedFor: ["lotofacil"] },
  { id: "lf_prime_balance", name: "LFPrimeBalance", category: "lotofacil_specialist", description: "Equilibrio de numeros primos na Lotofacil", descriptionEn: "Prime number balance in Lotofacil", enabled: true, weight: 3, specializedFor: ["lotofacil"] },
  { id: "lf_fibonacci_net", name: "LFFibonacciNet", category: "lotofacil_specialist", description: "Rede baseada em sequencias de Fibonacci", descriptionEn: "Fibonacci sequence-based network", enabled: true, weight: 3, specializedFor: ["lotofacil"] },
  { id: "lf_quadrant_ai", name: "LFQuadrantAI", category: "lotofacil_specialist", description: "Analise por quadrantes do volante Lotofacil", descriptionEn: "Quadrant analysis of Lotofacil card", enabled: true, weight: 4, specializedFor: ["lotofacil"] },
  { id: "lf_neural_15", name: "LFNeural15", category: "lotofacil_specialist", description: "Rede neural especializada em selecionar 15 numeros", descriptionEn: "Neural network specialized in selecting 15 numbers", enabled: true, weight: 5, specializedFor: ["lotofacil"] },

  // === QUINA SPECIALISTS (6) ===
  { id: "quina_freq_pro", name: "QuinaFreqPro", category: "quina_specialist", description: "Analise de frequencia avancada 1-80 Quina", descriptionEn: "Advanced 1-80 frequency analysis for Quina", enabled: true, weight: 5, specializedFor: ["quina"] },
  { id: "quina_zone_map", name: "QuinaZoneMap", category: "quina_specialist", description: "Mapeamento de zonas quentes/frias 1-80", descriptionEn: "Hot/cold zone mapping 1-80", enabled: true, weight: 4, specializedFor: ["quina"] },
  { id: "quina_5pick_opt", name: "Quina5PickOpt", category: "quina_specialist", description: "Otimizador de selecao de 5 numeros em 80", descriptionEn: "5-number selection optimizer from 80", enabled: true, weight: 5, specializedFor: ["quina"] },
  { id: "quina_gap_cycle", name: "QuinaGapCycle", category: "quina_specialist", description: "Ciclos de lacuna e retorno dos numeros", descriptionEn: "Gap and return cycles of numbers", enabled: true, weight: 4, specializedFor: ["quina"] },
  { id: "quina_cluster_ai", name: "QuinaClusterAI", category: "quina_specialist", description: "Agrupamento por clusters de numeros sorteados", descriptionEn: "Clustering by groups of drawn numbers", enabled: true, weight: 4, specializedFor: ["quina"] },
  { id: "quina_neural_5", name: "QuinaNeural5", category: "quina_specialist", description: "Rede neural treinada exclusivamente em Quina", descriptionEn: "Neural network trained exclusively on Quina", enabled: true, weight: 5, specializedFor: ["quina"] },

  // === LOTOMANIA SPECIALISTS (6) ===
  { id: "lm_50pick_master", name: "LM50PickMaster", category: "lotomania_specialist", description: "Mestre em selecao de 50 numeros de 100", descriptionEn: "Master in selecting 50 from 100 numbers", enabled: true, weight: 5, specializedFor: ["lotomania"] },
  { id: "lm_zero_hunter", name: "LMZeroHunter", category: "lotomania_specialist", description: "Detector de jogos com 0 acertos (premio especial)", descriptionEn: "Detector for 0-hit games (special prize)", enabled: true, weight: 4, specializedFor: ["lotomania"] },
  { id: "lm_half_split", name: "LMHalfSplit", category: "lotomania_specialist", description: "Divisao otimizada 50/50 do universo 1-100", descriptionEn: "Optimized 50/50 split of 1-100 universe", enabled: true, weight: 4, specializedFor: ["lotomania"] },
  { id: "lm_block_analyzer", name: "LMBlockAnalyzer", category: "lotomania_specialist", description: "Analise por blocos de 10 numeros", descriptionEn: "Analysis by 10-number blocks", enabled: true, weight: 4, specializedFor: ["lotomania"] },
  { id: "lm_exclusion_net", name: "LMExclusionNet", category: "lotomania_specialist", description: "Rede de exclusao inteligente (quais NAO jogar)", descriptionEn: "Intelligent exclusion network (which NOT to play)", enabled: true, weight: 4, specializedFor: ["lotomania"] },
  { id: "lm_neural_50", name: "LMNeural50", category: "lotomania_specialist", description: "Rede neural profunda para selecao de 50 numeros", descriptionEn: "Deep neural network for 50-number selection", enabled: true, weight: 5, specializedFor: ["lotomania"] },

  // === TIMEMANIA SPECIALISTS (6) ===
  { id: "tm_10pick_pro", name: "TM10PickPro", category: "timemania_specialist", description: "Especialista em selecao de 10 numeros de 80", descriptionEn: "10-number selection specialist from 80", enabled: true, weight: 5, specializedFor: ["timemania"] },
  { id: "tm_team_predictor", name: "TMTeamPredictor", category: "timemania_specialist", description: "Predicao do time do coracao via padroes", descriptionEn: "Heart team prediction via patterns", enabled: true, weight: 4, specializedFor: ["timemania"] },
  { id: "tm_distribution", name: "TMDistribution", category: "timemania_specialist", description: "Distribuicao otimizada em 80 numeros", descriptionEn: "Optimized distribution across 80 numbers", enabled: true, weight: 4, specializedFor: ["timemania"] },
  { id: "tm_cluster_10", name: "TMCluster10", category: "timemania_specialist", description: "Agrupamento de 10 numeros por afinidade", descriptionEn: "10-number clustering by affinity", enabled: true, weight: 4, specializedFor: ["timemania"] },
  { id: "tm_streak_ai", name: "TMStreakAI", category: "timemania_specialist", description: "IA de sequencias e raias na Timemania", descriptionEn: "Streak and sequence AI for Timemania", enabled: true, weight: 3, specializedFor: ["timemania"] },
  { id: "tm_neural_10", name: "TMNeural10", category: "timemania_specialist", description: "Rede neural treinada em Timemania", descriptionEn: "Neural network trained on Timemania", enabled: true, weight: 5, specializedFor: ["timemania"] },

  // === DUPLA SENA SPECIALISTS (6) ===
  { id: "ds_dual_engine", name: "DSDualEngine", category: "duplasena_specialist", description: "Motor duplo para ambos sorteios simultaneos", descriptionEn: "Dual engine for both simultaneous draws", enabled: true, weight: 5, specializedFor: ["duplasena"] },
  { id: "ds_cross_analyzer", name: "DSCrossAnalyzer", category: "duplasena_specialist", description: "Analise cruzada entre 1o e 2o sorteio", descriptionEn: "Cross-analysis between 1st and 2nd draw", enabled: true, weight: 4, specializedFor: ["duplasena"] },
  { id: "ds_50range_opt", name: "DS50RangeOpt", category: "duplasena_specialist", description: "Otimizacao no range 1-50 para 6 numeros", descriptionEn: "1-50 range optimization for 6 numbers", enabled: true, weight: 4, specializedFor: ["duplasena"] },
  { id: "ds_mirror_net", name: "DSMirrorNet", category: "duplasena_specialist", description: "Rede espelho entre sorteios 1 e 2", descriptionEn: "Mirror network between draws 1 and 2", enabled: true, weight: 4, specializedFor: ["duplasena"] },
  { id: "ds_correlation", name: "DSCorrelation", category: "duplasena_specialist", description: "Correlacao estatistica entre duplo sorteio", descriptionEn: "Statistical correlation between double draw", enabled: true, weight: 3, specializedFor: ["duplasena"] },
  { id: "ds_neural_dual", name: "DSNeuralDual", category: "duplasena_specialist", description: "Rede neural dual treinada em Dupla Sena", descriptionEn: "Dual neural network trained on Dupla Sena", enabled: true, weight: 5, specializedFor: ["duplasena"] },

  // === DIA DE SORTE SPECIALISTS (6) ===
  { id: "dd_31range_pro", name: "DD31RangePro", category: "diadesorte_specialist", description: "Especialista no range compacto 1-31", descriptionEn: "Specialist in compact 1-31 range", enabled: true, weight: 5, specializedFor: ["diadesorte"] },
  { id: "dd_month_oracle", name: "DDMonthOracle", category: "diadesorte_specialist", description: "Oraculo de previsao do Mes da Sorte", descriptionEn: "Lucky Month prediction oracle", enabled: true, weight: 4, specializedFor: ["diadesorte"] },
  { id: "dd_calendar_net", name: "DDCalendarNet", category: "diadesorte_specialist", description: "Rede baseada em padroes de calendario", descriptionEn: "Calendar pattern-based network", enabled: true, weight: 4, specializedFor: ["diadesorte"] },
  { id: "dd_7pick_master", name: "DD7PickMaster", category: "diadesorte_specialist", description: "Mestre em selecao de 7 numeros de 31", descriptionEn: "Master in selecting 7 from 31 numbers", enabled: true, weight: 5, specializedFor: ["diadesorte"] },
  { id: "dd_day_pattern", name: "DDDayPattern", category: "diadesorte_specialist", description: "Padroes baseados em dias do mes", descriptionEn: "Day-of-month based patterns", enabled: true, weight: 3, specializedFor: ["diadesorte"] },
  { id: "dd_neural_7", name: "DDNeural7", category: "diadesorte_specialist", description: "Rede neural treinada em Dia de Sorte", descriptionEn: "Neural network trained on Dia de Sorte", enabled: true, weight: 5, specializedFor: ["diadesorte"] },

  // === SUPER SETE SPECIALISTS (6) ===
  { id: "ss_column_master", name: "SSColumnMaster", category: "supersete_specialist", description: "Mestre em otimizacao de 7 colunas 0-9", descriptionEn: "Master in 7-column 0-9 optimization", enabled: true, weight: 5, specializedFor: ["supersete"] },
  { id: "ss_digit_freq", name: "SSDigitFreq", category: "supersete_specialist", description: "Frequencia de digitos por coluna individual", descriptionEn: "Per-column digit frequency", enabled: true, weight: 4, specializedFor: ["supersete"] },
  { id: "ss_cross_column", name: "SSCrossColumn", category: "supersete_specialist", description: "Correlacao cruzada entre as 7 colunas", descriptionEn: "Cross-correlation between 7 columns", enabled: true, weight: 4, specializedFor: ["supersete"] },
  { id: "ss_sum_optimizer", name: "SSSumOptimizer", category: "supersete_specialist", description: "Otimizador de soma total das 7 colunas", descriptionEn: "Total sum optimizer for 7 columns", enabled: true, weight: 3, specializedFor: ["supersete"] },
  { id: "ss_sequence_ai", name: "SSSequenceAI", category: "supersete_specialist", description: "IA de sequencias ascendentes/descendentes", descriptionEn: "Ascending/descending sequence AI", enabled: true, weight: 3, specializedFor: ["supersete"] },
  { id: "ss_neural_col", name: "SSNeuralCol", category: "supersete_specialist", description: "Rede neural por coluna para Super Sete", descriptionEn: "Per-column neural network for Super Sete", enabled: true, weight: 5, specializedFor: ["supersete"] },

  // === +MILIONARIA SPECIALISTS (6) ===
  { id: "mm_6plus2_engine", name: "MM6Plus2Engine", category: "maismilionaria_specialist", description: "Motor especializado 6 numeros + 2 trevos", descriptionEn: "Specialized 6 numbers + 2 clovers engine", enabled: true, weight: 5, specializedFor: ["maismilionaria"] },
  { id: "mm_clover_predictor", name: "MMCloverPredictor", category: "maismilionaria_specialist", description: "Predicao avancada dos 2 trevos de 1 a 6", descriptionEn: "Advanced prediction of 2 clovers from 1-6", enabled: true, weight: 5, specializedFor: ["maismilionaria"] },
  { id: "mm_50range_deep", name: "MM50RangeDeep", category: "maismilionaria_specialist", description: "Analise profunda do range 1-50", descriptionEn: "Deep analysis of 1-50 range", enabled: true, weight: 4, specializedFor: ["maismilionaria"] },
  { id: "mm_combined_score", name: "MMCombinedScore", category: "maismilionaria_specialist", description: "Score combinado numeros + trevos", descriptionEn: "Combined score numbers + clovers", enabled: true, weight: 4, specializedFor: ["maismilionaria"] },
  { id: "mm_premium_net", name: "MMPremiumNet", category: "maismilionaria_specialist", description: "Rede premium para premio maximo (6+2)", descriptionEn: "Premium network for maximum prize (6+2)", enabled: true, weight: 5, specializedFor: ["maismilionaria"] },
  { id: "mm_neural_clover", name: "MMNeuralClover", category: "maismilionaria_specialist", description: "Rede neural para trevos e numeros integrados", descriptionEn: "Neural network for integrated clovers and numbers", enabled: true, weight: 5, specializedFor: ["maismilionaria"] },

  // === META-LEARNING (8) ===
  { id: "meta_model_selector", name: "MetaModelSelector", category: "meta_learning", description: "Seleciona o melhor modelo por loteria automaticamente", descriptionEn: "Automatically selects best model per lottery", enabled: true, weight: 5 },
  { id: "meta_weight_tuner", name: "MetaWeightTuner", category: "meta_learning", description: "Auto-ajuste de pesos de todos os modelos", descriptionEn: "Auto-tuning weights of all models", enabled: true, weight: 5 },
  { id: "meta_consensus", name: "MetaConsensus", category: "meta_learning", description: "Consenso multi-modelo com votacao ponderada", descriptionEn: "Multi-model consensus with weighted voting", enabled: true, weight: 5 },
  { id: "meta_transfer", name: "MetaTransferAI", category: "meta_learning", description: "Transferencia de aprendizado entre loterias", descriptionEn: "Transfer learning between lotteries", enabled: true, weight: 4 },
  { id: "meta_auto_retrain", name: "MetaAutoRetrain", category: "meta_learning", description: "Re-treino automatico apos cada sorteio", descriptionEn: "Automatic retraining after each draw", enabled: true, weight: 5 },
  { id: "meta_performance", name: "MetaPerformance", category: "meta_learning", description: "Monitor de performance de todos os modelos", descriptionEn: "Performance monitor for all models", enabled: true, weight: 4 },
  { id: "meta_evolution", name: "MetaEvolution", category: "meta_learning", description: "Evolucao continua - nunca retrocede", descriptionEn: "Continuous evolution - never regresses", enabled: true, weight: 5 },
  { id: "meta_gate_optimizer", name: "MetaGateOpt", category: "meta_learning", description: "Otimizador adaptativo do gate de confianca", descriptionEn: "Adaptive confidence gate optimizer", enabled: true, weight: 5 },

  // === DEEP ANALYSIS (8) ===
  { id: "deep_cross_lottery", name: "DeepCrossLottery", category: "deep_analysis", description: "Analise cruzada entre todas as 9 loterias", descriptionEn: "Cross-analysis between all 9 lotteries", enabled: true, weight: 5 },
  { id: "deep_historical", name: "DeepHistorical", category: "deep_analysis", description: "Analise historica profunda de todos os concursos", descriptionEn: "Deep historical analysis of all contests", enabled: true, weight: 5 },
  { id: "deep_anomaly", name: "DeepAnomalyNet", category: "deep_analysis", description: "Deteccao de anomalias em larga escala", descriptionEn: "Large-scale anomaly detection", enabled: true, weight: 4 },
  { id: "deep_similarity", name: "DeepSimilarity", category: "deep_analysis", description: "Busca de concursos similares no historico", descriptionEn: "Similar contest search in history", enabled: true, weight: 4 },
  { id: "deep_prediction_fusion", name: "PredictionFusion", category: "deep_analysis", description: "Fusao de predicoes de todos os modelos", descriptionEn: "Fusion of predictions from all models", enabled: true, weight: 5 },
  { id: "deep_confidence_calibrator", name: "ConfCalibrator", category: "deep_analysis", description: "Calibracao precisa do indice de confianca", descriptionEn: "Precise confidence index calibration", enabled: true, weight: 5 },
  { id: "deep_pattern_discovery", name: "PatternDiscovery", category: "deep_analysis", description: "Descoberta automatica de novos padroes ocultos", descriptionEn: "Automatic discovery of new hidden patterns", enabled: true, weight: 4 },
  { id: "deep_sentinel", name: "DeepSentinel", category: "deep_analysis", description: "Sentinela de qualidade final antes do APPROVED", descriptionEn: "Final quality sentinel before APPROVED", enabled: true, weight: 5 },
]

export function getEnabledEngineNames(engines: AIEngine[]): string[] {
  return engines.filter(e => e.enabled).map(e => e.name)
}

export function getSpecializedEngines(engines: AIEngine[], lotteryId: string): AIEngine[] {
  return engines.filter(e => e.enabled && e.specializedFor?.includes(lotteryId))
}

export function pickRandomEngine(engines: AIEngine[]): string {
  const enabled = engines.filter(e => e.enabled)
  if (enabled.length === 0) return "CertusV2"
  const totalWeight = enabled.reduce((sum, e) => sum + e.weight, 0)
  let random = Math.random() * totalWeight
  for (const engine of enabled) {
    random -= engine.weight
    if (random <= 0) return engine.name
  }
  return enabled[0].name
}

export function pickSpecializedEngine(engines: AIEngine[], lotteryId: string): string {
  const specialized = getSpecializedEngines(engines, lotteryId)
  if (specialized.length > 0) {
    const totalWeight = specialized.reduce((sum, e) => sum + e.weight, 0)
    let random = Math.random() * totalWeight
    for (const engine of specialized) {
      random -= engine.weight
      if (random <= 0) return engine.name
    }
    return specialized[0].name
  }
  return pickRandomEngine(engines)
}

export interface GateConfig {
  defaultThreshold: number
  lotteryThresholds: Record<string, number>
  autoEscalate: boolean
  neverRegress: boolean
  adaptiveMode: boolean
}

export const DEFAULT_GATE_CONFIG: GateConfig = {
  defaultThreshold: 0.999,
  lotteryThresholds: {},
  autoEscalate: true,
  neverRegress: true,
  adaptiveMode: true,
}

export function getGateThreshold(config: GateConfig, lotteryId: string): number {
  return config.lotteryThresholds[lotteryId] ?? config.defaultThreshold
}
