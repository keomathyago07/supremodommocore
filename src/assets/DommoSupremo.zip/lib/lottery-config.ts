export interface LotteryConfig {
  id: string
  canonicalId: string
  displayName: string
  color: string
  minNumbers: number
  maxNumbers: number
  pickCount: number
  extraField?: string
  extraOptions?: string[] | number[]
  extraPickCount?: number
  columns?: number
  drawDays: number[] // 0=Sun,1=Mon,2=Tue,3=Wed,4=Thu,5=Fri,6=Sat
  drawDayNames: { "pt-BR": string; en: string }
  prizeRanges: { hits: number; label: string; labelEn: string }[]
}

export const LOTTERIES: LotteryConfig[] = [
  {
    id: "megasena",
    canonicalId: "megasena",
    displayName: "Mega-Sena",
    color: "#209869",
    minNumbers: 1,
    maxNumbers: 60,
    pickCount: 6,
    drawDays: [2, 4, 6], // Tue, Thu, Sat
    drawDayNames: { "pt-BR": "Tercas, quintas e sabados", en: "Tuesdays, Thursdays and Saturdays" },
    prizeRanges: [
      { hits: 6, label: "Sena (6 acertos)", labelEn: "Sena (6 hits)" },
      { hits: 5, label: "Quina (5 acertos)", labelEn: "Quina (5 hits)" },
      { hits: 4, label: "Quadra (4 acertos)", labelEn: "Quadra (4 hits)" },
    ],
  },
  {
    id: "lotofacil",
    canonicalId: "lotofacil",
    displayName: "Lotofacil",
    color: "#930089",
    minNumbers: 1,
    maxNumbers: 25,
    pickCount: 15,
    drawDays: [1, 2, 3, 4, 5, 6], // Mon-Sat
    drawDayNames: { "pt-BR": "Segundas a sabados", en: "Monday to Saturday" },
    prizeRanges: [
      { hits: 15, label: "15 acertos", labelEn: "15 hits" },
      { hits: 14, label: "14 acertos", labelEn: "14 hits" },
      { hits: 13, label: "13 acertos", labelEn: "13 hits" },
      { hits: 12, label: "12 acertos", labelEn: "12 hits" },
      { hits: 11, label: "11 acertos", labelEn: "11 hits" },
    ],
  },
  {
    id: "quina",
    canonicalId: "quina",
    displayName: "Quina",
    color: "#260085",
    minNumbers: 1,
    maxNumbers: 80,
    pickCount: 5,
    drawDays: [1, 2, 3, 4, 5, 6], // Mon-Sat
    drawDayNames: { "pt-BR": "Segundas a sabados", en: "Monday to Saturday" },
    prizeRanges: [
      { hits: 5, label: "Quina (5 acertos)", labelEn: "Quina (5 hits)" },
      { hits: 4, label: "Quadra (4 acertos)", labelEn: "Quadra (4 hits)" },
      { hits: 3, label: "Terno (3 acertos)", labelEn: "Terno (3 hits)" },
      { hits: 2, label: "Duque (2 acertos)", labelEn: "Duque (2 hits)" },
    ],
  },
  {
    id: "lotomania",
    canonicalId: "lotomania",
    displayName: "Lotomania",
    color: "#F78100",
    minNumbers: 1,
    maxNumbers: 100,
    pickCount: 50,
    drawDays: [1, 3, 5], // Mon, Wed, Fri
    drawDayNames: { "pt-BR": "Segundas, quartas e sextas", en: "Mondays, Wednesdays and Fridays" },
    prizeRanges: [
      { hits: 20, label: "20 acertos", labelEn: "20 hits" },
      { hits: 19, label: "19 acertos", labelEn: "19 hits" },
      { hits: 18, label: "18 acertos", labelEn: "18 hits" },
      { hits: 17, label: "17 acertos", labelEn: "17 hits" },
      { hits: 16, label: "16 acertos", labelEn: "16 hits" },
      { hits: 15, label: "15 acertos", labelEn: "15 hits" },
      { hits: 0, label: "0 acertos", labelEn: "0 hits" },
    ],
  },
  {
    id: "timemania",
    canonicalId: "timemania",
    displayName: "Timemania",
    color: "#00FF48",
    minNumbers: 1,
    maxNumbers: 80,
    pickCount: 10,
    extraField: "time_coracao",
    drawDays: [2, 4, 6], // Tue, Thu, Sat
    drawDayNames: { "pt-BR": "Tercas, quintas e sabados", en: "Tuesdays, Thursdays and Saturdays" },
    prizeRanges: [
      { hits: 7, label: "7 acertos", labelEn: "7 hits" },
      { hits: 6, label: "6 acertos", labelEn: "6 hits" },
      { hits: 5, label: "5 acertos", labelEn: "5 hits" },
      { hits: 4, label: "4 acertos", labelEn: "4 hits" },
      { hits: 3, label: "3 acertos", labelEn: "3 hits" },
    ],
  },
  {
    id: "duplasena",
    canonicalId: "duplasena",
    displayName: "Dupla Sena",
    color: "#A61324",
    minNumbers: 1,
    maxNumbers: 50,
    pickCount: 6,
    drawDays: [1, 3, 5], // Mon, Wed, Fri
    drawDayNames: { "pt-BR": "Segundas, quartas e sextas", en: "Mondays, Wednesdays and Fridays" },
    prizeRanges: [
      { hits: 6, label: "1o Sorteio - Sena (6 acertos)", labelEn: "1st Draw - Sena (6 hits)" },
      { hits: 5, label: "1o Sorteio - Quina (5 acertos)", labelEn: "1st Draw - Quina (5 hits)" },
      { hits: 6, label: "2o Sorteio - Sena (6 acertos)", labelEn: "2nd Draw - Sena (6 hits)" },
      { hits: 5, label: "2o Sorteio - Quina (5 acertos)", labelEn: "2nd Draw - Quina (5 hits)" },
    ],
  },
  {
    id: "diadesorte",
    canonicalId: "diadesorte",
    displayName: "Dia de Sorte",
    color: "#CB7917",
    minNumbers: 1,
    maxNumbers: 31,
    pickCount: 7,
    extraField: "mes_sorte",
    extraOptions: [
      "Janeiro", "Fevereiro", "Marco", "Abril", "Maio", "Junho",
      "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro",
    ],
    drawDays: [2, 4, 6], // Tue, Thu, Sat
    drawDayNames: { "pt-BR": "Tercas, quintas e sabados", en: "Tuesdays, Thursdays and Saturdays" },
    prizeRanges: [
      { hits: 7, label: "7 acertos", labelEn: "7 hits" },
      { hits: 6, label: "6 acertos", labelEn: "6 hits" },
      { hits: 5, label: "5 acertos", labelEn: "5 hits" },
      { hits: 4, label: "4 acertos", labelEn: "4 hits" },
    ],
  },
  {
    id: "supersete",
    canonicalId: "supersete",
    displayName: "Super Sete",
    color: "#A8CF45",
    minNumbers: 0,
    maxNumbers: 9,
    pickCount: 7,
    columns: 7,
    drawDays: [1, 3, 5], // Mon, Wed, Fri
    drawDayNames: { "pt-BR": "Segundas, quartas e sextas", en: "Mondays, Wednesdays and Fridays" },
    prizeRanges: [
      { hits: 7, label: "7 acertos", labelEn: "7 hits" },
      { hits: 6, label: "6 acertos", labelEn: "6 hits" },
      { hits: 5, label: "5 acertos", labelEn: "5 hits" },
      { hits: 4, label: "4 acertos", labelEn: "4 hits" },
      { hits: 3, label: "3 acertos", labelEn: "3 hits" },
    ],
  },
  {
    id: "maismilionaria",
    canonicalId: "maismilionaria",
    displayName: "+Milionaria",
    color: "#002B5C",
    minNumbers: 1,
    maxNumbers: 50,
    pickCount: 6,
    extraField: "trevos",
    extraOptions: [1, 2, 3, 4, 5, 6],
    extraPickCount: 2,
    drawDays: [3, 6], // Wed, Sat
    drawDayNames: { "pt-BR": "Quartas e sabados", en: "Wednesdays and Saturdays" },
    prizeRanges: [
      { hits: 6, label: "6 acertos + 2 trevos", labelEn: "6 hits + 2 clovers" },
      { hits: 6, label: "6 acertos + 1 ou 0 trevos", labelEn: "6 hits + 1 or 0 clovers" },
      { hits: 5, label: "5 acertos + 2 trevos", labelEn: "5 hits + 2 clovers" },
      { hits: 5, label: "5 acertos + 1 ou 0 trevos", labelEn: "5 hits + 1 or 0 clovers" },
      { hits: 4, label: "4 acertos + 2 trevos", labelEn: "4 hits + 2 clovers" },
      { hits: 3, label: "3 acertos + 2 trevos", labelEn: "3 hits + 2 clovers" },
      { hits: 2, label: "2 acertos + 2 trevos", labelEn: "2 hits + 2 clovers" },
    ],
  },
]

export function canonicalLotteryId(id: string): string {
  const s = (id || "").trim().toLowerCase().replace(/_/g, "-").replace(/ /g, "-")
  const alias: Record<string, string> = {
    "mega-sena": "megasena",
    "+milionaria": "maismilionaria",
    "mais-milionaria": "maismilionaria",
    "dia-de-sorte": "diadesorte",
    "dupla-sena": "duplasena",
    "super-sete": "supersete",
    "loto-facil": "lotofacil",
    "loto-mania": "lotomania",
    "time-mania": "timemania",
  }
  if (alias[s]) return alias[s]
  return s.replace(/-/g, "")
}

/** LOCKED PATTERNS - DO NOT MODIFY. These are the exact patterns the AI must use. */
export const LOCKED_PATTERNS: Record<string, { drawDays: number[]; prizeTiers: { hits: number; label: string }[]; dualDraw?: boolean }> = {
  megasena: {
    drawDays: [2, 4, 6], // Tue, Thu, Sat
    prizeTiers: [{ hits: 6, label: "6 acertos" }, { hits: 5, label: "5 acertos" }, { hits: 4, label: "4 acertos" }],
  },
  quina: {
    drawDays: [1, 2, 3, 4, 5, 6], // Mon-Sat
    prizeTiers: [{ hits: 5, label: "5 acertos" }, { hits: 4, label: "4 acertos" }],
  },
  maismilionaria: {
    drawDays: [3, 6], // Wed, Sat
    prizeTiers: [
      { hits: 6, label: "6 acertos + 2 trevos" },
      { hits: 6, label: "6 acertos + 1 ou 0 trevos" },
      { hits: 5, label: "5 acertos + 2 trevos" },
      { hits: 5, label: "5 acertos + 1 ou 0 trevos" },
      { hits: 4, label: "4 acertos + 2 trevos" },
    ],
  },
  lotofacil: {
    drawDays: [1, 2, 3, 4, 5, 6], // Mon-Sat
    prizeTiers: [{ hits: 15, label: "15 acertos" }, { hits: 14, label: "14 acertos" }],
  },
  timemania: {
    drawDays: [2, 4, 6], // Tue, Thu, Sat
    prizeTiers: [{ hits: 7, label: "7 acertos" }, { hits: 6, label: "6 acertos" }, { hits: 5, label: "5 acertos" }],
  },
  lotomania: {
    drawDays: [1, 3, 5], // Mon, Wed, Fri
    prizeTiers: [{ hits: 20, label: "20 acertos" }, { hits: 19, label: "19 acertos" }, { hits: 18, label: "18 acertos" }, { hits: 0, label: "0 acertos" }],
  },
  supersete: {
    drawDays: [1, 3, 5], // Mon, Wed, Fri
    prizeTiers: [{ hits: 7, label: "7 acertos" }, { hits: 6, label: "6 acertos" }, { hits: 5, label: "5 acertos" }],
  },
  diadesorte: {
    drawDays: [2, 4, 6], // Tue, Thu, Sat
    prizeTiers: [{ hits: 7, label: "7 acertos" }, { hits: 6, label: "6 acertos" }],
  },
  duplasena: {
    drawDays: [1, 3, 5], // Mon, Wed, Fri
    dualDraw: true,
    prizeTiers: [
      { hits: 6, label: "1o Sorteio - 6 acertos" },
      { hits: 5, label: "1o Sorteio - 5 acertos" },
      { hits: 6, label: "2o Sorteio - 6 acertos" },
      { hits: 5, label: "2o Sorteio - 5 acertos" },
    ],
  },
}

export function getLotteryById(id: string): LotteryConfig | undefined {
  const canonical = canonicalLotteryId(id)
  return LOTTERIES.find((l) => l.canonicalId === canonical)
}

export function getTodayLotteries(): LotteryConfig[] {
  const today = new Date()
  const day = today.getDay()
  return LOTTERIES.filter((l) => l.drawDays.includes(day))
}
